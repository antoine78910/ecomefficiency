const express = require('express');
const { ImapFlow } = require('imapflow');
require('dotenv').config();

const app = express();

// CORS pour permettre l'accès depuis l'extension
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
  } else {
    next();
  }
});
const PORT = process.env.PORT || process.env.IMAP_SERVER_PORT || 20016;

function mask(s) { return s ? s.replace(/.(?=.{4})/g, '*') : s; }

app.get('/otp', async (req, res) => {
  console.log('[imap] OTP request received at', new Date().toISOString());
  const imapHost = process.env.IMAP_HOST; // e.g., "imap.neospace.email"
  const imapPort = Number(process.env.IMAP_PORT || 993);
  const imapUser = process.env.IMAP_USER; // full email address
  const imapPass = process.env.IMAP_PASS; // app password
  const imapTLS  = String(process.env.IMAP_TLS || 'true') === 'true';
  const imapMethod = (process.env.IMAP_METHOD || 'LOGIN').toUpperCase(); // LOGIN or PLAIN

  console.log('[imap] Config:', { 
    host: imapHost, 
    port: imapPort, 
    user: imapUser ? imapUser.substring(0, 3) + '***' : 'missing',
    tls: imapTLS,
    method: imapMethod 
  });

  if (!imapHost || !imapUser || !imapPass) {
    console.error('[imap] Missing env vars', { host: !!imapHost, user: !!imapUser, pass: !!imapPass });
    return res.status(500).json({ error: 'Missing IMAP env vars' });
  }

  const client = new ImapFlow({
    host: imapHost,
    port: imapPort,
    secure: imapTLS,
    auth: { user: imapUser, pass: imapPass, method: imapMethod }
  });

  let code = '';
  try {
    await client.connect();
    const lock = await client.getMailboxLock('INBOX');
    try {
      // Search latest 20 unseen first, else latest 20
      let seq; 
      const unseen = await client.search({ seen: false }, { uid: true });
      if (unseen.length > 0) {
        seq = unseen.slice(-20);
      } else {
        const all = await client.search({}, { uid: true });
        seq = all.slice(-20);
      }
      seq = seq.reverse();

      for (const uid of seq) {
        const { content } = await client.download(uid, null, { uid: true });
        const raw = await contentToUtf8(content);
        // Quick filter to messages from OpenAI or referencing auth.openai.com
        const looksLikeOpenAI = /openai|auth\.openai\.com/i.test(raw);
        if (!looksLikeOpenAI) continue;
        // Extract the first 6-digit code in the message
        const m = raw.match(/\b(\d{6})\b/);
        if (m && m[1]) { code = m[1]; break; }
      }
    } finally {
      lock.release();
    }
  } catch (e) {
    console.error('[imap] Error while fetching OTP:', e);
    return res.status(500).json({ 
      error: (e && e.message) ? e.message : String(e),
      response: e && e.response,
      responseStatus: e && e.responseStatus,
      responseText: e && e.responseText,
      serverResponseCode: e && e.serverResponseCode
    });
  } finally {
    try { await client.logout(); } catch (_) {}
  }

  console.log('[imap] Sending response:', { code });
  res.json({ code });
});

// Dedicated endpoint for Vmake email OTP (4-digit code)
app.get('/otp-vmake', async (req, res) => {
  console.log('[imap-vmake] OTP-VMAKE request received at', new Date().toISOString());
  const imapHost = process.env.IMAP_HOST;
  const imapPort = Number(process.env.IMAP_PORT || 993);
  const imapUser = process.env.IMAP_USER;
  const imapPass = process.env.IMAP_PASS;
  const imapTLS  = String(process.env.IMAP_TLS || 'true') === 'true';
  const imapMethod = (process.env.IMAP_METHOD || 'LOGIN').toUpperCase();

  console.log('[imap-vmake] Config:', { 
    host: imapHost, 
    port: imapPort, 
    user: imapUser ? imapUser.substring(0, 3) + '***' : 'missing',
    tls: imapTLS,
    method: imapMethod 
  });

  if (!imapHost || !imapUser || !imapPass) {
    console.error('[imap-vmake] Missing env vars', { host: !!imapHost, user: !!imapUser, pass: !!imapPass });
    return res.status(500).json({ error: 'Missing IMAP env vars' });
  }

  const client = new ImapFlow({
    host: imapHost,
    port: imapPort,
    secure: imapTLS,
    auth: { user: imapUser, pass: imapPass, method: imapMethod }
  });

  let code = '';
  try {
    await client.connect();
    console.log('[imap-vmake] Connected to IMAP server');
    const lock = await client.getMailboxLock('INBOX');
    try {
      let seq; 
      const unseen = await client.search({ seen: false }, { uid: true });
      if (unseen.length > 0) {
        seq = unseen.slice(-20);
        console.log('[imap-vmake] Found', unseen.length, 'unseen emails, checking last 20');
      } else {
        const all = await client.search({}, { uid: true });
        seq = all.slice(-20);
        console.log('[imap-vmake] No unseen emails, checking last 20 from all emails');
      }
      // latest first
      seq = seq.reverse();
      console.log('[imap-vmake] Processing', seq.length, 'emails');

      const NOW = Date.now();
      const MAX_AGE_MS = 15 * 60 * 1000; // 15 minutes

      for (const uid of seq) {
        try {
          // Download email content and envelope for date check
          const message = await client.fetchOne(uid, { 
            envelope: true,
            bodyStructure: true 
          }, { uid: true });

          // 1. Date check - Ignore old emails
          if (message.envelope && message.envelope.date) {
            const emailDate = new Date(message.envelope.date);
            const ageMs = NOW - emailDate.getTime();
            if (ageMs > MAX_AGE_MS) {
              console.log('[imap-vmake] Email', uid, 'is too old (' + Math.round(ageMs/60000) + ' min), skipping.');
              continue;
            }
          }

          // 2. Sender check
          const fromAddress = message?.envelope?.from?.[0]?.address || '';
          const isFromVmake = /account@vmake\.ai/i.test(fromAddress);
          
          if (!isFromVmake) {
            // Also check headers in raw content later as backup, but for now continue
            // We'll rely on the content check if envelope fails or is generic
          } else {
             console.log('[imap-vmake] Found recent email from account@vmake.ai (UID: ' + uid + '), checking content...');
          }
          
          const { content } = await client.download(uid, null, { uid: true });
          const raw = await contentToUtf8(content);

          // Double check sender in content if envelope failed
          if (!isFromVmake && !(/from:\s*[^<\n]*account@vmake\.ai/i.test(raw) || /account@vmake\.ai/i.test(raw))) {
             continue;
          }

          // 3. Precise Code Extraction
          let m = null;
          
          // Pattern 1: STRICT - The code is in a div with font-size:40px (or similar)
          // Matches: <div style="...font-size:40px..."> 1538 </div>
          // We look for "40px" and digits inside the div tag content
          m = raw.match(/<div[^>]*style="[^"]*font-size:\s*40px[^"]*"[^>]*>[\s\r\n]*(\d{4})[\s\r\n]*<\/div>/i);
          
          if (!m) {
             // Variant: maybe attributes are ordered differently or quotes differ
             m = raw.match(/font-size:\s*40px[^>]*>[\s\r\n]*(\d{4})[\s\r\n]*<\/div>/i);
          }

          // Pattern 2: "Your verification code is" followed closely by 4 digits
          if (!m) {
             const contextMatch = raw.match(/Your verification code is[\s\S]{0,150}?(\d{4})/i);
             if (contextMatch) {
                // Avoid matching years like 2024, 2025 unless explicitly marked
                const candidate = contextMatch[1];
                const currentYear = new Date().getFullYear();
                // If it looks like a year (2020-2030) and wasn't in the specific div, be skeptical
                if (parseInt(candidate) >= 2020 && parseInt(candidate) <= 2030) {
                   console.log('[imap-vmake] Skipped candidate ' + candidate + ' because it looks like a year and wasn\'t in the main code box.');
                } else {
                   m = contextMatch;
                }
             }
          }

          if (m && m[1]) { 
            code = m[1]; 
            console.log('[imap-vmake] ✓ Extracted code:', code, 'from email UID:', uid);
            break; 
          } else {
             // ... logging ...
          }
        } catch (emailErr) {
          console.warn('[imap-vmake] Error processing email', uid, ':', emailErr.message);
          continue;
        }
      }
    } finally {
      lock.release();
    }
  } catch (e) {
    console.error('[imap-vmake] Error while fetching OTP:', e);
    return res.status(500).json({ 
      error: (e && e.message) ? e.message : String(e),
      response: e && e.response,
      responseStatus: e && e.responseStatus,
      responseText: e && e.responseText,
      serverResponseCode: e && e.serverResponseCode
    });
  } finally {
    try { await client.logout(); } catch (_) {}
  }

  console.log('[imap-vmake] Sending response:', { code: code || 'not found' });
  res.json({ code });
});

async function contentToUtf8(content) {
  if (!content) return '';
  // Node stream
  if (typeof content.on === 'function') {
    return new Promise((resolve, reject) => {
      let data = '';
      content.on('data', chunk => { data += Buffer.from(chunk).toString('utf8'); });
      content.on('end', () => resolve(data));
      content.on('error', reject);
    });
  }
  // Buffer or Uint8Array
  if (Buffer.isBuffer(content)) return content.toString('utf8');
  if (content instanceof Uint8Array) return Buffer.from(content).toString('utf8');
  if (typeof content === 'string') return content;
  try { return String(content || ''); } catch (_) { return ''; }
}

app.listen(PORT, () => {
  console.log(`[imap_server] listening on ${PORT}`);
});

app.get('/health', (req, res) => {
  res.json({ ok: true, port: Number(PORT) });
});

// Route racine pour éviter "Cannot GET /"
app.get('/', (req, res) => {
  res.json({ 
    message: 'IMAP Server is running', 
    endpoints: ['/otp', '/otp-vmake', '/health'],
    port: Number(PORT) 
  });
});
