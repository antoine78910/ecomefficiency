(function () {
  'use strict';

  const EMAIL = 'admin@ecomefficiency.com';
  const OTP_ENDPOINT = 'http://51.83.103.21:20016/otp-vmake';

  /**
   * Small helper to wait for an element to appear in the DOM.
   * @param {Function} finder - function that returns the element or null
   * @param {number} timeoutMs
   * @returns {Promise<HTMLElement|null>}
   */
  function waitForElementFn(finder, timeoutMs = 15000) {
    return new Promise((resolve) => {
      const start = Date.now();
      const existing = finder();
      if (existing) return resolve(existing);

      const observer = new MutationObserver(() => {
        const el = finder();
        if (el) {
          console.log(
            '[VMAVE-AUTOLOGIN] waitForElementFn: element found after',
            Date.now() - start,
            'ms'
          );
          observer.disconnect();
          resolve(el);
        }
      });
      observer.observe(document.documentElement, {
        childList: true,
        subtree: true,
      });

      setTimeout(() => {
        observer.disconnect();
        console.warn(
          '[VMAVE-AUTOLOGIN] waitForElementFn: timeout after',
          timeoutMs,
          'ms'
        );
        resolve(null);
      }, timeoutMs);
    });
  }

  function setNativeValue(input, value) {
    try {
      const proto = Object.getPrototypeOf(input);
      const desc =
        Object.getOwnPropertyDescriptor(proto, 'value') ||
        Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
      if (desc && typeof desc.set === 'function') {
        desc.set.call(input, value);
      } else {
        input.value = value;
      }
    } catch {
      input.value = value;
    }
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function humanClick(element) {
    if (!element) return;
    try {
      element.scrollIntoView({ block: 'center', behavior: 'auto' });
    } catch (_) {}

    const rect = element.getBoundingClientRect();
    let x = rect.left + rect.width / 2;
    let y = rect.top + rect.height / 2;

    // Clamp to viewport in case element is partially off-screen
    x = Math.min(Math.max(x, 5), window.innerWidth - 5);
    y = Math.min(Math.max(y, 5), window.innerHeight - 5);

    // Use the real element under this point (React usually listens on document)
    const target = document.elementFromPoint(x, y) || element;

    function fire(type) {
      const ev = new MouseEvent(type, {
        bubbles: true,
        cancelable: true,
        clientX: x,
        clientY: y,
        button: 0,
      });
      target.dispatchEvent(ev);
    }

    fire('mouseover');
    fire('mousemove');
    fire('mousedown');
    fire('mouseup');
    fire('click');
  }

  function clickTopRightArea() {
    const x = window.innerWidth - 10;
    const y = 20;
    const target = document.elementFromPoint(x, y);
    if (!target) {
      console.log('[VMAVE-AUTOLOGIN] clickTopRightArea: no target at point');
      return;
    }
    console.log('[VMAVE-AUTOLOGIN] clickTopRightArea: target =', target.tagName, target.className || '');

    function fire(type) {
      const ev = new MouseEvent(type, {
        bubbles: true,
        cancelable: true,
        clientX: x,
        clientY: y,
        button: 0,
      });
      target.dispatchEvent(ev);
    }

    fire('mouseover');
    fire('mousemove');
    fire('mousedown');
    fire('mouseup');
    fire('click');
  }

  function isOnVmakeWorkspace() {
    return (
      location.hostname === 'vmake.ai' &&
      (location.pathname === '/workspace' ||
        location.pathname.startsWith('/workspace'))
    );
  }

  const LOGIN_POPUP_SELECTOR =
    '.starii-account-view.starii-account-popuper-container.vmake-account-login-popup';

  function isLoginPopupVisible() {
    const el = document.querySelector(LOGIN_POPUP_SELECTOR);
    if (!el) return false;
    // Check if truly visible
    return el.offsetParent !== null && window.getComputedStyle(el).display !== 'none';
  }

  function removeUpsellUI() {
    if (location.hostname !== 'vmake.ai') return;

    const removeNow = () => {
      // Top banner "Recreate Viral Thumbnail in just one click — powered by Nano Banana Pro🍌"
      const banner = document.querySelector('.header-alert-wrap--6cBQU');
      if (banner) {
        console.log('[VMAVE-AUTOLOGIN] Banner detected, trying to close it');
        const closeBtn = banner.querySelector(
          '.header-alert-close--3tNHT, .vmake-close-bold-icon.header-alert-close--3tNHT'
        );
        if (closeBtn) {
          // Cliquer d'abord sur la croix pour que le site ferme la bannière proprement
          console.log('[VMAVE-AUTOLOGIN] Clicking banner close icon');
          humanClick(closeBtn);
        } else {
          // Fallback : masquer la bannière sans toucher à la structure React
          console.log('[VMAVE-AUTOLOGIN] No close icon, hiding banner with display:none');
          banner.style.display = 'none';
        }
      }

      // "Upgrade" button that points to /pricing
      const upgradeBtn = document.querySelector(
        'a.workbench-layout-upgrade--vz-Nf.workbench-layout-dark-upgrade-btn--LLMk-'
      );
      if (upgradeBtn) {
        console.log('[VMAVE-AUTOLOGIN] Hiding Upgrade button with display:none');
        upgradeBtn.style.display = 'none';
      }
    };

    // Remove once immediately
    removeNow();

    // Keep watching for re-insertions (SPA rerenders)
    const obs = new MutationObserver(() => removeNow());
    obs.observe(document.documentElement, {
      childList: true,
      subtree: true,
    });
  }

  function findContinueWithEmailButton() {
    const docs = [document];
    // Also inspect same-origin iframes if any (login form may be rendered there)
    for (const frame of Array.from(document.querySelectorAll('iframe'))) {
      try {
        if (frame.contentWindow && frame.contentWindow.document) {
          docs.push(frame.contentWindow.document);
        }
      } catch (_) {
        // cross-origin iframe, ignore
      }
    }

    for (const doc of docs) {
      // Scope the search to the popup if it exists in this document
      const scope =
        doc.querySelector(LOGIN_POPUP_SELECTOR) ||
        doc.querySelector('.vmake-account-login-popup') ||
        doc;

      // 0) Try the exact button the user described
      const exactBtn = Array.from(
        scope.querySelectorAll(
          'button.starii-account-button.starii-account-button-primary.starii-account-third-party-login-form-button'
        )
      ).find((btn) => {
        const txt = (btn.textContent || '').toLowerCase();
        return txt.includes('continue with email');
      });
      if (exactBtn) {
        console.log(
          '[VMAVE-AUTOLOGIN] Found exact "Continue with email" button in',
          scope === doc ? 'document root' : 'popup scope'
        );
        return exactBtn;
      }

      // 1) Look for the dedicated text span then climb to button
      const textSpans = Array.from(
        scope.querySelectorAll(
          '.starii-account-third-party-login-form-button-text'
        )
      );
      const spanMatch = textSpans.find((el) => {
        const txt = (el.textContent || '').toLowerCase();
        return txt.includes('continue with email') || txt.includes('email');
      });
      if (spanMatch) {
        const btn = spanMatch.closest('button');
        if (btn) {
          console.log('[VMAVE-AUTOLOGIN] Found "Continue with email" via text span in', doc === document ? 'main document' : 'iframe');
          return btn;
        }
      }

      // 2) Fallback: direct button class selectors + text match
      const buttons = Array.from(
        scope.querySelectorAll(
          'button.starii-account-third-party-login-form-button, button.starii-account-button'
        )
      );
      const btnByText = buttons.find((btn) => {
        const txt = (btn.textContent || '').toLowerCase();
        return txt.includes('continue with email') || txt.includes('email');
      });
      if (btnByText) {
        console.log('[VMAVE-AUTOLOGIN] Found "Continue with email" via button text match in', doc === document ? 'main document' : 'iframe');
        return btnByText;
      }

      // 3) Fallback by icon mail + any surrounding button
      const mailIcon = scope.querySelector(
        '.starii-account-icon-mail, .starii-account-third-party-login-form-button-icon-email'
      );
      if (mailIcon) {
        const btnFromIcon = mailIcon.closest('button');
        if (btnFromIcon) {
          console.log('[VMAVE-AUTOLOGIN] Found "Continue with email" via mail icon in', doc === document ? 'main document' : 'iframe');
          return btnFromIcon;
        }
      }

      // 4) Very generic fallback: any node whose text contains "Continue with email"
      const anyNode = Array.from(scope.querySelectorAll('*')).find((el) => {
        const txt = (el.textContent || '').toLowerCase();
        return txt.includes('continue with email') || txt.includes('email');
      });
      if (anyNode) {
        const btnClosest = anyNode.closest('button');
        if (btnClosest) {
          console.log('[VMAVE-AUTOLOGIN] Found "Continue with email" via generic text search (button ancestor) in', doc === document ? 'main document' : 'iframe');
          return btnClosest;
        }
        // If we found text but no button ancestor, ignore this match and continue
        console.log(
          '[VMAVE-AUTOLOGIN] Generic text "Continue with email" found without button ancestor, ignoring'
        );
      }
    }

    return null;
  }

  function hasVipCrown() {
    // Look for the VIP badge/crown inside the account area
    const account = document.querySelector(
      '.account-account--6Pkj5.workbench-layout-account--xLQe0'
    );
    if (!account) return false;
    return !!account.querySelector(
      '.account-vip-badge--VzVkQ .vmake-vip-icon, .badge-badge--LQ0Th.account-badge--YgpaI .vmake-vip-icon'
    );
  }

  let emailFlowRunning = false;

  async function openLoginPopupIfNeeded() {
    console.log('[VMAVE-AUTOLOGIN] openLoginPopupIfNeeded called');
    if (hasVipCrown()) {
      console.log('[VMAVE-AUTOLOGIN] Already on VIP account, nothing to do.');
      return false;
    }

    const accountBtn =
      // 1. Try exact classes provided recently by user
      document.querySelector('.ant-dropdown-trigger.account-account--6Pkj5.workbench-layout-account--xLQe0') ||
      // 2. Try generic account class parts (often stable)
      document.querySelector('[class*="workbench-layout-account"]') ||
      document.querySelector('[class*="account-account"]') ||
      // 3. Try finding the avatar image and going up to parent
      (function() {
         const svg = document.querySelector('.ant-avatar svg');
         return svg ? svg.closest('.ant-dropdown-trigger') : null;
      })() ||
      // 4. Wait for it if needed
      (await waitForElementFn(() =>
        document.querySelector('.ant-dropdown-trigger.account-account--6Pkj5')
      ));

    if (!accountBtn) {
      console.warn(
        '[VMAVE-AUTOLOGIN] Account button not found, forcing click on top-right area.'
      );
      // Force click top right (coordinates x=window.width-50, y=30)
      const x = window.innerWidth - 60;
      const y = 35;
      const el = document.elementFromPoint(x, y);
      if (el) {
          console.log('[VMAVE-AUTOLOGIN] Clicking element at top-right:', el);
          humanClick(el);
          el.click(); // Try both
      }
      return true;
    }

    // Simule un vrai clic souris sur l'avatar (même si l'attribut disabled est présent)
    console.log('[VMAVE-AUTOLOGIN] Account avatar found, performing humanClick');
    humanClick(accountBtn);

    // Fallback: if nothing appears, also click top-right corner once
    setTimeout(() => {
      console.log('[VMAVE-AUTOLOGIN] Fallback: extra click in top-right area');
      clickTopRightArea();
    }, 500);

    return true;
  }

  async function startEmailLoginFlow() {
    if (emailFlowRunning) {
      console.log('[VMAVE-AUTOLOGIN] startEmailLoginFlow: already running, skip');
      return;
    }
    emailFlowRunning = true;

    try {
      console.log('[VMAVE-AUTOLOGIN] startEmailLoginFlow: begin');

      if (!isLoginPopupVisible()) {
        const popupOpened = await openLoginPopupIfNeeded();
        console.log(
          '[VMAVE-AUTOLOGIN] startEmailLoginFlow: popupOpened =',
          popupOpened
        );
        if (!popupOpened && hasVipCrown()) {
          // already logged, nothing else
          console.log(
            '[VMAVE-AUTOLOGIN] Popup not opened but crown detected afterwards, stopping auto-login.'
          );
          return;
        }
      } else {
        console.log(
          '[VMAVE-AUTOLOGIN] Login popup already visible, skipping avatar click'
        );
      }

      // 1) Click "Continue with email"
      console.log('[VMAVE-AUTOLOGIN] Waiting for "Continue with email" button');
      const emailBtn = await waitForElementFn(
        () => findContinueWithEmailButton(),
        15000
      );

      if (!emailBtn) {
        console.warn(
          '[VMAVE-AUTOLOGIN] "Continue with email" button not found.'
        );
        return;
      }
      console.log(
        '[VMAVE-AUTOLOGIN] "Continue with email" button found, performing humanClick'
      );
      humanClick(emailBtn);

      // 2) Fill email field
      console.log('[VMAVE-AUTOLOGIN] Waiting for email input field');
      const emailInput = await waitForElementFn(
        () =>
          document.querySelector(
            'input.starii-account-input-native[placeholder="Enter your email address"]'
          ),
        15000
      );

      if (!emailInput) {
        console.warn(
          '[VMAVE-AUTOLOGIN] Email input not found after clicking "Continue with email".'
        );
        return;
      }

      console.log('[VMAVE-AUTOLOGIN] Email input found, filling with', EMAIL);
      setNativeValue(emailInput, EMAIL);

      // Wait a bit for the input to be processed
      await new Promise((r) => setTimeout(r, 300));

      // 3) Click "Send" button
      console.log('[VMAVE-AUTOLOGIN] Waiting for "Send" button');
      const sendBtn = await waitForElementFn(
        () => {
          // Try exact selector first
          const exactBtn = document.querySelector(
            'button.starii-account-button.starii-account-button-primary.starii-account-email-verify-login-view-submit'
          );
          if (exactBtn && /send/i.test(exactBtn.textContent || '')) {
            return exactBtn;
          }
          
          // Fallback: search by class and text
          return Array.from(
            document.querySelectorAll(
              'button.starii-account-email-verify-login-view-submit, button.starii-account-button.starii-account-button-primary'
            )
          ).find((btn) => {
            const text = (btn.textContent || '').trim();
            return /^send$/i.test(text) || text.toLowerCase() === 'send';
          });
        },
        10000
      );

      if (!sendBtn) {
        console.warn(
          '[VMAVE-AUTOLOGIN] "Send" button for verification code not found.'
        );
        return;
      }

      console.log('[VMAVE-AUTOLOGIN] "Send" button found:', {
        text: sendBtn.textContent,
        classes: sendBtn.className,
        disabled: sendBtn.disabled
      });

      // Wait for button to be enabled (sometimes disabled briefly while validating)
      let attempts = 0;
      while (sendBtn.disabled && attempts < 10) {
        console.log('[VMAVE-AUTOLOGIN] Send button is disabled, waiting...');
        await new Promise((r) => setTimeout(r, 200));
        attempts++;
      }

      // Use humanClick instead of simple click() for better React compatibility
      setTimeout(async () => {
        console.log('[VMAVE-AUTOLOGIN] Clicking "Send" button with humanClick');
        humanClick(sendBtn);
        
        console.log('[VMAVE-AUTOLOGIN] "Send" clicked. Waiting for OTP input to appear...');
        
        // 4) Wait for OTP input (usually appears after send)
        // Try to find the verify code input
        const otpInput = await waitForElementFn(() => 
          document.querySelector('input[placeholder*="verification code"], input[placeholder*="code"], .starii-account-input-code') ||
          document.querySelector('input.starii-account-input-native[type="text"]')
        , 10000);
        
        if (otpInput) {
             console.log('[VMAVE-AUTOLOGIN] OTP Input detected.');
        } else {
             console.log('[VMAVE-AUTOLOGIN] OTP Input not specificly detected, continuing with timer...');
        }

        console.log('[VMAVE-AUTOLOGIN] Waiting 20 seconds for email delivery...');
        
        // Show overlay immediately so user sees "Searching..."
        ensureOtpOverlay();

        // Wait 20 seconds BEFORE requesting code
        setTimeout(() => {
          console.log('[VMAVE-AUTOLOGIN] 20s elapsed. Starting OTP search.');
          requestOtpCode();
        }, 20000);

      }, 500);
    } finally {
      emailFlowRunning = false;
    }
  }

  // ---------- OTP overlay ----------

  let otpRequestInFlight = false;
  let lastOtpCode = null;

  function ensureOtpOverlay() {
    if (document.getElementById('vmake-otp-overlay')) return;

    const overlay = document.createElement('div');
    overlay.id = 'vmake-otp-overlay';
    Object.assign(overlay.style, {
      position: 'fixed',
      top: '12px',
      right: '12px',
      zIndex: '2147483647',
      width: '220px',
      minHeight: '80px',
      background: 'rgba(0,0,0,0.7)',
      color: '#fff',
      borderRadius: '10px',
      padding: '12px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: '8px',
      boxShadow: '0 4px 16px rgba(0,0,0,0.25)',
      fontFamily:
        '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
    });

    const spinner = document.createElement('div');
    spinner.id = 'vmake-otp-spinner';
    Object.assign(spinner.style, {
      width: '24px',
      height: '24px',
      border: '3px solid rgba(255,255,255,0.3)',
      borderTopColor: '#fff',
      borderRadius: '50%',
      animation: 'vmake-otp-spin 1s linear infinite',
    });

    const style = document.createElement('style');
    style.textContent =
      '@keyframes vmake-otp-spin{to{transform:rotate(360deg)}}';

    const label = document.createElement('div');
    label.id = 'vmake-otp-label';
    label.textContent = 'Searching for Vmake code...';
    Object.assign(label.style, {
      fontSize: '12px',
      opacity: '0.9',
      textAlign: 'center',
    });

    const result = document.createElement('div');
    result.id = 'vmake-otp-result';
    Object.assign(result.style, {
      fontSize: '20px',
      fontWeight: 'bold',
      letterSpacing: '0.25em',
      textAlign: 'center',
    });

    const copyBtn = document.createElement('button');
    copyBtn.id = 'vmake-otp-copy';
    copyBtn.textContent = 'Copy code';
    Object.assign(copyBtn.style, {
      display: 'none',
      fontSize: '12px',
      padding: '5px 10px',
      borderRadius: '6px',
      border: '1px solid #888',
      background: '#222',
      color: '#fff',
      cursor: 'pointer',
    });

    const hint = document.createElement('div');
    hint.id = 'vmake-otp-hint';
    // Utilisation de innerHTML pour insérer le lien
    hint.innerHTML = 'If it doesn\'t work copy paste the code you see <a href="http://51.83.103.21:20016/otp-vmake" target="_blank" style="color:#4daaff;text-decoration:underline;">here</a>';
    Object.assign(hint.style, {
      fontSize: '10px',
      opacity: '0.8',
      textAlign: 'center',
    });

    const retryBtn = document.createElement('button');
    retryBtn.id = 'vmake-otp-retry';
    retryBtn.textContent = 'Retry';
    Object.assign(retryBtn.style, {
      display: 'none',
      fontSize: '11px',
      padding: '4px 8px',
      borderRadius: '6px',
      border: '1px solid #888',
      background: '#222',
      color: '#fff',
      cursor: 'pointer',
    });

    retryBtn.addEventListener('click', () => {
      lastOtpCode = null;
      otpRequestInFlight = false;
      const res = document.getElementById('vmake-otp-result');
      const lab = document.getElementById('vmake-otp-label');
      const spin = document.getElementById('vmake-otp-spinner');
      if (res) res.textContent = '';
      if (lab) lab.textContent = 'Searching for Vmake code...';
      if (spin) spin.style.display = 'block';
      retryBtn.style.display = 'none';
      requestOtpCode();
    });

    overlay.appendChild(style);
    overlay.appendChild(spinner);
    overlay.appendChild(label);
    overlay.appendChild(result);
    overlay.appendChild(copyBtn);
    overlay.appendChild(retryBtn);
    overlay.appendChild(hint);

    document.documentElement.appendChild(overlay);
  }

  function setOtpCodeOnOverlay(code) {
    const result = document.getElementById('vmake-otp-result');
    const copyBtn = document.getElementById('vmake-otp-copy');
    const spinner = document.getElementById('vmake-otp-spinner');
    const label = document.getElementById('vmake-otp-label');
    if (!result || !copyBtn || !spinner || !label) return;

    spinner.style.display = 'none';
    label.textContent = 'Vmake code received:';
    result.textContent = code;
    copyBtn.style.display = 'inline-block';

    copyBtn.onclick = async () => {
      try {
        await navigator.clipboard.writeText(code);
        copyBtn.textContent = 'Copied';
        setTimeout(() => {
          copyBtn.textContent = 'Copy code';
        }, 1200);
      } catch (e) {
        console.warn('[VMAVE-AUTOLOGIN] Clipboard write failed:', e);
      }
    };

    // Auto-close overlay when OTP input disappears (login success)
    const checkInterval = setInterval(() => {
      const otpInput = document.querySelector('input[placeholder*="verification code"], input[placeholder*="code"], .starii-account-input-code, input.starii-account-input-native[type="text"]');
      // If OTP input is gone and we are not in the "searching" phase (code is displayed), close overlay
      if (!otpInput) {
        const ov = document.getElementById('vmake-otp-overlay');
        if (ov) {
            console.log('[VMAVE-AUTOLOGIN] OTP input gone, closing overlay.');
            ov.remove();
        }
        clearInterval(checkInterval);
      }
    }, 1000);
  }

  async function requestOtpCode() {
    if (otpRequestInFlight) return;
    if (lastOtpCode) {
      console.log('[VMAVE-AUTOLOGIN] Using cached OTP code:', lastOtpCode);
      setOtpCodeOnOverlay(lastOtpCode);
      return;
    }

    console.log('[VMAVE-AUTOLOGIN] Requesting OTP code via Background Script');
    otpRequestInFlight = true;
    
    try {
      // Try more times with delays (email delivery can take 10-30s)
      let code = '';
      // Increase attempts to 10 (approx 45-60 seconds total wait time)
      for (let attempt = 0; attempt < 10 && !code; attempt++) {
        console.log('[VMAVE-AUTOLOGIN] OTP attempt', attempt + 1, 'of 10');
        
        try {
          // Send message to background script to bypass Mixed Content blocking
          const response = await new Promise((resolve) => {
             chrome.runtime.sendMessage({ type: 'FETCH_VMAKE_OTP' }, (res) => {
               resolve(res);
             });
          });
          
          if (response && response.ok && response.code) {
             code = response.code;
             console.log('[VMAVE-AUTOLOGIN] OTP received from BG:', code);
          } else {
             console.warn('[VMAVE-AUTOLOGIN] BG response not OK:', response);
          }
          
        } catch (err) {
          console.error('[VMAVE-AUTOLOGIN] Messaging error:', err);
        }
        
        if (!code && attempt < 9) {
          // Progressive delay: 4s
          const delay = 4000; 
          console.log('[VMAVE-AUTOLOGIN] Waiting', delay, 'ms before next attempt...');
          await new Promise((r) => setTimeout(r, delay));
        }
      }

      if (code && code.length >= 4) {
        lastOtpCode = code;
        setOtpCodeOnOverlay(code);
      } else {
        console.warn('[VMAVE-AUTOLOGIN] No valid OTP code found in mailbox');
        const label = document.getElementById('vmake-otp-label');
        const spinner = document.getElementById('vmake-otp-spinner');
        const result = document.getElementById('vmake-otp-result');
        const retryBtn = document.getElementById('vmake-otp-retry');
        if (spinner) spinner.style.display = 'none';
        if (label) label.textContent = 'No code found in emails.';
        if (result) result.textContent = '';
        if (retryBtn) retryBtn.style.display = 'inline-block';
      }
    } catch (e) {
      console.error('[VMAVE-AUTOLOGIN] Error while requesting OTP:', e);
      // ... error UI handling ...
      const label = document.getElementById('vmake-otp-label');
      const spinner = document.getElementById('vmake-otp-spinner');
      const result = document.getElementById('vmake-otp-result');
      const retryBtn = document.getElementById('vmake-otp-retry');
      if (spinner) spinner.style.display = 'none';
      if (label) label.textContent = 'Error retrieving code.';
      if (result) result.textContent = '';
      if (retryBtn) retryBtn.style.display = 'inline-block';
    } finally {
      otpRequestInFlight = false;
    }
  }

  function init() {
    if (location.hostname !== 'vmake.ai') return;

    console.log(
      '[VMAVE-AUTOLOGIN] init on',
      location.hostname,
      'path:',
      location.pathname
    );

    // Always clean banner + upgrade button on any vmake.ai page
    removeUpsellUI();

    // Auto-login uniquement sur /workspace quand il n'y a pas encore la couronne
    if (!isOnVmakeWorkspace()) return;

    // Watcher toutes les 0.5s pour déclencher le process dès que le popup est visible
    let popupHandled = false;
    setInterval(() => {
      if (!isOnVmakeWorkspace()) return;
      if (!isLoginPopupVisible()) return;
      if (popupHandled) return;
      console.log(
        '[VMAVE-AUTOLOGIN] Login popup detected by watcher, starting email flow'
      );
      popupHandled = true;
      startEmailLoginFlow();
    }, 500);

    // Wait a bit for header to render, then decide if we need to login
    setTimeout(() => {
      console.log('[VMAVE-AUTOLOGIN] Checking VIP crown before auto-login');
      if (hasVipCrown()) {
        console.log('[VMAVE-AUTOLOGIN] VIP crown detected, already logged in.');
        return;
      }
      console.log('[VMAVE-AUTOLOGIN] No VIP crown, starting email login flow');
      startEmailLoginFlow();
    }, 1500);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }
})();


