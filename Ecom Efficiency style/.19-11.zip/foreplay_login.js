// foreplay_login.js
console.log('[Foreplay Login] Script chargé');

function executeAutoLogin() {
    // Vérifier si on est sur la page de login
    if (!window.location.href.startsWith('https://app.foreplay.co/login')) {
        console.log('[Foreplay Login] Pas sur la page de login');
        // Si on n'est plus sur la page de login, on peut supprimer l'écran noir
        removeBlackScreen();
        return false;
    }

    // Vérifier si le script a déjà été exécuté
    if (window.foreplayLoginExecuted) {
        console.log('[Foreplay Login] Auto-login déjà exécuté');
        return true;
    }

    console.log('[Foreplay Login] Démarrage de l\'auto-login Foreplay');
    
    // Marquer comme exécuté
    window.foreplayLoginExecuted = true;
    
    // Exécuter directement le code d'auto-login au lieu d'injecter un script externe
    setTimeout(() => {
        startForeplayAutoLogin();
    }, 1000);
    
    return true;
}

// Fonction principale d'auto-login (intégrée directement)
async function startForeplayAutoLogin() {
    console.log('[FOREPLAY-LOGIN] 🚀 === DÉMARRAGE AUTO-LOGIN FOREPLAY ===');
    
    try {
        // Afficher la barre de chargement
        showLoadingBar();
        
        // Récupérer les credentials
        const credentials = await fetchCredentials();
        console.log('[FOREPLAY-LOGIN] ✅ Credentials récupérés:', credentials.email);
        
        // Remplir les champs et soumettre
        await autoLogin(credentials);
        
    } catch (error) {
        console.error('[FOREPLAY-LOGIN] ❌ Auto-login échoué:', error);
        // En cas d'erreur totale, garder l'écran noir car on est probablement encore sur la page de login
        console.log('[FOREPLAY-LOGIN] 🖤 Écran noir maintenu suite à l\'erreur de récupération');
    }
}

// ===== FONCTIONS INTÉGRÉES (de auto_login_foreplay.js) =====

// Création de la barre de chargement avec fond noir
function showLoadingBar() {
    if (document.getElementById('login-overlay')) {
        return;
    }

    const overlay = document.createElement('div');
    overlay.id = 'login-overlay';
    Object.assign(overlay.style, {
        position: 'fixed',
        top: '0',
        left: '0',
        width: '100%',
        height: '100%',
        backgroundColor: 'rgba(0, 0, 0, 1)',
        zIndex: '2147483647',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        pointerEvents: 'none',
    });

    const logo = document.createElement('img');
    logo.src = chrome.runtime.getURL('logo_ecom.png');
    logo.alt = 'Ecom Efficiency Logo';
    Object.assign(logo.style, {
        width: '100px',
        height: '100px',
        marginBottom: '20px',
        borderRadius: '30px',
        animation: 'ecom-pulse 2.4s cubic-bezier(.5,0,.5,1) infinite'
    });
    overlay.appendChild(logo);

    if (!document.getElementById('ecom-pulse-style')) {
        const style = document.createElement('style');
        style.id = 'ecom-pulse-style';
        style.textContent = `
        @keyframes ecom-pulse {
            0%   { transform: scale(1);   filter: drop-shadow(0 0 0 #7c3aed); }
            30%  { transform: scale(1.10);filter: drop-shadow(0 0 18px #a78bfa);}
            50%  { transform: scale(1.15);filter: drop-shadow(0 0 32px #7c3aed);}
            70%  { transform: scale(1.10);filter: drop-shadow(0 0 18px #a78bfa);}
            100% { transform: scale(1);   filter: drop-shadow(0 0 0 #7c3aed); }
        }`;
        document.head.appendChild(style);
    }

    const progressContainer = document.createElement('div');
    Object.assign(progressContainer.style, {
        width: '80%',
        maxWidth: '400px',
        backgroundColor: '#333',
        borderRadius: '10px',
        height: '15px',
        overflow: 'hidden',
        marginBottom: '10px'
    });

    const progressBar = document.createElement('div');
    progressBar.id = 'progress-bar';
    Object.assign(progressBar.style, {
        height: '100%',
        width: '0%',
        backgroundColor: '#7c3aed',
        transition: 'width 0.1s linear'
    });

    progressContainer.appendChild(progressBar);
    overlay.appendChild(progressContainer);

    const loadingContainer = document.createElement('div');
    loadingContainer.style.display = 'flex';
    loadingContainer.style.alignItems = 'center';
    loadingContainer.style.gap = '5px';
    loadingContainer.style.marginTop = '10px';

    const loadingText = document.createElement('div');
    loadingText.id = 'loading-text';
    loadingText.textContent = 'Chargement';
    Object.assign(loadingText.style, {
        color: 'white',
        fontSize: '14px'
    });

    const dots = document.createElement('span');
    dots.id = 'loading-dots';
    dots.textContent = '...';
    dots.style.width = '24px';
    dots.style.display = 'inline-block';
    dots.style.textAlign = 'left';

    loadingContainer.appendChild(loadingText);
    loadingContainer.appendChild(dots);
    overlay.appendChild(loadingContainer);

    let dotCount = 0;
    const maxDots = 3;
    let dotsInterval = setInterval(() => {
        dotCount = (dotCount % maxDots) + 1;
        dots.textContent = '.'.repeat(dotCount) + ' '.repeat(maxDots - dotCount);
    }, 300);

    document.body.appendChild(overlay);
    document.body.style.overflow = 'hidden';

    const duration = 10000;
    const startTime = Date.now();
    
    function updateProgress() {
        const elapsed = Date.now() - startTime;
        const progress = Math.min(elapsed / duration * 100, 100);
        
        progressBar.style.width = `${progress}%`;
        
        if (progress < 100) {
            requestAnimationFrame(updateProgress);
        } else {
            clearInterval(dotsInterval);
            document.getElementById('loading-dots').textContent = '...';
            
            // Ne pas supprimer automatiquement l'écran noir - il sera géré par la surveillance du login
            console.log('[FOREPLAY-LOGIN] 🖤 Écran de chargement terminé - maintenu pour masquer le login');
        }
    }
    
    updateProgress();
    
    overlay._cleanup = () => {
        clearInterval(dotsInterval);
    };
    
    return overlay;
}

// ===== GESTION DE L'ÉCRAN NOIR POUR LE LOGIN =====

function removeBlackScreen() {
    const overlay = document.getElementById('login-overlay');
    if (overlay) {
        console.log('[FOREPLAY-LOGIN] 🖤➡️ Suppression de l\'écran noir');
        overlay.style.transition = 'opacity 0.5s ease-in-out';
        overlay.style.opacity = '0';
        setTimeout(() => {
            if (overlay && overlay.parentNode) {
                document.body.style.overflow = '';
                overlay.remove();
            }
        }, 500);
    } else {
        console.log('[FOREPLAY-LOGIN] 🖤 Aucun écran noir à supprimer');
    }
}

function monitorLoginSuccess() {
    let checkCount = 0;
    const maxChecks = 30; // 15 secondes maximum (500ms * 30)
    
    const checkForPageChange = () => {
        checkCount++;
        console.log(`[FOREPLAY-LOGIN] 👀 Vérification ${checkCount}/${maxChecks} - URL actuelle: ${window.location.href}`);
        
        // Si on n'est plus sur la page de login, succès !
        if (!window.location.href.startsWith('https://app.foreplay.co/login')) {
            console.log('[FOREPLAY-LOGIN] ✅ Login réussi - changement de page détecté');
            removeBlackScreen();
            return;
        }
        
        // Vérifier s'il y a des messages d'erreur
        const errorElement = document.querySelector('.error, .alert, .alert-danger, [class*="error"], [class*="invalid"]');
        if (errorElement && errorElement.textContent.trim()) {
            console.log('[FOREPLAY-LOGIN] ❌ Message d\'erreur détecté:', errorElement.textContent.trim());
            console.log('[FOREPLAY-LOGIN] 🖤 Écran noir maintenu - échec du login');
            return;
        }
        
        // Si on atteint le maximum de vérifications et qu'on est toujours sur la page de login
        if (checkCount >= maxChecks) {
            console.log('[FOREPLAY-LOGIN] ⏰ Timeout - toujours sur la page de login après 15 secondes');
            console.log('[FOREPLAY-LOGIN] 🖤 Écran noir maintenu - login probablement échoué');
            return;
        }
        
        // Continuer à vérifier
        setTimeout(checkForPageChange, 500);
    };
    
    // Commencer la surveillance après un délai pour laisser le temps au serveur de répondre
    setTimeout(checkForPageChange, 1000);
}

// URLs pour accéder au Google Sheet
const GOOGLE_SHEET_CSV_URL = 'https://docs.google.com/spreadsheets/d/e/2PACX-1vRFtg1rXIe3_TFgDUA6Rj8ARgFBgDPEWfGSH1py5pDzVrlVWXEP9WxwUTjnUJCVCGSd1nRfDWV49Bdm/pub?output=csv';
const GOOGLE_SHEET_HTML_URL = 'https://docs.google.com/spreadsheets/d/e/2PACX-1vRFtg1rXIe3_TFgDUA6Rj8ARgFBgDPEWfGSH1py5pDzVrlVWXEP9WxwUTjnUJCVCGSd1nRfDWV49Bdm/pubhtml';

// Parser une ligne CSV (gère les guillemets et virgules)
function parseCSVLine(line) {
    const result = [];
    let current = '';
    let inQuotes = false;
    
    for (let i = 0; i < line.length; i++) {
        const char = line[i];
        if (char === '"') {
            inQuotes = !inQuotes;
        } else if (char === ',' && !inQuotes) {
            result.push(current.trim());
            current = '';
        } else {
            current += char;
        }
    }
    result.push(current.trim());
    return result;
}

// Parser les données CSV pour trouver "foreplay"
function parseCSVForForeplay(csvData) {
    console.log('[FOREPLAY-LOGIN] 📊 Début du parsing CSV pour Foreplay');
    console.log('[FOREPLAY-LOGIN] 📈 Données CSV reçues, longueur:', csvData.length);
    
    const lines = csvData.split('\n').filter(line => line.trim());
    console.log('[FOREPLAY-LOGIN] 📋 Nombre de lignes trouvées:', lines.length);
    
    // Afficher un aperçu des premières lignes pour debug
    console.log('[FOREPLAY-LOGIN] 🔍 Aperçu des premières lignes:');
    lines.slice(0, 5).forEach((line, index) => {
        console.log(`[FOREPLAY-LOGIN] Ligne ${index + 1}:`, line.substring(0, 100) + (line.length > 100 ? '...' : ''));
    });
    
    for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        const cells = parseCSVLine(line);
        
        if (cells.length >= 3) {
            const firstCell = cells[0]?.toString().trim().toLowerCase();
            console.log(`[FOREPLAY-LOGIN] 🔍 Ligne ${i + 1} - Première cellule:`, `"${firstCell}"`);
            
            // Recherche "foreplay" (différentes variantes)
            if (firstCell === 'foreplay' || firstCell.includes('foreplay')) {
                const email = cells[1]?.toString().trim() || '';
                const password = cells[2]?.toString().trim() || '';
                
                console.log('[FOREPLAY-LOGIN] 🎯 Ligne Foreplay trouvée !');
                console.log('[FOREPLAY-LOGIN] 📧 Email:', email);
                console.log('[FOREPLAY-LOGIN] 🔐 Password longueur:', password.length);
                
                if (email && password) {
                    return { email, password };
                } else {
                    console.log('[FOREPLAY-LOGIN] ⚠️ Email ou password vide');
                }
            }
        }
    }
    
    console.log('[FOREPLAY-LOGIN] ❌ Aucune ligne "foreplay" trouvée dans le CSV');
    return null;
}

// Parser les données HTML pour trouver "foreplay" (fallback)
function parseHTMLForForeplay(htmlData) {
    console.log('[FOREPLAY-LOGIN] 🌐 Début du parsing HTML pour Foreplay');
    
    const doc = new DOMParser().parseFromString(htmlData, 'text/html');
    const rows = doc.querySelectorAll('tr');
    console.log('[FOREPLAY-LOGIN] 📋 Nombre de lignes HTML trouvées:', rows.length);
    
    for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const cells = row.querySelectorAll('td, th');
        
        if (cells.length >= 3) {
            const firstCellText = cells[0]?.textContent?.trim().toLowerCase() || '';
            console.log(`[FOREPLAY-LOGIN] 🔍 Ligne HTML ${i + 1} - Première cellule:`, `"${firstCellText}"`);
            
            if (firstCellText === 'foreplay' || firstCellText.includes('foreplay')) {
                // Extraire email et password des cellules suivantes
                const emailCell = cells[1];
                const passCell = cells[2];
                
                const email = (emailCell.querySelector('.softmerge-inner')?.textContent || emailCell.textContent || '').trim();
                const password = (passCell.querySelector('.softmerge-inner')?.textContent || passCell.textContent || '').trim();
                
                console.log('[FOREPLAY-LOGIN] 🎯 Ligne Foreplay trouvée en HTML !');
                console.log('[FOREPLAY-LOGIN] 📧 Email:', email);
                console.log('[FOREPLAY-LOGIN] 🔐 Password longueur:', password.length);
                
                if (email && password) {
                    return { email, password };
                }
            }
        }
    }
    
    console.log('[FOREPLAY-LOGIN] ❌ Aucune ligne "foreplay" trouvée dans le HTML');
    return null;
}

// Fonction principale de récupération des credentials (robuste)
async function fetchCredentials() {
    console.log('[FOREPLAY-LOGIN] 🚀 === RÉCUPÉRATION IDENTIFIANTS GOOGLE SHEETS ===');
    
    // MÉTHODE 1: Essayer de récupérer en CSV d'abord
    try {
        console.log('[FOREPLAY-LOGIN] 🔍 Méthode 1: Récupération format CSV...');
        const csvResponse = await fetch(GOOGLE_SHEET_CSV_URL);
        
        if (csvResponse.ok) {
            const csvData = await csvResponse.text();
            console.log('[FOREPLAY-LOGIN] 📊 CSV récupéré avec succès');
            
            // Vérifier que c'est bien du CSV et pas une page d'erreur
            if (csvData.includes('<html') || csvData.includes('Google Drive')) {
                console.log('[FOREPLAY-LOGIN] ⚠️ CSV retourne une page HTML - tentative suivante');
            } else {
                const result = parseCSVForForeplay(csvData);
                if (result) {
                    console.log('[FOREPLAY-LOGIN] ✅ Credentials trouvés via CSV !');
                    return result;
                }
            }
        } else {
            console.log('[FOREPLAY-LOGIN] ❌ Erreur CSV:', csvResponse.status);
        }
    } catch (error) {
        console.log('[FOREPLAY-LOGIN] ❌ Erreur lors de la récupération CSV:', error.message);
    }
    
    // MÉTHODE 2: Fallback vers HTML
    console.log('[FOREPLAY-LOGIN] 🔍 Méthode 2: Récupération format HTML...');
    
    const htmlUrls = [
        GOOGLE_SHEET_HTML_URL,
        GOOGLE_SHEET_HTML_URL + '?gid=0',
        GOOGLE_SHEET_HTML_URL.replace('/pubhtml', '/pub?output=html'),
        GOOGLE_SHEET_HTML_URL.replace('/pubhtml', '/pub?gid=0&single=true&output=html')
    ];
    
    for (const url of htmlUrls) {
        try {
            console.log('[FOREPLAY-LOGIN] 🌐 Tentative URL HTML:', url);
            const htmlResponse = await fetch(url);
            
            if (htmlResponse.ok) {
                const htmlData = await htmlResponse.text();
                
                // Vérifier que ce n'est pas une page Google Drive générique
                if (htmlData.includes('Google Drive') && !htmlData.includes('<table')) {
                    console.log('[FOREPLAY-LOGIN] ⚠️ Page Google Drive détectée - tentative suivante');
                    continue;
                }
                
                console.log('[FOREPLAY-LOGIN] 📄 HTML récupéré, recherche de "foreplay"...');
                const result = parseHTMLForForeplay(htmlData);
                if (result) {
                    console.log('[FOREPLAY-LOGIN] ✅ Credentials trouvés via HTML !');
                    return result;
                }
            } else {
                console.log('[FOREPLAY-LOGIN] ❌ Erreur HTML:', htmlResponse.status);
            }
        } catch (error) {
            console.log('[FOREPLAY-LOGIN] ❌ Erreur lors de la récupération HTML:', error.message);
        }
    }
    
    // Si tout échoue
    console.log('[FOREPLAY-LOGIN] 💀 === ÉCHEC TOTAL ===');
    console.log('[FOREPLAY-LOGIN] Toutes les méthodes de récupération ont échoué');
    throw new Error('Impossible de récupérer les credentials Foreplay depuis Google Sheets');
}

// Attendre un élément dans le DOM
function waitFor(selector, timeout = 20000) {
    return new Promise((resolve, reject) => {
        const el = document.querySelector(selector);
        if (el) return resolve(el);
        const obs = new MutationObserver(() => {
            const found = document.querySelector(selector);
            if (found) {
                obs.disconnect();
                resolve(found);
            }
        });
        obs.observe(document.body, { childList: true, subtree: true });
        setTimeout(() => {
            obs.disconnect();
            reject(new Error(`Timeout sur "${selector}"`));
        }, timeout);
    });
}

// Auto‑login principal
async function autoLogin(credentials) {
    try {
        const { email, password } = credentials;
        console.log('[FOREPLAY-LOGIN] ▶ Credentials à utiliser:', email, '(password:', password.length, 'chars)');

        // Nouveaux sélecteurs pour la page de login Foreplay
        const emailSel = 'input[placeholder="Enter your email address"]';
        const passSel = 'input[placeholder="Enter your password"]';
        
        // Attendre et remplir l'email
        const emailInput = await waitFor(emailSel);
        emailInput.value = email;
        emailInput.dispatchEvent(new Event('input', { bubbles: true }));
        console.log('[FOREPLAY-LOGIN] ✅ Email saisi:', emailInput.value);
        
        // Attendre et remplir le mot de passe
        const passInput = await waitFor(passSel);
        passInput.value = password;
        passInput.dispatchEvent(new Event('input', { bubbles: true }));
        console.log('[FOREPLAY-LOGIN] ✅ Password saisi, longueur:', passInput.value.length);

        // Attendre le bouton "Sign In"
        let btn = null;
        const buttons = document.querySelectorAll('button[type="submit"]');
        for (const b of buttons) {
            if (b.textContent.trim().toLowerCase().includes('sign in')) {
                btn = b;
                break;
            }
        }
        if (!btn) btn = await waitFor('button[type="submit"]', 20000); // fallback
        if (btn.disabled) throw new Error('Bouton submit désactivé');
        
        console.log('[FOREPLAY-LOGIN] 🔘 Clic sur le bouton Sign In...');
        
        // Garder l'écran noir et surveiller si on quitte la page de login
        console.log('[FOREPLAY-LOGIN] 🖤 Écran noir maintenu - surveillance du changement de page...');
        monitorLoginSuccess();
        
        btn.click();

        console.log('[FOREPLAY-LOGIN] ✅ Formulaire soumis !');
    } catch (err) {
        console.error('[FOREPLAY-LOGIN] ❌ Auto-login échoué:', err);
        // En cas d'erreur, garder l'écran noir car on est probablement encore sur la page de login
        console.log('[FOREPLAY-LOGIN] 🖤 Écran noir maintenu suite à l\'erreur');
        throw err;
    }
}

// Essayer d'exécuter immédiatement
executeAutoLogin();

// Watcher sur les changements d'URL (SPA)
(function() {
    let lastUrl = location.href;
    const checkUrl = () => {
        if (location.href !== lastUrl) {
            lastUrl = location.href;
            executeAutoLogin();
        }
    };
    // Patch pushState et replaceState
    const pushState = history.pushState;
    history.pushState = function() {
        pushState.apply(this, arguments);
        window.dispatchEvent(new Event('locationchange'));
    };
    const replaceState = history.replaceState;
    history.replaceState = function() {
        replaceState.apply(this, arguments);
        window.dispatchEvent(new Event('locationchange'));
    };
    window.addEventListener('popstate', checkUrl);
    window.addEventListener('locationchange', checkUrl);
})();

// Configurer un MutationObserver pour détecter les changements dans le DOM
const foreplayObserver = new MutationObserver((mutations) => {
    executeAutoLogin();
});

// Observer les changements dans le document
foreplayObserver.observe(document, {
    childList: true,
    subtree: true
});

// Vérifier toutes les secondes au cas où
setInterval(executeAutoLogin, 1000);

// Écouter les messages du background script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'checkLoginPage') {
        sendResponse({ isLoginPage: window.location.href.startsWith('https://app.foreplay.co/login') });
    }
});
