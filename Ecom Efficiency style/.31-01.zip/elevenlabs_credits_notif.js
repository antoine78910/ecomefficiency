// =======================
// ElevenLabs Credits Notification
// =======================
// Détecte "Low credits" et affiche le temps restant avant le prochain refill
// Refill tous les 3 jours à partir du 19 octobre 2025 5h AM UTC+2

(function() {
    'use strict';
    // Silence all console output for this script (avoid leaking info / spam).
    try {
        const noop = function () {};
        console.log = noop;
        console.info = noop;
        console.warn = noop;
        console.error = noop;
        console.debug = noop;
        console.trace = noop;
        console.group = noop;
        console.groupCollapsed = noop;
        console.groupEnd = noop;
    } catch (_) {}

    // Configuration du refill
    const REFILL_START_DATE = new Date('2025-10-19T05:00:00+02:00'); // 19 octobre 2025 5h AM UTC+2
    const REFILL_INTERVAL_HOURS = 3 * 24; // 3 jours = 72 heures

    // Fonction pour calculer le temps restant avant le prochain refill
    function getNextRefillTime() {
        const now = new Date();
        const timeSinceStart = now - REFILL_START_DATE;
        
        if (timeSinceStart < 0) {
            // Si on est avant la date de début, retourner la date de début
            const timeUntilStart = Math.abs(timeSinceStart);
            const days = Math.floor(timeUntilStart / (1000 * 60 * 60 * 24));
            const hours = Math.floor((timeUntilStart % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((timeUntilStart % (1000 * 60 * 60)) / (1000 * 60));
            return { days, hours, minutes };
        }

        // Calculer combien de cycles de 3 jours se sont écoulés
        const millisInInterval = REFILL_INTERVAL_HOURS * 60 * 60 * 1000;
        const cyclesPassed = Math.floor(timeSinceStart / millisInInterval);
        
        // Calculer la date du prochain refill
        const nextRefillDate = new Date(REFILL_START_DATE.getTime() + (cyclesPassed + 1) * millisInInterval);
        
        // Calculer le temps restant en jours, heures et minutes
        const timeUntilRefill = nextRefillDate - now;
        const days = Math.floor(timeUntilRefill / (1000 * 60 * 60 * 24));
        const hours = Math.floor((timeUntilRefill % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((timeUntilRefill % (1000 * 60 * 60)) / (1000 * 60));
        
        return { days, hours, minutes };
    }

    // Fonction pour créer la notification personnalisée
    function createCustomNotification() {
        // Vérifier si la notification existe déjà
        if (document.getElementById('elevenlabs-custom-credits-notif')) {
            console.log('[ElevenLabs Credits] Custom notification already exists');
            return;
        }

        // Vérifier si l'utilisateur a déjà fermé la notification pour cette session
        const dismissedForSession = sessionStorage.getItem('elevenlabs_credits_notif_dismissed');
        if (dismissedForSession === '1') {
            console.log('[ElevenLabs Credits] Notification already dismissed for this session');
            return;
        }

        const timeUntilRefill = getNextRefillTime();
        console.log('[ElevenLabs Credits] Time until next refill:', timeUntilRefill);
        
        // Formater le timer
        let timerText = '';
        if (timeUntilRefill.days > 0) {
            timerText = `${timeUntilRefill.days}d ${timeUntilRefill.hours}h ${timeUntilRefill.minutes}m`;
        } else {
            timerText = `${timeUntilRefill.hours}h ${timeUntilRefill.minutes}m`;
        }

        // Créer la notification
        const notifDiv = document.createElement('div');
        notifDiv.id = 'elevenlabs-custom-credits-notif';
        notifDiv.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            width: 360px;
            background: #1a1a2e;
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(138, 43, 226, 0.4);
            z-index: 999999;
            color: white;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            animation: slideIn 0.3s ease-out;
        `;

        notifDiv.innerHTML = `
            <style>
                @keyframes slideIn {
                    from {
                        transform: translateX(100px);
                        opacity: 0;
                    }
                    to {
                        transform: translateX(0);
                        opacity: 1;
                    }
                }
                
                #elevenlabs-custom-credits-notif .close-btn {
                    position: absolute;
                    top: 12px;
                    right: 12px;
                    background: transparent;
                    border: 1px solid rgba(138, 43, 226, 0.3);
                    color: rgba(138, 43, 226, 0.8);
                    width: 28px;
                    height: 28px;
                    border-radius: 6px;
                    cursor: pointer;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    transition: all 0.2s ease;
                    font-size: 18px;
                    font-weight: 600;
                }
                
                #elevenlabs-custom-credits-notif .close-btn:hover {
                    background: rgba(138, 43, 226, 0.15);
                    border-color: rgba(138, 43, 226, 0.6);
                    color: rgba(138, 43, 226, 1);
                }
                
                #elevenlabs-custom-credits-notif .timer {
                    font-size: 42px;
                    font-weight: 700;
                    margin: 15px 0;
                    color: #a78bfa;
                }
                
                #elevenlabs-custom-credits-notif .label {
                    font-size: 13px;
                    opacity: 0.7;
                    margin-bottom: 8px;
                    letter-spacing: 0.3px;
                    text-transform: uppercase;
                    font-size: 11px;
                }
                
                #elevenlabs-custom-credits-notif .section {
                    background: rgba(138, 43, 226, 0.08);
                    border: 1px solid rgba(138, 43, 226, 0.2);
                    border-radius: 8px;
                    padding: 14px;
                    margin-top: 18px;
                }
                
                #elevenlabs-custom-credits-notif .section-title {
                    font-size: 14px;
                    font-weight: 600;
                    margin-bottom: 10px;
                    opacity: 0.9;
                }
                
                #elevenlabs-custom-credits-notif .upgrade-btn {
                    background: #8b5cf6;
                    color: white;
                    border: none;
                    padding: 10px 20px;
                    border-radius: 6px;
                    font-weight: 600;
                    cursor: pointer;
                    width: 100%;
                    margin-top: 8px;
                    transition: background 0.2s ease;
                    font-size: 13px;
                }
                
                #elevenlabs-custom-credits-notif .upgrade-btn:hover {
                    background: #7c3aed;
                }
                
                #elevenlabs-custom-credits-notif .warning {
                    background: rgba(138, 43, 226, 0.05);
                    border: 1px solid rgba(138, 43, 226, 0.15);
                    border-radius: 6px;
                    padding: 10px;
                    font-size: 11px;
                    margin-top: 12px;
                    display: flex;
                    align-items: center;
                    gap: 8px;
                    line-height: 1.4;
                    opacity: 0.85;
                }
                
                #elevenlabs-custom-credits-notif .warning-icon {
                    font-size: 14px;
                    flex-shrink: 0;
                }
            </style>
            
            <button class="close-btn" id="close-credits-notif" title="Close">×</button>
            
            <div style="font-size: 24px; font-weight: 700; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; justify-content: center;">
                <span style="font-size: 28px;">⚠️</span>
                <span>No More Credits</span>
            </div>
            
            <div class="label">Next refill in</div>
            <div class="timer">${timerText}</div>
            
            <div class="section">
                <div class="section-title">💎 Want more credits?</div>
                <button class="upgrade-btn" id="upgrade-pro-btn">Upgrade to Pro</button>
            </div>
            
            <div class="warning">
                <span class="warning-icon">⚠️</span>
                <span><strong>Important:</strong> Connect and open the link in your own browser</span>
            </div>
        `;

        document.body.appendChild(notifDiv);
        console.log('[ElevenLabs Credits] Custom notification created');

        // Ajouter les event listeners
        const closeBtn = document.getElementById('close-credits-notif');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                // Marquer comme dismissed pour cette session uniquement
                sessionStorage.setItem('elevenlabs_credits_notif_dismissed', '1');
                console.log('[ElevenLabs Credits] Notification dismissed for this session');
                
                notifDiv.style.animation = 'slideInRight 0.3s ease-in reverse';
                setTimeout(() => {
                    notifDiv.remove();
                    console.log('[ElevenLabs Credits] Notification closed');
                }, 300);
            });
        }

        const upgradeBtn = document.getElementById('upgrade-pro-btn');
        if (upgradeBtn) {
            upgradeBtn.addEventListener('click', () => {
                window.open('https://ecomefficiency.com/?via=adspower', '_blank');
                console.log('[ElevenLabs Credits] Upgrade button clicked - Opening ecomefficiency.com/?via=adspower');
            });
        }

        // Ne plus auto-fermer - l'utilisateur doit cliquer sur la croix
        // setTimeout(() => {
        //     if (document.getElementById('elevenlabs-custom-credits-notif')) {
        //         notifDiv.style.animation = 'slideInRight 0.3s ease-in reverse';
        //         setTimeout(() => {
        //             notifDiv.remove();
        //             console.log('[ElevenLabs Credits] Notification auto-closed after 30s (will show again on next page load)');
        //         }, 300);
        //     }
        // }, 30000);
    }

    // Trouver le petit bouton "Upgrade" (ou équivalent)
    function hasSmallUpgradeButton() {
        try {
            // Candidats: a, button, [role=button]
            const nodes = Array.from(document.querySelectorAll('a, button, [role="button"]'));
            for (let i = 0; i < nodes.length; i++) {
                const el = nodes[i];
                if (!el || !el.isConnected) continue;
                const text = (el.textContent || '').trim().toLowerCase();
                if (!text) continue;
                // Cible un court libellé "upgrade" (pas les phrases longues)
                const isShortUpgrade = (text === 'upgrade' || text === 'upgrade now' || text === 'upgrade→' || text === 'upgrade →' || (text.includes('upgrade') && text.length <= 12));
                if (!isShortUpgrade) continue;

                // Écarter de faux positifs: boutons d'upsell larges avec long libellé
                if (text.length > 16) continue;

                // Vérifier quelques indices d'upgrade: href ou data attribs
                const href = (el.getAttribute && el.getAttribute('href')) || '';
                const ariaLabel = (el.getAttribute && el.getAttribute('aria-label')) || '';
                const isLikelyUpgrade = /upgrade|pricing|plan|billing|subscribe/i.test(href || '') || /upgrade/i.test(ariaLabel || '');

                if (isLikelyUpgrade) {
                    // Optionnel: ignorer si caché/invisible
                    const cs = window.getComputedStyle ? getComputedStyle(el) : null;
                    if (cs && (cs.display === 'none' || cs.visibility === 'hidden' || Number(cs.opacity) === 0)) continue;
                    const r = el.getBoundingClientRect();
                    if (r.width <= 0 || r.height <= 0) continue;
                    return true;
                }
            }
        } catch (_) {}
        return false;
    }

    // Détection précise de la bannière "Low credits" (HTML fourni)
    function isLowCreditsBannerVisible() {
        try {
            // 1) Bouton de fermeture avec aria-label exact
            const dismissBtn = document.querySelector('button[aria-label="Dismiss low credits warning"]');
            if (dismissBtn) return true;

            // 2) Libellé "Low credits" avec classes communes
            const lowCreditsLabels = Array.from(document.querySelectorAll('p.text-sm.text-foreground.font-medium.line-clamp-1'));
            if (lowCreditsLabels.some(p => (p.textContent || '').trim().toLowerCase() === 'low credits')) {
                return true;
            }

            // 3) Fallback: barre stylée contenant "Low credits" + bouton Upgrade
            const bars = Array.from(document.querySelectorAll('div.bg-gray-alpha-50.border-gray-alpha-200.border'));
            for (const bar of bars) {
                const hasUpgrade = Array.from(bar.querySelectorAll('button')).some(b => (b.textContent || '').trim().toLowerCase() === 'upgrade');
                const hasLowCredits = Array.from(bar.querySelectorAll('p')).some(p => (p.textContent || '').trim().toLowerCase() === 'low credits');
                if (hasUpgrade && hasLowCredits) return true;
            }
        } catch (_) {}
        return false;
    }

    function removeCustomNotification() {
        const notif = document.getElementById('elevenlabs-custom-credits-notif');
        if (notif) {
            try { notif.remove(); } catch (_) {}
            console.log('[ElevenLabs Credits] Existing notification removed (no small upgrade button)');
        }
    }

    function detectLowCreditsNotification() {
        // Afficher uniquement quand la bannière "Low credits" spécifique est présente
        const show = isLowCreditsBannerVisible();
        console.log('[ElevenLabs Credits] isLowCreditsBannerVisible =', show);
        if (show) {
            createCustomNotification();
            return true;
        }
        removeCustomNotification();
        return false;
    }

    // Observer les changements du DOM pour détecter l'apparition de la notification
    const observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
            if (mutation.addedNodes.length > 0) {
                // Attendre un peu que le DOM soit stable
                setTimeout(() => {
                    detectLowCreditsNotification();
                }, 100);
                break;
            }
        }
    });

    // Démarrer l'observation
    function startObserving() {
        if (document.body) {
            observer.observe(document.body, {
                childList: true,
                subtree: true
            });
            console.log('[ElevenLabs Credits] Observer started');
            
            // Faire une première vérification et un polling léger
            setTimeout(() => { detectLowCreditsNotification(); }, 1000);
            let tries = 0;
            const poll = setInterval(() => {
                tries++;
                const shown = detectLowCreditsNotification();
                if (shown || tries > 40) { // ~20s
                    clearInterval(poll);
                }
            }, 500);
        } else {
            setTimeout(startObserving, 100);
        }
    }

    // Attendre que le DOM soit prêt
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', startObserving);
    } else {
        startObserving();
    }

    console.log('[ElevenLabs Credits] Initialization complete');

})();

