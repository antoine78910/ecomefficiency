// remove_dropship_banner.js
(function() {
  // Exécute sur toutes les pages de dropship.io
  if (!window.location.href.startsWith('https://app.dropship.io/')) return;

  // IMPORTANT:
  // Dropship is a SPA; aggressive DOM removal / heavy polling can destabilize it and cause dashboard↔login loops.
  // This script now uses CSS-only hiding (very low risk) + a lightweight observer to re-apply once.

  const STYLE_ID = 'ee-dropship-hide-style';

  function ensureStyle() {
    try {
      if (document.getElementById(STYLE_ID)) return;
      const style = document.createElement('style');
      style.id = STYLE_ID;
      style.textContent = `
        /* Limited banner */
        div.limited-banner { display: none !important; }

        /* Common "upgrade" button classes (safe to hide) */
        .main-sidebar-free-button,
        .free-button {
          display: none !important;
          visibility: hidden !important;
          pointer-events: none !important;
        }
      `;
      (document.head || document.documentElement).appendChild(style);
    } catch (_) {}
  }

  function start() {
    ensureStyle();
    try {
      const mo = new MutationObserver(() => { try { ensureStyle(); } catch (_) {} });
      mo.observe(document.documentElement, { childList: true, subtree: true });
      setTimeout(() => { try { mo.disconnect(); } catch (_) {} }, 120000);
    } catch (_) {}
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
})();
