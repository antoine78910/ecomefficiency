// auto_logout_11.js

(function() {
    'use strict';

    // IMPORTANT:
    // This script used to auto-logout on *every* /app page load, which breaks normal UI
    // (ex: profile/credits popups stop working because we keep clicking/redirecting).
    // We now only auto-logout when we detect a real blocking/paywall modal.
    function shouldAutoLogoutNow() {
        try {
            const hostOk = location.hostname.endsWith('elevenlabs.io');
            const pathOk = location.pathname.startsWith('/app');
            if (!hostOk || !pathOk) return false;

            // Detect common blocking/paywall messages in dialogs/toasts
            const nodes = Array.from(document.querySelectorAll('[role="dialog"], [aria-modal="true"], [data-radix-dialog-content], .Toastify, [data-sonner-toaster]'))
                .slice(0, 80);
            const hay = nodes.map(n => (n && (n.textContent || '') || '').toLowerCase()).join(' ');
            if (!hay) return false;

            return (
                hay.includes('free trial') ||
                hay.includes('trial expired') ||
                hay.includes('subscription expired') ||
                hay.includes('payment failed') ||
                hay.includes('payment required') ||
                hay.includes('billing') ||
                hay.includes('upgrade to') ||
                hay.includes('upgrade')
            );
        } catch (_) {
            return false;
        }
    }

    // If no blocking modal is present, do nothing.
    // (Keeps the ElevenLabs UI usable, including quota/credits popups.)
    if (!shouldAutoLogoutNow()) return;

    // Helpers visibilité / click
    function isElementVisible(el) {
        if (!el) return false;
        const cs = getComputedStyle(el);
        if (cs.visibility === 'hidden' || cs.display === 'none' || Number(cs.opacity) === 0) return false;
        const r = el.getBoundingClientRect();
        return r.width > 0 && r.height > 0;
    }

    function humanLikeClick(el) {
        if (!el) return;
        try { el.scrollIntoView({ block: 'center' }); } catch {}
        const ev = { bubbles: true, cancelable: true, view: window };
        try { el.dispatchEvent(new PointerEvent('pointerover', ev)); } catch {}
        try { el.dispatchEvent(new PointerEvent('pointerenter', ev)); } catch {}
        try { el.dispatchEvent(new PointerEvent('mouseover', ev)); } catch {}
        try { el.dispatchEvent(new PointerEvent('mousemove', ev)); } catch {}
        try { el.dispatchEvent(new PointerEvent('pointerdown', ev)); } catch {}
        try { el.dispatchEvent(new PointerEvent('mousedown', ev)); } catch {}
        try { el.dispatchEvent(new PointerEvent('pointerup', ev)); } catch {}
        try { el.dispatchEvent(new PointerEvent('mouseup', ev)); } catch {}
        try { el.dispatchEvent(new PointerEvent('click', ev)); } catch {}
        try { el.click(); } catch {}
    }

    function delay(ms) { return new Promise(r => setTimeout(r, ms)); }

    // Fonction pour attendre la présence d'un élément dans le DOM
    function waitForElement(selector, timeout = 10000) {
        return new Promise((resolve, reject) => {
            const observer = new MutationObserver((mutations) => {
                const element = document.querySelector(selector);
                if (element) {
                    observer.disconnect();
                    resolve(element);
                }
            });

            observer.observe(document.body, {
                childList: true,
                subtree: true
            });

            // Vérifier immédiatement si l'élément existe
            const element = document.querySelector(selector);
            if (element) {
                observer.disconnect();
                resolve(element);
            }

            // Timeout si l'élément n'est pas trouvé
            setTimeout(() => {
                observer.disconnect();
                reject(new Error('Element not found'));
            }, timeout);
        });
    }

    // Attendre le premier élément qui matche parmi plusieurs sélecteurs
    function waitForOneOf(selectors, timeout = 12000) {
        return new Promise((resolve, reject) => {
            const pick = () => selectors.map(s => document.querySelector(s)).find(Boolean);
            const immediate = pick();
            if (immediate) return resolve(immediate);

            const obs = new MutationObserver(() => {
                const el = pick();
                if (el) {
                    obs.disconnect();
                    resolve(el);
                }
            });
            obs.observe(document.body, { childList: true, subtree: true, attributes: true });
            const t = setTimeout(() => {
                obs.disconnect();
                reject(new Error('Element not found for any selector: ' + selectors.join(', ')));
            }, timeout);
        });
    }

    function findButtonByText(regex) {
        const btns = Array.from(document.querySelectorAll('button'));
        return btns.find(b => regex.test((b.textContent || '').trim()));
    }

    function findClickableByText(textRegex) {
        const nodes = Array.from(document.querySelectorAll('button, a, [role="button"], [role="menuitem"], div[role="menuitem"], li[role="menuitem"]'));
        for (const el of nodes) {
            if (!isElementVisible(el)) continue;
            const txt = ((el.innerText || el.textContent || '').trim());
            if (textRegex.test(txt)) return el;
        }
        return null;
    }

    // Injection dans le contexte page pour capter les navigations SPA réelles
    function injectHistoryHook() {
        try {
            const script = document.createElement('script');
            script.textContent = `(() => {
                if (window.__el_history_hook_installed) return; 
                window.__el_history_hook_installed = true;
                const notify = () => { try { window.dispatchEvent(new Event('el:navigation')); } catch {}
                };
                const ps = history.pushState; 
                history.pushState = function() { const r = ps.apply(this, arguments); notify(); return r; };
                const rs = history.replaceState; 
                history.replaceState = function() { const r = rs.apply(this, arguments); notify(); return r; };
                window.addEventListener('popstate', notify);
                const ofetch = window.fetch; 
                window.fetch = function() { return ofetch.apply(this, arguments).then((res) => { try { notify(); } catch {} return res; }); };
                const open = XMLHttpRequest.prototype.open;
                XMLHttpRequest.prototype.open = function() { this.addEventListener('load', () => { try { notify(); } catch {} }); return open.apply(this, arguments); };
                // Mutations DOM significatives
                const mo = new MutationObserver(() => notify());
                try { mo.observe(document.documentElement, { childList: true, subtree: true }); } catch {}
            })();`;
            (document.documentElement || document.head || document.body).appendChild(script);
            script.remove();
        } catch {}
    }

    // Fonction principale pour la déconnexion
    async function autoLogout() {
        try {
            if (sessionStorage.getItem('el_logout_done') === '1') return;
            if (!(location.hostname.endsWith('elevenlabs.io') && location.pathname.startsWith('/app'))) return;

            console.log('[EL LOGOUT] Début séquence sur', location.href);

            // 1) Ouvrir le menu profil (FR/EN) avec sélecteurs élargis et fallback texte
            let profileButton = null;
            try {
                profileButton = await waitForOneOf([
                    'button[aria-label="Your profile"]',
                    'button[aria-label="Votre profil"]',
                    'button[aria-label*="profile" i]',
                    'button[aria-label*="profil" i]'
                ], 10000);
            } catch (_) {}
            if (!profileButton) {
                profileButton = findClickableByText(/Mon compte|My account|Votre profil|Your profile|Account|Profil|Profile|Avatar/i);
            }
            if (!profileButton) throw new Error('Profile button not found');
            console.log('[EL LOGOUT] Bouton profil trouvé, clic');
            humanLikeClick(profileButton);
            await delay(300);

            // 2) Cliquer sur "Se déconnecter" (FR/EN) avec recherche large
            let logoutButton = null;
            try {
                logoutButton = await waitForOneOf([
                    '[aria-label="Sign out"]',
                    '[aria-label="Se déconnecter"]',
                    '[title*="Sign out" i]',
                    '[title*="déconnect" i]'
                ], 8000);
            } catch (_) {}
            if (!logoutButton) {
                logoutButton = findClickableByText(/Se déconnecter|Sign out|Log out|Déconnexion/i);
            }
            if (!logoutButton) throw new Error('Logout button not found');
            console.log('[EL LOGOUT] Bouton déconnexion trouvé, clic');
            humanLikeClick(logoutButton);

            sessionStorage.setItem('el_logout_done', '1');

            // 3) Recharger la page après 5s pour déclencher l'auto-login
            console.log('[EL LOGOUT] Déconnexion cliquée, reload dans 5s');
            setTimeout(() => {
                // Ne pas effacer le flag pour éviter toute boucle
                location.reload();
            }, 5000);
        } catch (error) {
            console.error('[EL LOGOUT] Erreur lors de la déconnexion:', error);
            // Nouvelle tentative légère après 2s si pas réussi
            setTimeout(() => {
                try { sessionStorage.removeItem('el_logout_done'); } catch {}
                autoLogout();
            }, 2000);
        }
    }

    // Exécuter la déconnexion automatique
    autoLogout();

    // Support des navigations SPA (pushState/replaceState) pour relancer l'auto-logout après redirection interne
    try {
        if (!window.__el_logout_hooks_installed) {
            window.__el_logout_hooks_installed = true;
            injectHistoryHook();
            let lastUrl = location.href;
            let debounceTimer = null;
            const runDebounced = () => {
                if (debounceTimer) clearTimeout(debounceTimer);
                debounceTimer = setTimeout(() => {
                    try { autoLogout(); } catch {}
                }, 250);
            };
            const triggerIfChanged = () => {
                const current = location.href;
                if (current !== lastUrl) {
                    lastUrl = current;
                    // Petite latence pour laisser le DOM se mettre à jour
                    // Ne pas effacer le flag ici pour éviter les re-déclenchements
                    runDebounced();
                }
            };

            const originalPushState = history.pushState;
            history.pushState = function() {
                const ret = originalPushState.apply(this, arguments);
                try { triggerIfChanged(); } catch {}
                return ret;
            };

            const originalReplaceState = history.replaceState;
            history.replaceState = function() {
                const ret = originalReplaceState.apply(this, arguments);
                try { triggerIfChanged(); } catch {}
                return ret;
            };

            window.addEventListener('popstate', triggerIfChanged);
            window.addEventListener('el:navigation', triggerIfChanged);
            // Observer DOM pour transitions React/Next
            try {
                const domObserver = new MutationObserver(() => {
                    if (location.hostname.endsWith('elevenlabs.io') && location.pathname.startsWith('/app')) {
                        runDebounced();
                    }
                });
                domObserver.observe(document.body, { childList: true, subtree: true });
            } catch {}
            // Fallback: polling léger au cas où l'app modifie la location sans History API
            setInterval(triggerIfChanged, 250);
        }
    } catch (_) {}

})();
