// Higgsfield EcomEfficiency: vérification abonnement + limite 100 crédits/jour + widget
(function () {
  'use strict';
  try { console.log('[EE-HF-Ecom] script loaded', location.href); } catch (_) {}

  const host = (location.hostname || '').toLowerCase();
  if (host !== 'higgsfield.ai' && host !== 'www.higgsfield.ai') return;
  if ((location.pathname || '').startsWith('/auth')) return;

  const CONFIG = window.EE_HIGGSFIELD_ECOM_CONFIG || {
    API_BASE_URL: 'https://your-ecomefficiency-api.vercel.app',
    VERIFY_SUBSCRIPTION_PATH: '/api/verify-subscription',
    DAILY_CREDIT_LIMIT: 100
  };
  // Mode test: simuler connexion = pas de popup email, tracking crédits + logs détaillés
  const SIMULATE_CONNECTED = !!(window.EE_HIGGSFIELD_ECOM_CONFIG && window.EE_HIGGSFIELD_ECOM_CONFIG.SIMULATE_CONNECTED);

  const WALLET_URL = 'https://fnf.higgsfield.ai/workspaces/wallet';
  const STORAGE_PREFIX = 'ee_hf_ecom_';
  const SESSION_VERIFIED_EMAIL = STORAGE_PREFIX + 'verified_email';
  const SESSION_VERIFIED_AT = STORAGE_PREFIX + 'verified_at';
  const LS_DAILY_USAGE = STORAGE_PREFIX + 'daily_usage'; // JSON: { "2025-02-21": 45, ... }
  const POPUP_SHOWN_KEY = STORAGE_PREFIX + 'popup_shown';

  const DEBUG = true;
  const _console = (typeof console !== 'undefined' && console.__ee_original__) ? console.__ee_original__ : (typeof console !== 'undefined' ? console : { log: function () {} });
  function log(...a) { if (DEBUG) try { _console.log.apply(_console, ['[EE-HF-Ecom]'].concat(Array.prototype.slice.call(a))); } catch (_) {} }

  // --- Storage ---
  function getVerifiedEmail() { try { return sessionStorage.getItem(SESSION_VERIFIED_EMAIL); } catch (_) { return null; } }
  function setVerifiedEmail(email) { try { sessionStorage.setItem(SESSION_VERIFIED_EMAIL, email || ''); sessionStorage.setItem(SESSION_VERIFIED_AT, String(Date.now())); } catch (_) {} }
  function getDailyUsage() {
    try {
      const raw = localStorage.getItem(LS_DAILY_USAGE);
      const o = raw ? JSON.parse(raw) : {};
      return typeof o === 'object' ? o : {};
    } catch (_) { return {}; }
  }
  function setDailyUsage(usage) { try { localStorage.setItem(LS_DAILY_USAGE, JSON.stringify(usage)); } catch (_) {} }
  function getTodayKey() { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
  function getUsedToday() { const u = getDailyUsage(); return u[getTodayKey()] || 0; }
  function addUsedToday(delta) { const u = getDailyUsage(); const k = getTodayKey(); u[k] = (u[k] || 0) + delta; setDailyUsage(u); }

  // --- Token JWT Higgsfield (Clerk) : POST /tokens + capture depuis les requêtes ---
  const CLERK_BASE = 'https://clerk.higgsfield.ai';
  const CLERK_TOKENS_PATH = '/v1/client/sessions';
  let capturedBearerToken = null;
  let capturedSessionId = null;

  function getSessionIdFromStorage() {
    try {
      const keys = [];
      for (let i = 0; i < localStorage.length; i++) keys.push(localStorage.key(i));
      for (let i = 0; i < keys.length; i++) {
        const k = keys[i];
        if (!k || k.indexOf('clerk') === -1) continue;
        const raw = localStorage.getItem(k);
        if (!raw) continue;
        try {
          const obj = JSON.parse(raw);
          const sid = (obj && (obj.session_id || obj.sessionId || obj.id || (obj.session && (obj.session.id || obj.session_id))));
          if (sid && typeof sid === 'string' && sid.indexOf('sess_') === 0) return sid;
          if (obj && obj.sessions && obj.sessions[0]) return obj.sessions[0].id || obj.sessions[0];
        } catch (_) {}
      }
    } catch (_) {}
    try {
      const c = document.cookie || '';
      const clientCookie = c.split(';').map(function (x) { return x.trim(); }).find(function (x) { return x.indexOf('__client=') === 0; });
      if (clientCookie) {
        const val = decodeURIComponent(clientCookie.split('=').slice(1).join('='));
        try {
          const obj = JSON.parse(val);
          const sid = (obj && (obj.session_id || obj.sessionId || (obj.session && obj.session.id)));
          if (sid && typeof sid === 'string') return sid;
        } catch (_) {
          try {
            const obj = JSON.parse(atob(val.replace(/-/g, '+').replace(/_/g, '/')));
            if (obj && obj.session_id) return obj.session_id;
          } catch (_) {}
        }
      }
    } catch (_) {}
    return null;
  }

  function getSessionId() {
    if (capturedSessionId) return capturedSessionId;
    try {
      if (typeof window.Clerk !== 'undefined' && window.Clerk.session && window.Clerk.session.id) return window.Clerk.session.id;
    } catch (_) {}
    return getSessionIdFromStorage();
  }

  /** Récupère un token JWT frais via POST Clerk /sessions/{id}/tokens (credentials: 'include') */
  function getFreshTokenFromClerk() {
    const sessionId = getSessionId();
    if (!sessionId) {
      log('getFreshTokenFromClerk: pas de session ID (attendre une requête Clerk ou être connecté)');
      return Promise.resolve(null);
    }
    const url = CLERK_BASE + CLERK_TOKENS_PATH + '/' + encodeURIComponent(sessionId) + '/tokens?__clerk_api_version=2025-11-10';
    log('POST Clerk tokens pour session', sessionId);
    const f = origFetch || window.fetch;
    function tryMethod(method) {
      return f(url, {
        method: method,
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' }
      }).then(function (r) {
        if (!r.ok) { log('Clerk tokens', method, r.status); return null; }
        var authHeader = r.headers && (r.headers.get ? r.headers.get('Authorization') : r.headers['Authorization']);
        if (authHeader && typeof authHeader === 'string' && authHeader.indexOf('Bearer ') === 0) {
          capturedBearerToken = authHeader.slice(7).trim();
          log('Token frais Clerk (header Authorization), len=' + capturedBearerToken.length);
          return capturedBearerToken;
        }
        return r.json().then(function (data) {
          const token = (data && (data.jwt || data.token || data.data && (data.data.jwt || data.data.token)));
          if (token && typeof token === 'string') {
            capturedBearerToken = token;
            log('Token frais Clerk (body), len=' + token.length);
            return token;
          }
          return null;
        });
      }).catch(function (e) { log('Clerk tokens error', e && e.message); return null; });
    }
    return tryMethod('POST').then(function (t) { return t || tryMethod('GET'); });
  }

  function getTokenFromClientCookie() {
    try {
      const cookies = (document.cookie || '').split(';').map(function (c) { return c.trim(); });
      for (let i = 0; i < cookies.length; i++) {
        if (cookies[i].indexOf('__client=') !== 0) continue;
        const raw = cookies[i].split('=').slice(1).join('=').trim();
        let decoded;
        try { decoded = decodeURIComponent(raw); } catch (_) { decoded = raw; }
        if (!decoded) continue;
        if (decoded.length > 50 && decoded.indexOf('eyJ') === 0 && (decoded.match(/\./g) || []).length >= 2) {
          try { JSON.parse(atob(decoded.split('.')[1])); return decoded; } catch (_) {}
        }
        try {
          const obj = JSON.parse(decoded);
          const t = (obj && (obj.token || obj.__token || obj.jwt || obj.lastToken || obj.session && obj.session.lastToken));
          if (t) return typeof t === 'string' ? t : (t && t.token ? t.token : null);
        } catch (_) {}
        try {
          const b64 = atob(decoded.replace(/-/g, '+').replace(/_/g, '/'));
          const obj = JSON.parse(b64);
          const t = (obj && (obj.token || obj.__token || obj.jwt));
          if (t) return typeof t === 'string' ? t : null;
        } catch (_) {}
        if (decoded.length > 100) return decoded;
      }
    } catch (_) {}
    return null;
  }

  function getJwt() {
    if (capturedBearerToken) return capturedBearerToken;
    const fromClient = getTokenFromClientCookie();
    if (fromClient) { log('token from cookie __client, len=' + fromClient.length); return fromClient; }
    try {
      const c = document.cookie || '';
      const match = c.match(/(?:^|;\s*)__session=([^;]+)/) || c.match(/(?:^|;\s*)__clerk_db_jwt=([^;]+)/);
      if (match && match[1]) { log('token from __session/__clerk_db_jwt'); return decodeURIComponent(match[1].trim()); }
    } catch (_) {}
    return null;
  }

  function getJwtAsync() {
    const sync = getJwt();
    if (sync) return Promise.resolve(sync);
    return getFreshTokenFromClerk().then(function (t) {
      if (t) return t;
      if (typeof window.Clerk !== 'undefined' && window.Clerk.session && typeof window.Clerk.session.getToken === 'function') {
        return Promise.resolve(window.Clerk.session.getToken()).then(function (t2) { return t2 || null; }).catch(function () { return null; });
      }
      return null;
    });
  }

  // --- Interception de TOUTES les requêtes (logs + capture session ID + Bearer + wallet) ---
  let origFetch = null;
  function installFetchInterceptor() {
    origFetch = window.fetch;
    if (!origFetch) return;
    window.fetch = function (input, init) {
      const url = typeof input === 'string' ? input : (input && input.url);
      const method = (init && init.method) || 'GET';
      const u = typeof url === 'string' ? url : (url && url.url) || '';
      log('HTTP', method, u);

      if (u.indexOf('clerk') !== -1 && u.indexOf('/sessions/') !== -1) {
        const m = u.match(/\/sessions\/(sess_[a-zA-Z0-9_]+)/);
        if (m && m[1]) { capturedSessionId = m[1]; log('Session ID capturé:', capturedSessionId); }
      }

      const headers = init && init.headers;
      let authHeader = null;
      if (headers) {
        if (typeof headers.get === 'function') authHeader = headers.get('Authorization');
        else if (headers.Authorization) authHeader = headers.Authorization;
        else if (headers.authorization) authHeader = headers.authorization;
      }
      if (authHeader && typeof authHeader === 'string' && authHeader.indexOf('Bearer ') === 0) {
        capturedBearerToken = authHeader.slice(7).trim();
        log('Token Bearer capturé (longueur ' + capturedBearerToken.length + ')');
      }

      return origFetch.apply(this, arguments).then(function (res) {
        if (u.indexOf('fnf.higgsfield.ai') !== -1) {
          log('HTTP RESPONSE', res.status, method, u);
          if (u.indexOf('workspaces/wallet') !== -1 && res.ok) {
            const clone = res.clone();
            clone.json().then(function (data) {
              log('wallet data', data);
              const raw = data && (data.balance ?? data.credits ?? data.available ?? (data.wallet && (data.wallet.balance ?? data.wallet.credits)));
              const num = typeof raw === 'number' ? raw : (typeof raw === 'string' ? parseInt(raw, 10) : null);
              if (num !== null) {
                const prev = lastBalance;
                lastBalance = num;
                if (prev !== null && prev !== num && num < prev) {
                  const delta = prev - num;
                  if (delta > 0) { addUsedToday(delta); lastDelta = delta; log('credits spent (intercept): delta=' + delta + ', usedToday=' + getUsedToday()); }
                }
              }
            }).catch(function () {});
          }
        }
        if (u.indexOf('clerk') !== -1 && u.indexOf('/tokens') !== -1 && res.ok && (method === 'POST' || method === 'GET')) {
          var authHeader = res.headers && (res.headers.get ? res.headers.get('Authorization') : res.headers['Authorization']);
          if (authHeader && typeof authHeader === 'string' && authHeader.indexOf('Bearer ') === 0) {
            capturedBearerToken = authHeader.slice(7).trim();
            log('Token capturé (réponse Clerk header Authorization), len=' + capturedBearerToken.length);
          } else {
            const clone = res.clone();
            clone.json().then(function (data) {
              const token = (data && (data.jwt || data.token || data.data && (data.data.jwt || data.data.token)));
              if (token && typeof token === 'string') {
                capturedBearerToken = token;
                log('Token capturé (réponse Clerk body), len=' + token.length);
              }
            }).catch(function () {});
          }
        }
        return res;
      });
    };
    log('fetch interceptor installed (toutes requêtes loggées, Bearer capturé)');

    if (typeof XMLHttpRequest !== 'undefined') {
      const OrigXHR = XMLHttpRequest;
      window.XMLHttpRequest = function () {
        const xhr = new OrigXHR();
        const origOpen = xhr.open;
        xhr.open = function (method, url) {
          log('XHR', method, url);
          return origOpen.apply(this, arguments);
        };
        const origSetRequestHeader = xhr.setRequestHeader;
        xhr.setRequestHeader = function (name, value) {
          if (String(name).toLowerCase() === 'authorization' && String(value).indexOf('Bearer ') === 0) {
            capturedBearerToken = value.slice(7).trim();
            log('Token Bearer capturé (XHR), len=' + capturedBearerToken.length);
          }
          return origSetRequestHeader.apply(this, arguments);
        };
        return xhr;
      };
      log('XHR interceptor installed');
    }
  }

  // --- Wallet : origFetch + credentials + timeout 12s ---
  const WALLET_FETCH_TIMEOUT_MS = 12000;
  function fetchWallet(token) {
    const f = origFetch || window.fetch;
    var controller = null;
    var timeoutId = null;
    if (typeof AbortController !== 'undefined') {
      controller = new AbortController();
      timeoutId = setTimeout(function () { if (controller) controller.abort(); }, WALLET_FETCH_TIMEOUT_MS);
    }
    var opts = {
      method: 'GET',
      credentials: 'include',
      headers: { 'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json' },
      signal: controller ? controller.signal : undefined
    };
    return f(WALLET_URL, opts).then(function (r) {
      if (timeoutId) clearTimeout(timeoutId);
      if (!r.ok) throw new Error('Wallet ' + r.status);
      return r.json();
    }).catch(function (err) {
      if (timeoutId) clearTimeout(timeoutId);
      throw err;
    });
  }

  // --- Backend: verify subscription ---
  function verifySubscription(email) {
    const base = (CONFIG.API_BASE_URL || '').replace(/\/$/, '');
    const path = (CONFIG.VERIFY_SUBSCRIPTION_PATH || '/api/verify-subscription').replace(/^\//, '');
    const url = base + '/' + path + (path.indexOf('?') >= 0 ? '&' : '?') + 'email=' + encodeURIComponent(email);
    return fetch(url, { method: 'GET', credentials: 'omit' })
      .then(function (r) {
        if (r.status === 401 || r.status === 404) return { ok: false };
        return r.json().then(function (data) { return data; }, function () { return { ok: r.ok }; });
      })
      .then(function (data) {
        const ok = !!(data && (data.ok === true || data.subscribed === true));
        return { ok, data };
      })
      .catch(function () { return { ok: false }; });
  }

  // --- Popup UI (demande email à chaque nouvelle ouverture) ---
  function shouldShowPopup() {
    if (SIMULATE_CONNECTED) return false;
    if (getVerifiedEmail()) return false;
    return true;
  }

  function createPopup() {
    if (document.getElementById('ee-hf-ecom-popup-root')) return;
    const root = document.createElement('div');
    root.id = 'ee-hf-ecom-popup-root';
    Object.assign(root.style, {
      position: 'fixed', top: '0', left: '0', right: '0', bottom: '0',
      zIndex: 2147483646, display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: 'rgba(0,0,0,0.6)', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
    });
    const box = document.createElement('div');
    box.className = 'ee-hf-ecom-popup-box';
    Object.assign(box.style, {
      background: '#1a1a1a', color: '#fff', padding: '24px', borderRadius: '12px',
      minWidth: '320px', maxWidth: '90vw', boxShadow: '0 10px 40px rgba(0,0,0,0.5)'
    });
    box.innerHTML = '<div style="font-weight:700;margin-bottom:8px;">Ecom Efficiency – Higgsfield</div>' +
      '<p style="margin:0 0 12px;font-size:14px;opacity:0.9;">Entrez l’email avec lequel vous avez souscrit à l’abonnement (vérification Stripe/Supabase).</p>' +
      '<input type="email" id="ee-hf-ecom-email" placeholder="votre@email.com" style="width:100%;box-sizing:border-box;padding:10px 12px;border:1px solid #444;border-radius:8px;background:#222;color:#fff;margin-bottom:12px;font-size:14px;" />' +
      '<div id="ee-hf-ecom-msg" style="min-height:20px;font-size:13px;margin-bottom:8px;"></div>' +
      '<div style="display:flex;gap:8px;">' +
      '<button type="button" id="ee-hf-ecom-submit" style="flex:1;padding:10px;background:#6366f1;color:#fff;border:none;border-radius:8px;cursor:pointer;font-weight:600;">Vérifier</button>' +
      '<button type="button" id="ee-hf-ecom-skip" style="padding:10px 16px;background:#333;color:#fff;border:none;border-radius:8px;cursor:pointer;">Plus tard</button>' +
      '</div>';
    root.appendChild(box);
    document.body.appendChild(root);

    const emailEl = document.getElementById('ee-hf-ecom-email');
    const msgEl = document.getElementById('ee-hf-ecom-msg');
    const submitBtn = document.getElementById('ee-hf-ecom-submit');
    const skipBtn = document.getElementById('ee-hf-ecom-skip');

    function setMsg(txt, isErr) {
      msgEl.textContent = txt || '';
      msgEl.style.color = isErr ? '#f87171' : '#86efac';
    }

    submitBtn.addEventListener('click', function () {
      const email = (emailEl.value || '').trim().toLowerCase();
      if (!email) { setMsg('Veuillez entrer un email.', true); return; }
      setMsg('Vérification en cours…');
      submitBtn.disabled = true;
      verifySubscription(email).then(function (res) {
        submitBtn.disabled = false;
        if (res.ok) {
          setVerifiedEmail(email);
          setMsg('Email vérifié. Accès autorisé.');
          setTimeout(function () { root.remove(); startTracking(); }, 600);
        } else {
          setMsg('Cet email n’est pas abonné ou le serveur est indisponible.', true);
        }
      }).catch(function () {
        submitBtn.disabled = false;
        setMsg('Erreur réseau. Vérifiez l’URL du backend.', true);
      });
    });
    skipBtn.addEventListener('click', function () {
      try { sessionStorage.setItem(POPUP_SHOWN_KEY, '1'); } catch (_) {}
      root.remove();
    });
  }

  // --- Widget (crédits + utilisé aujourd’hui + limite) ---
  let widgetEl = null;
  function ensureWidget() {
    if (widgetEl && document.body.contains(widgetEl)) return widgetEl;
    widgetEl = document.createElement('div');
    widgetEl.id = 'ee-hf-ecom-widget';
    Object.assign(widgetEl.style, {
      position: 'fixed', top: '12px', right: '12px', zIndex: 2147483645,
      background: 'rgba(10,10,14,0.92)', color: '#fff', padding: '12px 14px', borderRadius: '10px',
      fontSize: '12px', minWidth: '160px', boxShadow: '0 4px 20px rgba(0,0,0,0.3)',
      border: '1px solid rgba(255,255,255,0.1)'
    });
    document.body.appendChild(widgetEl);
    return widgetEl;
  }

  function updateWidget(balance, usedToday, limit, isOverLimit, lastGenDelta) {
    const w = ensureWidget();
    const limitVal = limit !== undefined ? limit : CONFIG.DAILY_CREDIT_LIMIT;
    w.style.borderColor = isOverLimit ? 'rgba(248,113,113,0.6)' : 'rgba(134,239,172,0.4)';
    w.style.background = isOverLimit ? 'rgba(80,20,20,0.92)' : 'rgba(10,10,14,0.92)';
    const lastLine = (lastGenDelta > 0) ? '<div style="font-size:11px;opacity:0.85;margin-top:4px;">Dernière génération: -' + lastGenDelta + ' crédits</div>' : '';
    w.innerHTML = '<div style="font-weight:700;margin-bottom:6px;">Crédits Higgsfield</div>' +
      '<div>Solde: <strong>' + (balance != null ? balance : '–') + '</strong></div>' +
      '<div>Utilisés aujourd\'hui: <strong>' + (usedToday != null ? usedToday : '0') + '</strong> / ' + limitVal + '</div>' + lastLine;
  }

  // --- Tracking: poll wallet, delta, daily cap (intervalle long pour éviter ERR_TIMED_OUT) ---
  let lastBalance = null;
  let lastDelta = 0;
  let pollInterval = null;
  let widgetRefreshInterval = null;
  let pollIntervalMs = 10000;
  let consecutiveTimeouts = 0;
  let lastTimeoutLog = 0;

  function startTracking() {
    if (pollInterval) return;
    log('startTracking() — poll wallet every ' + (pollIntervalMs / 1000) + 's, widget every 0.5s');

    function refreshWidgetFromState() {
      const used = getUsedToday();
      const limit = CONFIG.DAILY_CREDIT_LIMIT;
      updateWidget(lastBalance, used, limit, used >= limit, lastDelta);
    }

    function doWalletPoll(token) {
      if (!token) return refreshWidgetFromState();
      return fetchWallet(token).then(function (data) {
        consecutiveTimeouts = 0;
        pollIntervalMs = 10000;
        log('poll: wallet', data);
        const raw = data && (data.balance ?? data.credits ?? data.available ?? (data.wallet && (data.wallet.balance ?? data.wallet.credits)));
        const num = typeof raw === 'number' ? raw : (typeof raw === 'string' ? parseInt(raw, 10) : null);
        const prevBalance = lastBalance;
        if (num !== null && prevBalance !== null && prevBalance !== num && num < prevBalance) {
          const delta = prevBalance - num;
          if (delta > 0) {
            addUsedToday(delta);
            lastDelta = delta;
            log('credits spent: delta=' + delta + ', usedToday=' + getUsedToday());
          }
        }
        if (num !== null) lastBalance = num;
        refreshWidgetFromState();
      }).catch(function (err) {
        const msg = err && err.message ? err.message : String(err);
        const isTimeout = (err && err.name === 'AbortError') || msg.indexOf('abort') !== -1 || msg.indexOf('TIMED_OUT') !== -1 || msg.indexOf('timeout') !== -1 || msg.indexOf('Failed to fetch') !== -1;
        if (isTimeout) {
          consecutiveTimeouts++;
          if (consecutiveTimeouts >= 2) {
            pollIntervalMs = Math.min(pollIntervalMs + 5000, 60000);
            if (pollInterval) { clearInterval(pollInterval); pollInterval = setInterval(poll, pollIntervalMs); }
          }
          if (Date.now() - lastTimeoutLog > 30000) {
            log('wallet timeout (réseau lent?) — poll toutes les ' + (pollIntervalMs / 1000) + 's');
            lastTimeoutLog = Date.now();
          }
        } else {
          consecutiveTimeouts = 0;
          if (msg.indexOf('401') !== -1) {
            capturedBearerToken = null;
            log('→ 401: token invalidé');
          } else log('poll: wallet error', msg);
        }
        refreshWidgetFromState();
      });
    }

    function poll() {
      getJwtAsync().then(function (token) {
        if (!token) {
          refreshWidgetFromState();
          return;
        }
        doWalletPoll(token);
      });
    }

    poll();
    pollInterval = setInterval(poll, pollIntervalMs);

    if (!widgetRefreshInterval) {
      widgetRefreshInterval = setInterval(refreshWidgetFromState, 500);
    }
  }

  // --- Blocage génération si quota atteint (overlay + blocage clic) ---
  function blockGenerateIfNeeded() {
    const used = getUsedToday();
    const limit = CONFIG.DAILY_CREDIT_LIMIT;
    const overlay = document.getElementById('ee-hf-ecom-block-overlay');
    if (used < limit) {
      if (overlay) overlay.remove();
      return;
    }
    if (overlay) return;
    const btn = Array.from(document.querySelectorAll('button')).find(function (b) {
      return /generate|générer|create|créer|run|go/i.test(b.textContent || '');
    });
    if (!btn) return;
    const wrap = document.createElement('div');
    wrap.id = 'ee-hf-ecom-block-overlay';
    wrap.setAttribute('data-ee-block', '1');
    wrap.style.cssText = 'position:absolute;inset:0;background:rgba(0,0,0,0.75);display:flex;align-items:center;justify-content:center;border-radius:inherit;z-index:9999;cursor:not-allowed;pointer-events:auto;';
    wrap.innerHTML = '<span style="color:#fff;font-size:13px;padding:12px;text-align:center;">Quota journalier atteint (100 crédits). Réessayez demain.</span>';
    const parent = btn.closest('div') || btn.parentElement;
    if (parent) {
      if (getComputedStyle(parent).position === 'static') parent.style.position = 'relative';
      parent.appendChild(wrap);
    }
  }

  function installGenerateClickBlocker() {
    document.addEventListener('click', function (e) {
      if (getUsedToday() < CONFIG.DAILY_CREDIT_LIMIT) return;
      const btn = e.target && (e.target.closest ? e.target.closest('button') : null);
      if (!btn) return;
      if (!/generate|générer|create|créer|run|go/i.test(btn.textContent || '')) return;
      e.preventDefault();
      e.stopPropagation();
      alert('Quota journalier atteint (100 crédits). Réessayez demain.');
    }, true);
  }

  function setupBlockingObserver() {
    installGenerateClickBlocker();
    setInterval(blockGenerateIfNeeded, 2000);
  }

  // --- Init: interceptor tout de suite, DOM (widget/popup) après load pour éviter conflit hydratation React #418 ---
  function init() {
    installFetchInterceptor();
    log('init', location.href, 'SIMULATE_CONNECTED=', SIMULATE_CONNECTED);
    function runDomAndTracking() {
      if (shouldShowPopup()) {
        createPopup();
      } else {
        if (SIMULATE_CONNECTED) log('mode simulé: tracking crédits activé');
        ensureWidget();
        startTracking();
        setupBlockingObserver();
      }
    }
    if (document.readyState === 'complete') {
      setTimeout(runDomAndTracking, 1500);
    } else {
      window.addEventListener('load', function () { setTimeout(runDomAndTracking, 1500); });
    }
  }

  try {
    init();
  } catch (err) {
    try { console.error('[EE-HF-Ecom] init error', err && err.message ? err.message : err, err && err.stack); } catch (_) {}
  }
})();
