// elevenlabs_grey_header_zone.js
// Grey-out and disable (non-clickable) the header zone containing Docs/Feedback/Chat/Notifications/Profile.
(function () {
  'use strict';

  if (!location.hostname.endsWith('elevenlabs.io')) return;
  if (!location.pathname.startsWith('/app')) return;

  const STYLE_ID = 'ee-el-grey-header-zone-style';
  const ZONE_ATTR = 'data-ee-greyed';

  function injectStyleOnce() {
    try {
      if (document.getElementById(STYLE_ID)) return;
      const style = document.createElement('style');
      style.id = STYLE_ID;
      style.textContent = `
        [${ZONE_ATTR}="1"] {
          opacity: 0.38 !important;
          filter: grayscale(1) saturate(0.2) contrast(0.9) !important;
          pointer-events: none !important;
          user-select: none !important;
          cursor: not-allowed !important;
        }
        /* keep layout stable even if some child buttons have hover/active styles */
        [${ZONE_ATTR}="1"] * {
          pointer-events: none !important;
          cursor: not-allowed !important;
        }
      `;
      (document.head || document.documentElement).appendChild(style);
    } catch (_) {}
  }

  function findTargetZone() {
    const userBtn =
      document.querySelector('button[data-testid="user-menu-button"]') ||
      document.querySelector('button[aria-label="Votre profil"]') ||
      document.querySelector('button[aria-label="Your profile"]');
    if (!userBtn) return null;

    // Walk up to find a container that also includes Notifications (same zone as snippet)
    let el = userBtn;
    for (let i = 0; i < 12 && el; i++) {
      el = el.parentElement;
      if (!el) break;
      if (el.tagName !== 'DIV') continue;

      const hasUser = !!el.querySelector('button[data-testid="user-menu-button"], button[aria-label="Votre profil"], button[aria-label="Your profile"]');
      const hasNotif = !!el.querySelector('button[aria-label="Notifications"]');
      const looksLikeZone =
        el.classList.contains('hstack') &&
        (el.classList.contains('items-center') || el.className.includes('items-center')) &&
        (el.classList.contains('gap-2') || el.className.includes('gap-2'));

      if (hasUser && hasNotif && looksLikeZone) return el;

      // Fallback: even if classes change, still pick first ancestor containing both
      if (hasUser && hasNotif) return el;
    }
    return null;
  }

  function applyGrey() {
    try {
      injectStyleOnce();
      const zone = findTargetZone();
      if (!zone) return false;
      if (zone.getAttribute(ZONE_ATTR) === '1') return true;
      zone.setAttribute(ZONE_ATTR, '1');
      return true;
    } catch (_) {
      return false;
    }
  }

  function start() {
    // quick retries during app boot
    let tries = 0;
    const t = setInterval(() => {
      tries++;
      const ok = applyGrey();
      if (ok || tries > 80) clearInterval(t); // ~8s
    }, 100);

    // keep it applied after SPA rerenders
    try {
      const mo = new MutationObserver(() => {
        applyGrey();
      });
      mo.observe(document.documentElement || document, { childList: true, subtree: true });
    } catch (_) {}

    // fallback periodic check
    setInterval(() => {
      applyGrey();
    }, 3000);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
})();

