(function() {
    'use strict';

    console.log('[HEYGEN] Loading spinner script started on:', window.location.href);

    // Fonction pour créer l'écran de chargement simple avec spinner
    function showLoadingSpinner() {
        if (document.getElementById('heygen-loading-overlay')) return;

        const overlay = document.createElement('div');
        overlay.id = 'heygen-loading-overlay';
        Object.assign(overlay.style, {
            position: 'fixed',
            top: '0',
            left: '0',
            width: '100vw',
            height: '100vh',
            background: 'linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%)',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center',
            alignItems: 'center',
            zIndex: '2147483647',
            // Do not block page interaction if the flow changes
            pointerEvents: 'none',
            fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
        });

        // Logo/Brand
        const logo = document.createElement('div');
        logo.textContent = 'ECOM EFFICIENCY';
        Object.assign(logo.style, {
            color: '#8b45c4',
            fontSize: '2.5em',
            fontWeight: '900',
            letterSpacing: '3px',
            marginBottom: '40px',
            textShadow: '0 0 20px rgba(139, 69, 196, 0.3)'
        });
        overlay.appendChild(logo);

        // Spinner simple
        const spinner = document.createElement('div');
        Object.assign(spinner.style, {
            width: '50px',
            height: '50px',
            border: '4px solid rgba(139, 69, 196, 0.2)',
            borderTop: '4px solid #8b45c4',
            borderRadius: '50%',
            animation: 'heygen-spin 1s linear infinite'
        });

        // Ajouter le spinner et animer via JS (évite l'inline CSS bloqué par CSP)
        overlay.appendChild(spinner);

        // Animation par rotation via requestAnimationFrame (pas de <style> inline)
        let __heygenSpinnerAngle = 0;
        const __heygenAnimateSpinner = () => {
            __heygenSpinnerAngle = (__heygenSpinnerAngle + 6) % 360;
            spinner.style.transform = `rotate(${__heygenSpinnerAngle}deg)`;
            requestAnimationFrame(__heygenAnimateSpinner);
        };
        requestAnimationFrame(__heygenAnimateSpinner);
        document.body.appendChild(overlay);
        console.log('[HEYGEN] ✅ Loading spinner displayed');
    }

    // Fonction pour terminer l'auto-login (garde juste le spinner)
    function completeAutoLogin() {
        // Juste garder le spinner qui tourne, pas d'action particulière
        console.log('[HEYGEN] ✅ Auto-login completed, keeping spinner visible until page change');
    }

    // Fonction pour surveiller les changements d'URL
    function monitorUrlChange() {
        let currentUrl = window.location.href;
        
        const checkUrl = setInterval(() => {
            if (window.location.href !== currentUrl) {
                console.log('[HEYGEN] URL changed from', currentUrl, 'to', window.location.href);
                
                // Si on quitte la page de login, masquer le spinner
                if (!window.location.href.includes('/login')) {
                    console.log('[HEYGEN] Left login page, hiding spinner');
                    clearInterval(checkUrl);
                    hideLoadingSpinner();
                }
                
                currentUrl = window.location.href;
            }
        }, 500);
        
        return checkUrl;
    }

    // Fonction pour masquer l'écran de chargement
    function hideLoadingSpinner() {
        const overlay = document.getElementById('heygen-loading-overlay');
        if (overlay) {
            overlay.style.opacity = '0';
            overlay.style.transition = 'opacity 0.5s ease';
            setTimeout(() => {
                overlay.remove();
                console.log('[HEYGEN] ✅ Loading spinner hidden');
            }, 500);
        }
    }

    // Fonction utilitaire pour attendre un élément
    function isVisible(el) {
        try {
            if (!el) return false;
            const cs = window.getComputedStyle(el);
            if (cs.visibility === 'hidden' || cs.display === 'none' || Number(cs.opacity) === 0) return false;
            const r = el.getBoundingClientRect();
            return r.width > 0 && r.height > 0;
        } catch (_) {
            return true;
        }
    }

    function waitForElement(selector, timeout = 10000, { visible = false } = {}) {
        return new Promise((resolve, reject) => {
            const pick = () => {
                const all = Array.from(document.querySelectorAll(selector));
                return visible ? (all.find(isVisible) || null) : (all[0] || null);
            };

            const element = pick();
            if (element) return resolve(element);

            const observer = new MutationObserver(() => {
                const found = pick();
                if (found) {
                    observer.disconnect();
                    resolve(found);
                }
            });

            observer.observe(document.body, {
                childList: true,
                subtree: true
            });

            setTimeout(() => {
                observer.disconnect();
                reject(new Error(`Element "${selector}" not found after ${timeout}ms`));
            }, timeout);
        });
    }

    function waitForAny(selectors, timeout = 10000, { visible = false } = {}) {
        const started = Date.now();
        const list = Array.isArray(selectors) ? selectors : [selectors];
        const tryOnce = async () => {
            for (const sel of list) {
                try {
                    const el = await waitForElement(sel, 250, { visible });
                    if (el) return el;
                } catch (_) {}
            }
            return null;
        };
        return new Promise((resolve, reject) => {
            const tick = async () => {
                const el = await tryOnce();
                if (el) return resolve(el);
                if (Date.now() - started > timeout) {
                    return reject(new Error(`None of selectors found within ${timeout}ms: ${list.join(', ')}`));
                }
                setTimeout(tick, 100);
            };
            tick();
        });
    }

    function getText(el) {
        try { return String(el.textContent || '').trim(); } catch (_) { return ''; }
    }

    function findButtonByText(re, root = document) {
        const rx = re instanceof RegExp ? re : new RegExp(String(re), 'i');
        const candidates = Array.from(root.querySelectorAll('button,[role="button"]'));
        for (const el of candidates) {
            if (!isVisible(el)) continue;
            const t = getText(el);
            if (!t) continue;
            if (rx.test(t)) return el;
        }
        return null;
    }

    function waitForButtonByText(re, timeout = 10000) {
        return new Promise((resolve, reject) => {
            const started = Date.now();
            const tick = () => {
                const btn = findButtonByText(re);
                if (btn) return resolve(btn);
                if (Date.now() - started > timeout) return reject(new Error(`Button not found: ${String(re)}`));
                setTimeout(tick, 100);
            };
            tick();
        });
    }

    function setNativeValue(input, value) {
        try {
            const proto = Object.getPrototypeOf(input);
            const desc =
                Object.getOwnPropertyDescriptor(proto, 'value') ||
                Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
            if (desc && typeof desc.set === 'function') desc.set.call(input, value);
            else input.value = value;
        } catch (_) {
            input.value = value;
        }
    }

    function fireInputEvents(input) {
        try { input.dispatchEvent(new Event('focus', { bubbles: true })); } catch (_) {}
        try { input.dispatchEvent(new Event('input', { bubbles: true, cancelable: true })); } catch (_) {}
        try { input.dispatchEvent(new Event('change', { bubbles: true, cancelable: true })); } catch (_) {}
        try { input.dispatchEvent(new Event('blur', { bubbles: true })); } catch (_) {}
    }

    // Fonction pour saisie rapide (copier-coller)
    function fastFillField(field, text) {
        try { field.scrollIntoView({ block: 'center', behavior: 'auto' }); } catch (_) {}
        try { field.focus(); } catch (_) {}
        setNativeValue(field, text);
        fireInputEvents(field);
        return Promise.resolve();
    }

    // Fonction principale d'auto-login
    async function performAutoLogin() {
        try {
            console.log('[HEYGEN] Starting auto-login process...');

            // If a code / OTP page is shown, do not block user
            const otpInput = document.querySelector('input[autocomplete="one-time-code"], input[inputmode="numeric"]');
            if (otpInput && isVisible(otpInput)) {
                console.log('[HEYGEN] OTP / code step detected, stopping auto-login');
                hideLoadingSpinner();
                return;
            }

            const EMAIL = 'ecom.efficiency1@gmail.com';
            const PASSWORD = 'C+N8(%5+3ScL.6S';

            // New HeyGen flow on auth.heygen.com/login:
            // 1) Continue with email
            // 2) Use password instead
            // 3) Fill email + password
            // 4) Sign in

            const continueWithEmailBtn = await waitForButtonByText(/continue with email/i, 8000).catch(() => null);
            if (continueWithEmailBtn) {
                console.log('[HEYGEN] Clicking "Continue with email"...');
                continueWithEmailBtn.click();
                await new Promise(r => setTimeout(r, 400));
            }

            const usePasswordInsteadBtn = await waitForButtonByText(/password instead/i, 8000).catch(() => null);
            if (usePasswordInsteadBtn) {
                console.log('[HEYGEN] Clicking "Use password instead"...');
                usePasswordInsteadBtn.click();
                await new Promise(r => setTimeout(r, 400));
            }

            console.log('[HEYGEN] Waiting for email + password inputs...');
            const emailInput = await waitForAny([
                'input[type="email"][autocomplete="email"]',
                'input[type="email"][placeholder*="email" i]',
                'input[type="email"]'
            ], 20000, { visible: true });
            const passwordInput = await waitForAny([
                'input[type="password"][autocomplete="current-password"]',
                'input[type="password"][placeholder*="password" i]',
                'input[type="password"]'
            ], 20000, { visible: true });

            console.log('[HEYGEN] ✅ Inputs found, filling...');
            await fastFillField(emailInput, EMAIL);
            await new Promise(r => setTimeout(r, 120));
            await fastFillField(passwordInput, PASSWORD);

            await new Promise(r => setTimeout(r, 250));

            const signInBtn = await waitForButtonByText(/^\s*sign in\s*$/i, 15000).catch(async () => {
                // Fallback: any visible button containing "Sign in"
                return await waitForButtonByText(/sign in/i, 15000);
            });

            // Wait for enablement (HeyGen disables until inputs are valid)
            let enableAttempts = 0;
            while (signInBtn && (signInBtn.disabled || signInBtn.getAttribute('aria-disabled') === 'true') && enableAttempts < 60) {
                await new Promise(r => setTimeout(r, 200));
                enableAttempts++;
            }

            console.log('[HEYGEN] Clicking "Sign in"...');
            signInBtn.click();

            // Auto-login terminé, garder juste le spinner
            completeAutoLogin();

            console.log('[HEYGEN] ✅ Auto-login process completed');

        } catch (error) {
            console.error('[HEYGEN] Auto-login failed:', error);
            
            // En cas d'erreur, garder juste le spinner qui tourne
            console.log('[HEYGEN] ❌ Auto-login failed, but keeping spinner visible until page change');
        }
    }

    // Fonction principale
    function initialize() {
        console.log('[HEYGEN] Initializing loading spinner and auto-login...');
        
        // Afficher le spinner immédiatement
        showLoadingSpinner();
        
        // Démarrer la surveillance des changements d'URL
        monitorUrlChange();
        
        // Démarrer l'auto-login après un court délai
        setTimeout(performAutoLogin, 1000);
    }

    // Démarrer dès que possible
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initialize);
    } else {
        // Si le DOM est déjà chargé
        initialize();
    }

})();