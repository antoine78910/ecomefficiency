// Auto-login for Gemini (Google) and Google Account password step
(function () {
  'use strict';

  const TARGET_EMAIL = 'cemalikirklar@gmail.com';
  const TARGET_PASSWORD = 'blt.171925';

  // One-time guards across retries (persist per-tab session)
  const FLAGS = {
    SIGNIN_CLICKED: 'gg_signin_clicked',
    ACCOUNT_CHOSEN: 'gg_account_chosen',
    PWD_SUBMITTED: 'gg_pwd_submitted',
    USED_ANOTHER: 'gg_used_another'
  };
  function getFlag(key) {
    try { return sessionStorage.getItem(key) === '1'; } catch { return false; }
  }
  function setFlag(key) {
    try { sessionStorage.setItem(key, '1'); } catch {}
  }
  
  // Prevent parallel executions
  let isRunning = false;

  function log() {
    console.log('[GEMINI-GOOGLE-AUTOLOGIN]', ...arguments);
  }

  function isVisible(el) {
    if (!el) return false;
    const cs = getComputedStyle(el);
    if (cs.visibility === 'hidden' || cs.display === 'none' || Number(cs.opacity) === 0) return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }

  function waitFor(selector, timeout = 20000, { visible = false, root = document } = {}) {
    return new Promise((resolve, reject) => {
      const pick = () => {
        const list = Array.from(root.querySelectorAll(selector));
        return visible ? list.find(isVisible) : (list[0] || null);
      };
      const now = pick();
      if (now) return resolve(now);
      const obs = new MutationObserver(() => {
        const el = pick();
        if (el) {
          obs.disconnect();
          resolve(el);
        }
      });
      obs.observe(root, { childList: true, subtree: true, attributes: true });
      const t = setTimeout(() => {
        try { obs.disconnect(); } catch {}
        reject(new Error('Timeout waiting for ' + selector));
      }, timeout);
    });
  }

  async function clickGeminiSignIn() {
    try {
      if (getFlag(FLAGS.SIGNIN_CLICKED)) return false;
      // Prefer the provided button structure by its text or data-test-id
      const btn = Array.from(document.querySelectorAll('button, [role="button"], .mdc-fab'))
        .find(b => /(sign\s*in|se\s*connecter|connexion|log\s*in)/i.test(b.textContent || '') || b.getAttribute('data-test-id') === 'action-button');
      if (btn && isVisible(btn)) {
        log('Clicking "Sign in" on gemini.google.com');
        btn.click();
        setFlag(FLAGS.SIGNIN_CLICKED);
        return true;
      }
    } catch {}
    return false;
  }

  async function selectGoogleAccount() {
    if (getFlag(FLAGS.ACCOUNT_CHOSEN)) {
      log('Account already chosen (flag is set)');
      return false;
    }
    
    log('🔍 Looking for account:', TARGET_EMAIL);
    
    // Priority 1: Find by data-identifier attribute (most reliable)
    log('  → Trying method 1: data-identifier selector...');
    const byIdentifier = document.querySelector('[data-identifier="' + CSS.escape(TARGET_EMAIL) + '"]');
    if (byIdentifier) {
      log('  ✓ Found element with data-identifier!');
      // The clickable element is usually the parent div with role="link"
      const clickable = byIdentifier.closest('div[role="link"]') || byIdentifier.closest('li') || byIdentifier;
      log('  → Clickable element:', clickable);
      log('  → Is visible:', isVisible(clickable));
      if (clickable && isVisible(clickable)) {
        log('  ✓ Clicking on account:', TARGET_EMAIL);
        clickable.click();
        setFlag(FLAGS.ACCOUNT_CHOSEN);
        return true;
      } else {
        log('  ✗ Clickable element not visible or not found');
      }
    } else {
      log('  ✗ No element found with data-identifier');
    }
    
    // Priority 2: Find by data-email in the displayed email element
    log('  → Trying method 2: data-email selector...');
    const byDataEmail = document.querySelector('[data-email="' + CSS.escape(TARGET_EMAIL) + '"]');
    if (byDataEmail) {
      log('  ✓ Found element with data-email!');
      const clickable = byDataEmail.closest('div[role="link"]') || byDataEmail.closest('li');
      log('  → Clickable element:', clickable);
      log('  → Is visible:', isVisible(clickable));
      if (clickable && isVisible(clickable)) {
        log('  ✓ Clicking on account:', TARGET_EMAIL);
        clickable.click();
        setFlag(FLAGS.ACCOUNT_CHOSEN);
        return true;
      } else {
        log('  ✗ Clickable element not visible or not found');
      }
    } else {
      log('  ✗ No element found with data-email');
    }
    
    // Priority 3: Find by visible text matching the email
    log('  → Trying method 3: text content search...');
    const emailElements = Array.from(document.querySelectorAll('.yAlK0b, [data-email]'));
    log('  → Found', emailElements.length, 'email elements to check');
    const matchByText = emailElements.find(el => {
      const text = (el.getAttribute('data-email') || el.textContent || '').trim().toLowerCase();
      return text === TARGET_EMAIL.toLowerCase();
    });
    if (matchByText) {
      log('  ✓ Found account by text content!');
      const clickable = matchByText.closest('div[role="link"]') || matchByText.closest('li');
      log('  → Clickable element:', clickable);
      log('  → Is visible:', isVisible(clickable));
      if (clickable && isVisible(clickable)) {
        log('  ✓ Clicking on account:', TARGET_EMAIL);
        clickable.click();
        setFlag(FLAGS.ACCOUNT_CHOSEN);
        return true;
      } else {
        log('  ✗ Clickable element not visible or not found');
      }
    } else {
      log('  ✗ No matching text found');
    }
    
    log('❌ Account not found in the list by any method');
    return false;
  }

  async function clickUseAnotherAccount() {
    if (getFlag(FLAGS.USED_ANOTHER)) return false;
    // Click the "Use another account" entry if present
    // Supports EN (Use another account) and FR (Utiliser un autre compte)
    const textMatch = /(use\s+another\s+account|utiliser\s+un\s+autre\s+compte)/i;
    // Try the exact <li> structure provided
    const specificLi = document.querySelector('li.aZvCDf.mIVEJc.W7Aapd.zpCp3.SmR8');
    if (specificLi) {
      const label = specificLi.querySelector('.riDSKb');
      if (label && textMatch.test((label.textContent || '').trim())) {
        const clickable = specificLi.querySelector('.VV3oRb.YZVTmd[role="link"]') || specificLi;
        if (clickable && isVisible(clickable)) {
          log('Clicking "Use another account" via specific <li>');
          clickable.click();
          setFlag(FLAGS.USED_ANOTHER);
          return true;
        }
      }
    }
    // Direct text scan on common clickable containers
    const candidates = Array.from(document.querySelectorAll('li, div[role="link"], button, [role="button"], .VV3oRb'));
    let target = candidates.find(n => textMatch.test((n.textContent || '').trim()));
    if (!target) {
      // Fallback: Google chooser label span
      const label = Array.from(document.querySelectorAll('.riDSKb, .VV3oRb .riDSKb'))
        .find(n => textMatch.test((n.textContent || '').trim()));
      if (label) {
        target = label.closest('li, div[role="link"], .VV3oRb');
      }
    }
    if (target && isVisible(target)) {
      log('Clicking "Use another account"');
      target.click();
      setFlag(FLAGS.USED_ANOTHER);
      return true;
    }
    return false;
  }

  async function fillIdentifierAndContinue() {
    // Wait and fill email/identifier
    let emailInput = document.querySelector('input#identifierId, input[name="identifier"], input[type="email"], input[autocomplete="username"], input[aria-label*="email" i]');
    if (!emailInput || !isVisible(emailInput)) {
      try {
        emailInput = await waitFor('input#identifierId, input[name="identifier"], input[type="email"]', 10000, { visible: true });
      } catch { return false; }
    }
    if (!emailInput) return false;
    if (emailInput.getAttribute('aria-disabled') === 'true') return false;

    log('Found email input, starting to type...');
    
    // Click on the input first
    emailInput.click();
    await new Promise(r => setTimeout(r, 100));
    
    // Simulate human typing with proper event sequence
    emailInput.focus();
    emailInput.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
    emailInput.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
    emailInput.dispatchEvent(new Event('focus', { bubbles: true }));
    emailInput.dispatchEvent(new Event('focusin', { bubbles: true }));
    
    // Clear any existing value
    emailInput.value = '';
    
    // Simulate typing each character - 1 second per character
    for (let i = 0; i < TARGET_EMAIL.length; i++) {
      const char = TARGET_EMAIL[i];
      
      // Keydown event
      emailInput.dispatchEvent(new KeyboardEvent('keydown', { 
        key: char,
        code: char === '@' ? 'Digit2' : ('Key' + char.toUpperCase()),
        bubbles: true,
        cancelable: true
      }));
      
      // Add character to value
      emailInput.value += char;
      
      // Input event
      emailInput.dispatchEvent(new InputEvent('input', { 
        bubbles: true, 
        cancelable: true,
        inputType: 'insertText',
        data: char
      }));
      
      // Keyup event
      emailInput.dispatchEvent(new KeyboardEvent('keyup', { 
        key: char,
        code: char === '@' ? 'Digit2' : ('Key' + char.toUpperCase()),
        bubbles: true,
        cancelable: true
      }));
      
      log('Typed character ' + (i + 1) + '/' + TARGET_EMAIL.length);
      
      // 1 second delay between characters
      await new Promise(r => setTimeout(r, 1000));
    }
    
    log('Email typing complete');
    
    emailInput.dispatchEvent(new Event('change', { bubbles: true }));
    emailInput.dispatchEvent(new Event('blur', { bubbles: true }));
    emailInput.dispatchEvent(new Event('focusout', { bubbles: true }));

    // Wait to allow validation
    await new Promise(r => setTimeout(r, 500));

    // Click Next
    let nextBtn = Array.from(document.querySelectorAll('button.VfPpkd-LgbsSe, div[role="button"], button'))
      .find(b => /(next|suivant)/i.test(b.textContent || '')) || document.querySelector('button.VfPpkd-LgbsSe');

    if (nextBtn && isVisible(nextBtn)) {
      // Wait until enabled if needed
      let tries = 0;
      while (tries < 20 && ((nextBtn.disabled === true) || nextBtn.getAttribute('aria-disabled') === 'true')) {
        await new Promise(r => setTimeout(r, 150));
        tries++;
      }
      if (!nextBtn.disabled && nextBtn.getAttribute('aria-disabled') !== 'true') {
        log('Submitting identifier (Next click)');
        nextBtn.click();
        return true;
      }
    }

    // Fallback: press Enter on the email input
    try {
      const enterEvt = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true };
      emailInput.focus();
      emailInput.dispatchEvent(new KeyboardEvent('keydown', enterEvt));
      emailInput.dispatchEvent(new KeyboardEvent('keyup', enterEvt));
      await new Promise(r => setTimeout(r, 300));
      return true;
    } catch {}

    return false;
  }

  async function fillPasswordAndContinue() {
    if (getFlag(FLAGS.PWD_SUBMITTED)) return false;
    
    // Password input - multiple selectors to catch it
    let pwd = document.querySelector('input[type="password"][name="Passwd"]');
    if (!pwd) pwd = document.querySelector('input.whsOnd[type="password"]');
    if (!pwd) pwd = document.querySelector('input[type="password"][jsname="YPqjbf"]');
    if (!pwd) pwd = document.querySelector('input[type="password"][autocomplete*="password"]');
    if (!pwd) pwd = document.querySelector('input[type="password"]');
    
    if (!pwd) {
      log('Password input not found');
      return false;
    }
    
    if (!isVisible(pwd)) {
      log('Password input not visible');
      return false;
    }
    
    log('Found password input, starting to type...');
    
    // Click on the input first
    pwd.click();
    await new Promise(r => setTimeout(r, 100));
    
    // Simulate human typing with proper event sequence
    pwd.focus();
    pwd.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
    pwd.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
    pwd.dispatchEvent(new Event('focus', { bubbles: true }));
    pwd.dispatchEvent(new Event('focusin', { bubbles: true }));
    
    // Clear any existing value
    pwd.value = '';
    
    // Simulate typing each character - 1 second per character
    for (let i = 0; i < TARGET_PASSWORD.length; i++) {
      const char = TARGET_PASSWORD[i];
      
      // Keydown event
      pwd.dispatchEvent(new KeyboardEvent('keydown', { 
        key: char,
        code: 'Key' + char.toUpperCase(),
        bubbles: true,
        cancelable: true
      }));
      
      // Add character to value
      pwd.value += char;
      
      // Input event
      pwd.dispatchEvent(new InputEvent('input', { 
        bubbles: true, 
        cancelable: true,
        inputType: 'insertText',
        data: char
      }));
      
      // Keyup event
      pwd.dispatchEvent(new KeyboardEvent('keyup', { 
        key: char,
        code: 'Key' + char.toUpperCase(),
        bubbles: true,
        cancelable: true
      }));
      
      log('Typed character ' + (i + 1) + '/' + TARGET_PASSWORD.length);
      
      // 1 second delay between characters
      await new Promise(r => setTimeout(r, 1000));
    }
    
    log('✓ Password typing complete');
    
    pwd.dispatchEvent(new Event('change', { bubbles: true }));
    pwd.dispatchEvent(new Event('blur', { bubbles: true }));
    pwd.dispatchEvent(new Event('focusout', { bubbles: true }));
    
    // Wait a bit to allow validation
    await new Promise(r => setTimeout(r, 500));

    // Click "Suivant" / "Next"
    log('🔍 Looking for Next button...');
    
    // Try to find by text
    const allButtons = Array.from(document.querySelectorAll('button, div[role="button"]'));
    log('  → Found', allButtons.length, 'button elements');
    
    let nextBtn = allButtons.find(b => /(suivant|next)/i.test(b.textContent || ''));
    if (nextBtn) {
      log('  ✓ Found Next button by text:', nextBtn.textContent.trim());
    } else {
      log('  ✗ No button found with "Next" or "Suivant" text');
    }
    
    // Fallback: try by class
    if (!nextBtn) {
      log('  → Trying fallback: button.VfPpkd-LgbsSe...');
      nextBtn = document.querySelector('button.VfPpkd-LgbsSe');
      if (nextBtn) {
        log('  ✓ Found button by class VfPpkd-LgbsSe');
      } else {
        log('  ✗ No button found with class VfPpkd-LgbsSe');
      }
    }
    
    if (nextBtn) {
      log('  → Button element:', nextBtn);
      log('  → Button visible:', isVisible(nextBtn));
      log('  → Button disabled:', nextBtn.disabled);
      log('  → Button aria-disabled:', nextBtn.getAttribute('aria-disabled'));
      
      if (isVisible(nextBtn)) {
        log('  ✓ Next button is visible, waiting for it to be enabled...');
        // Wait until enabled if needed
        let tries = 0;
        while (tries < 30 && ((nextBtn.disabled === true) || nextBtn.getAttribute('aria-disabled') === 'true')) {
          await new Promise(r => setTimeout(r, 200));
          tries++;
          log('  → Waiting... try', tries);
        }
        
        if (!nextBtn.disabled && nextBtn.getAttribute('aria-disabled') !== 'true') {
          log('  ✓ Button is enabled, clicking now!');
          nextBtn.click();
          setFlag(FLAGS.PWD_SUBMITTED);
          return true;
        } else {
          log('  ✗ Next button still disabled after 30 tries (6 seconds)');
        }
      } else {
        log('  ✗ Next button not visible');
      }
    } else {
      log('  ❌ Next button not found by any method');
    }
    return false;
  }

  function onGemini() {
    return location.hostname === 'gemini.google.com';
  }
  function onGoogleAccounts() {
    return location.hostname === 'accounts.google.com';
  }
  function isAccountChooser() {
    return /\/v3\/signin\/accountchooser/i.test(location.pathname) || /accountchooser\?/i.test(location.href);
  }

  let loopId = null;
  function stopLoop() {
    try { if (loopId) clearInterval(loopId); } catch {}
    loopId = null;
  }

  async function run() {
    // Prevent parallel executions
    if (isRunning) {
      log('Already running, skipping...');
      return;
    }
    
    isRunning = true;
    try {
      if (onGemini()) {
        log('On Gemini page, looking for Sign in button...');
        await clickGeminiSignIn();
      } else if (onGoogleAccounts()) {
        log('On Google Accounts page, URL:', location.href);
        
        // STEP 1: Try to select the account directly if it's in the list
        if (!getFlag(FLAGS.ACCOUNT_CHOSEN)) {
          log('Step 1: Looking for account in the list...');
          const accountSelected = await selectGoogleAccount();
          if (accountSelected) {
            log('✓ Account selected from list, waiting for password page...');
            // Don't stop loop yet, we need it to detect the password page
            return;
          } else {
            log('✗ Account not found in the list');
          }
        } else {
          log('Account already selected (flag set)');
        }
        
        // STEP 2: Fill password if on password page
        log('Step 2: Checking if password input is available...');
        const submitted = await fillPasswordAndContinue();
        if (submitted) {
          log('✓ Password submitted, login complete!');
          // Now we can stop the loop
          stopLoop();
        }
      }
    } catch (e) {
      log('❌ Error:', e && e.message);
    } finally {
      isRunning = false;
    }
  }

  // Kick and retry a few times for dynamic UIs
  // With slow typing (1s per char), we need more attempts
  // Email ~23 chars + password ~10 chars = ~33 seconds minimum
  let attempts = 0;
  const maxAttempts = 100; // 100 * 500ms = 50 seconds max
  loopId = setInterval(() => {
    attempts++;
    run();
    if (attempts >= maxAttempts) stopLoop();
  }, 500);

  // Also re-run on URL changes
  let last = location.href;
  setInterval(() => {
    if (location.href !== last) {
      last = location.href;
      attempts = 0;
      // Reset loop to allow next step, but keep one-time flags to avoid double-actions
      if (!loopId) {
        loopId = setInterval(() => {
          attempts++;
          run();
          if (attempts >= maxAttempts) stopLoop();
        }, 500);
      }
      run();
    }
  }, 700);
})();


