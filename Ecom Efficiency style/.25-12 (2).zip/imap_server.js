const express = require('express');
const { ImapFlow } = require('imapflow');
require('dotenv').config();

const app = express();

// CORS pour permettre l'accès depuis l'extension
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
  } else {
    next();
  }
});
const PORT = process.env.PORT || process.env.IMAP_SERVER_PORT || 20016;

function mask(s) { return s ? s.replace(/.(?=.{4})/g, '*') : s; }

// Avoid piling up multiple IMAP connects per account (extension can poll quickly)
const vmakeInflight = new Map(); // account -> { ts, promise }

app.get('/otp', async (req, res) => {
  console.log('[imap] OTP request received at', new Date().toISOString());
  const imapHost = process.env.IMAP_HOST; // e.g., "imap.neospace.email"
  const imapPort = Number(process.env.IMAP_PORT || 993);
  // Allow dedicated creds for GPT (/otp) while keeping IMAP_USER as fallback
  const imapUser = process.env.IMAP_GPT_USER || process.env.IMAP_USER; // full email address
  const imapPass = process.env.IMAP_GPT_PASS || process.env.IMAP_PASS; // app password
  const imapTLS  = String(process.env.IMAP_TLS || 'true') === 'true';
  const imapMethod = (process.env.IMAP_METHOD || 'LOGIN').toUpperCase(); // LOGIN or PLAIN

  console.log('[imap] Config:', { 
    host: imapHost, 
    port: imapPort, 
    user: imapUser ? imapUser.substring(0, 3) + '***' : 'missing',
    tls: imapTLS,
    method: imapMethod 
  });

  if (!imapHost || !imapUser || !imapPass) {
    console.error('[imap] Missing env vars', { host: !!imapHost, user: !!imapUser, pass: !!imapPass });
    return res.status(500).json({ error: 'Missing IMAP env vars' });
  }

  const client = new ImapFlow({
    host: imapHost,
    port: imapPort,
    secure: imapTLS,
    auth: { user: imapUser, pass: imapPass, method: imapMethod }
  });

  let code = '';
  try {
    await client.connect();
    const lock = await client.getMailboxLock('INBOX');
    try {
      // Search latest 20 unseen first, else latest 20
      let seq; 
      const unseen = await client.search({ seen: false }, { uid: true });
      if (unseen.length > 0) {
        seq = unseen.slice(-20);
      } else {
        const all = await client.search({}, { uid: true });
        seq = all.slice(-20);
      }
      seq = seq.reverse();

      for (const uid of seq) {
        const { content } = await client.download(uid, null, { uid: true });
        const raw = await contentToUtf8(content);
        // Quick filter to messages from OpenAI or referencing auth.openai.com
        const looksLikeOpenAI = /openai|auth\.openai\.com/i.test(raw);
        if (!looksLikeOpenAI) continue;
        // Extract the first 6-digit code in the message
        const m = raw.match(/\b(\d{6})\b/);
        if (m && m[1]) { code = m[1]; break; }
      }
    } finally {
      lock.release();
    }
  } catch (e) {
    console.error('[imap] Error while fetching OTP:', e);
    return res.status(500).json({ 
      error: (e && e.message) ? e.message : String(e),
      response: e && e.response,
      responseStatus: e && e.responseStatus,
      responseText: e && e.responseText,
      serverResponseCode: e && e.serverResponseCode
    });
  } finally {
    try { await client.logout(); } catch (_) {}
  }

  console.log('[imap] Sending response:', { code });
  res.json({ code });
});

// Helper to serve vmake OTP for a given accountId ("1", "2", "3")
async function handleOtpVmake(accountId, req, res) {
  const account = String(accountId || '3'); // default account 3
  console.log('[imap-vmake] OTP-VMAKE request received at', new Date().toISOString(), 'account=', account);

  // Deduplicate in-flight requests for the same account (avoid dozens of 90s timeouts in parallel)
  const now = Date.now();
  const inflight = vmakeInflight.get(account);
  if (inflight && (now - inflight.ts) < 25_000) {
    console.log('[imap-vmake] Reusing in-flight IMAP attempt for account', account);
    try {
      const out = await inflight.promise;
      return res.json(out);
    } catch (e) {
      return res.status(500).json({
        error: (e && e.message) ? e.message : String(e),
        code: e && e.code,
        details: e && e.details
      });
    }
  }

  const accountMap = {
    '1': { user: process.env.IMAP_USER1, pass: process.env.IMAP_PASS1 },
    '2': { user: process.env.IMAP_USER2, pass: process.env.IMAP_PASS2 },
    '3': { user: process.env.IMAP_USER3 || process.env.IMAP_USER, pass: process.env.IMAP_PASS3 || process.env.IMAP_PASS },
  };

  const creds = accountMap[account] || accountMap['3'];
  const imapUser = creds.user;
  const imapPass = creds.pass;

  // Per-account host override + multi-host fallback
  // - IMAP_HOST3 / IMAP_HOST2 / IMAP_HOST1: single host per account
  // - IMAP_HOSTS3 / IMAP_HOSTS2 / IMAP_HOSTS1: comma-separated host list (will be tried in order)
  // - IMAP_HOSTS: global comma-separated list (fallback)
  const imapHostSingle =
    process.env[`IMAP_HOST${account}`] ||
    process.env.IMAP_HOST;
  const imapHostsRaw =
    process.env[`IMAP_HOSTS${account}`] ||
    process.env.IMAP_HOSTS ||
    imapHostSingle ||
    '';
  const imapHosts = String(imapHostsRaw)
    .split(',')
    .map(s => s.trim())
    .filter(Boolean);

  const imapPort = Number(process.env.IMAP_PORT || 993);
  const imapTLS  = String(process.env.IMAP_TLS || 'true') === 'true';
  const imapMethod = (process.env.IMAP_METHOD || 'LOGIN').toUpperCase();

  // Tunable timeouts (connect timeout was 90s in your logs)
  const connectionTimeout = Number(process.env.IMAP_CONNECTION_TIMEOUT_MS || 30_000);
  const socketTimeout = Number(process.env.IMAP_SOCKET_TIMEOUT_MS || 60_000);
  const greetingTimeout = Number(process.env.IMAP_GREETING_TIMEOUT_MS || 30_000);

  console.log('[imap-vmake] Config:', { 
    host: imapHosts[0] || imapHostSingle, 
    port: imapPort, 
    user: imapUser ? imapUser.substring(0, 3) + '***' : 'missing',
    tls: imapTLS,
    method: imapMethod,
    account,
    hostsToTry: imapHosts.length,
    connectionTimeout,
  });

  if (!imapHosts.length || !imapUser || !imapPass) {
    console.error('[imap-vmake] Missing env vars', { host: !!imapHosts.length, user: !!imapUser, pass: !!imapPass });
    return res.status(500).json({ error: 'Missing IMAP env vars' });
  }

  const workPromise = (async () => {
    let lastErr = null;

    for (const host of imapHosts) {
      const client = new ImapFlow({
        host,
        port: imapPort,
        secure: imapTLS,
        auth: { user: imapUser, pass: imapPass, method: imapMethod },
        // ImapFlow timeouts (fix noisy 90s hangs; doesn't bypass network blocks)
        connectionTimeout,
        socketTimeout,
        greetingTimeout,
        tls: imapTLS ? { servername: host } : undefined
      });

      try {
        console.log('[imap-vmake] Trying IMAP host:', host);
        await client.connect();
        console.log('[imap-vmake] Connected to IMAP server:', host);

        let code = '';
        const lock = await client.getMailboxLock('INBOX');
        try {
          let seq; 
          const unseen = await client.search({ seen: false }, { uid: true });
          if (unseen.length > 0) {
            seq = unseen.slice(-20);
            console.log('[imap-vmake] Found', unseen.length, 'unseen emails, checking last 20');
          } else {
            const all = await client.search({}, { uid: true });
            seq = all.slice(-20);
            console.log('[imap-vmake] No unseen emails, checking last 20 from all emails');
          }
          // latest first
          seq = seq.reverse();
          console.log('[imap-vmake] Processing', seq.length, 'emails');

          const NOW = Date.now();
          const MAX_AGE_MS = 15 * 60 * 1000; // 15 minutes

          for (const uid of seq) {
            try {
              // Download email content and envelope for date check
              const message = await client.fetchOne(uid, { 
                envelope: true,
                bodyStructure: true 
              }, { uid: true });

              // 1. Date check - Ignore old emails
              if (message.envelope && message.envelope.date) {
                const emailDate = new Date(message.envelope.date);
                const ageMs = NOW - emailDate.getTime();
                if (ageMs > MAX_AGE_MS) {
                  console.log('[imap-vmake] Email', uid, 'is too old (' + Math.round(ageMs/60000) + ' min), skipping.');
                  continue;
                }
              }

              // 2. Sender check
              const fromAddress = message?.envelope?.from?.[0]?.address || '';
              const isFromVmake = /account@vmake\.ai/i.test(fromAddress);
              
              const { content } = await client.download(uid, null, { uid: true });
              const raw = await contentToUtf8(content);

              // Double check sender in content if envelope failed
              if (!isFromVmake && !(/from:\s*[^<\n]*account@vmake\.ai/i.test(raw) || /account@vmake\.ai/i.test(raw))) {
                continue;
              }

              // 3. Precise Code Extraction
              let m = null;
              m = raw.match(/<div[^>]*style="[^"]*font-size:\s*40px[^"]*"[^>]*>[\s\r\n]*(\d{4})[\s\r\n]*<\/div>/i);
              if (!m) {
                m = raw.match(/font-size:\s*40px[^>]*>[\s\r\n]*(\d{4})[\s\r\n]*<\/div>/i);
              }
              if (!m) {
                const contextMatch = raw.match(/Your verification code is[\s\S]{0,150}?(\d{4})/i);
                if (contextMatch) {
                  const candidate = contextMatch[1];
                  if (parseInt(candidate) >= 2020 && parseInt(candidate) <= 2030) {
                    console.log('[imap-vmake] Skipped candidate ' + candidate + ' because it looks like a year and wasn\'t in the main code box.');
                  } else {
                    m = contextMatch;
                  }
                }
              }

              if (m && m[1]) { 
                code = m[1]; 
                console.log('[imap-vmake] ✓ Extracted code:', code, 'from email UID:', uid, 'host:', host);
                break; 
              }
            } catch (emailErr) {
              console.warn('[imap-vmake] Error processing email', uid, ':', emailErr.message);
              continue;
            }
          }

          console.log('[imap-vmake] Sending response:', { code: code || 'not found', host });
          return { code };
        } finally {
          lock.release();
        }
      } catch (e) {
        lastErr = e;
        console.error('[imap-vmake] Host failed:', host, 'err=', e && e.message ? e.message : e);
      } finally {
        try { await client.logout(); } catch (_) {}
      }
    }

    // All hosts failed
    const errMsg = lastErr ? (lastErr.message || String(lastErr)) : 'IMAP connect failed';
    const err = new Error(errMsg);
    err.code = lastErr && lastErr.code;
    err.details = lastErr && lastErr.details;
    throw err;
  })();

  vmakeInflight.set(account, { ts: now, promise: workPromise });
  try {
    const out = await workPromise;
    return res.json(out);
  } catch (e) {
    console.error('[imap-vmake] Error while fetching OTP:', e);
    return res.status(500).json({ 
      error: (e && e.message) ? e.message : String(e),
      code: e && e.code,
      details: e && e.details,
      hint: 'CONNECT_TIMEOUT means the server could not open a TCP connection to the IMAP host:port. Usually firewall/port block, wrong host, or provider blocks your server IP. Try setting IMAP_HOSTS2 to an alternate IMAP hostname that works from the server.'
    });
  } finally {
    const cur = vmakeInflight.get(account);
    if (cur && cur.promise === workPromise) vmakeInflight.delete(account);
  }
}

// Dedicated endpoints per account
app.get('/otp-vmake1', async (req, res) => handleOtpVmake('1', req, res));
app.get('/otp-vmake2', async (req, res) => handleOtpVmake('2', req, res));
app.get('/otp-vmake3', async (req, res) => handleOtpVmake('3', req, res));
// Backward compatibility: default to account 3
app.get('/otp-vmake', async (req, res) => handleOtpVmake(req.query.account || '3', req, res));

async function contentToUtf8(content) {
  if (!content) return '';
  // Node stream
  if (typeof content.on === 'function') {
    return new Promise((resolve, reject) => {
      let data = '';
      content.on('data', chunk => { data += Buffer.from(chunk).toString('utf8'); });
      content.on('end', () => resolve(data));
      content.on('error', reject);
    });
  }
  // Buffer or Uint8Array
  if (Buffer.isBuffer(content)) return content.toString('utf8');
  if (content instanceof Uint8Array) return Buffer.from(content).toString('utf8');
  if (typeof content === 'string') return content;
  try { return String(content || ''); } catch (_) { return ''; }
}

app.listen(PORT, () => {
  console.log(`[imap_server] listening on ${PORT}`);
});

app.get('/health', (req, res) => {
  res.json({ ok: true, port: Number(PORT) });
});

// Route racine pour éviter "Cannot GET /"
app.get('/', (req, res) => {
  res.json({ 
    message: 'IMAP Server is running', 
    endpoints: ['/otp', '/otp-vmake', '/health'],
    port: Number(PORT) 
  });
});
