// auto_logout_11.js

(function() {
    'use strict';

    const EE_ALLOWED_EMAILS_CSV = 'elevenlabs_allowed_emails.csv';
    const EE_STORAGE_ALLOWED_KEY = 'ee_el_allowed_emails';

    function onTarget() {
        try {
            return location.hostname.endsWith('elevenlabs.io') && location.pathname.startsWith('/app');
        } catch (_) {
            return false;
        }
    }
    if (!onTarget()) return;

    // IMPORTANT:
    // This script used to auto-logout on *every* /app page load, which breaks normal UI
    // (ex: profile/credits popups stop working because we keep clicking/redirecting).
    // We now only auto-logout when we detect a real blocking/paywall modal.
    function shouldAutoLogoutNow() {
        try {
            const hostOk = location.hostname.endsWith('elevenlabs.io');
            const pathOk = location.pathname.startsWith('/app');
            if (!hostOk || !pathOk) return false;

            // Detect common blocking/paywall messages in dialogs/toasts
            const nodes = Array.from(document.querySelectorAll('[role="dialog"], [aria-modal="true"], [data-radix-dialog-content], .Toastify, [data-sonner-toaster]'))
                .slice(0, 80);
            const hay = nodes.map(n => (n && (n.textContent || '') || '').toLowerCase()).join(' ');
            if (!hay) return false;

            return (
                hay.includes('free trial') ||
                hay.includes('trial expired') ||
                hay.includes('subscription expired') ||
                hay.includes('payment failed') ||
                hay.includes('payment required') ||
                hay.includes('billing') ||
                hay.includes('upgrade to') ||
                hay.includes('upgrade')
            );
        } catch (_) {
            return false;
        }
    }

    function normalizeEmail(s) {
        return String(s || '').trim().toLowerCase();
    }

    function extractFirstEmail(text) {
        const t = String(text || '');
        const m = t.match(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i);
        return m ? normalizeEmail(m[0]) : '';
    }

    function findCurrentEmail() {
        try {
            // Prefer header/nav area (cheap + usually contains the email)
            const roots = [];
            const header = document.querySelector('header');
            const nav = document.querySelector('nav');
            if (header) roots.push(header);
            if (nav) roots.push(nav);
            roots.push(document.body || document.documentElement);

            for (const r of roots) {
                if (!r) continue;
                const email = extractFirstEmail(r.innerText || r.textContent || '');
                if (email) return email;
            }
        } catch (_) {}

        // Fallback: scan localStorage for something that looks like an email
        try {
            const keys = Object.keys(localStorage || {}).slice(0, 120);
            for (const k of keys) {
                if (!/email/i.test(k)) continue;
                const v = localStorage.getItem(k);
                const email = extractFirstEmail(v || '');
                if (email) return email;
            }
        } catch (_) {}

        return '';
    }

    function chromeLocalGet(key) {
        return new Promise((resolve) => {
            try {
                if (!chrome || !chrome.storage || !chrome.storage.local) return resolve(null);
                chrome.storage.local.get([key], (obj) => resolve(obj ? obj[key] : null));
            } catch (_) {
                resolve(null);
            }
        });
    }

    function chromeLocalSet(obj) {
        return new Promise((resolve) => {
            try {
                if (!chrome || !chrome.storage || !chrome.storage.local) return resolve(false);
                chrome.storage.local.set(obj, () => resolve(true));
            } catch (_) {
                resolve(false);
            }
        });
    }

    async function loadAllowedEmails() {
        const out = new Set();

        // 1) CSV shipped with extension (if filled)
        try {
            if (chrome && chrome.runtime && chrome.runtime.getURL) {
                const url = chrome.runtime.getURL(EE_ALLOWED_EMAILS_CSV);
                const res = await fetch(url, { cache: 'no-store' });
                const txt = await res.text();
                const lines = String(txt || '').split(/\r?\n/);
                for (const line of lines) {
                    const email = extractFirstEmail(line);
                    if (email) out.add(email);
                }
            }
        } catch (_) {}

        // 2) Storage fallback (auto-learned)
        try {
            const stored = await chromeLocalGet(EE_STORAGE_ALLOWED_KEY);
            if (Array.isArray(stored)) {
                stored.map(normalizeEmail).filter(Boolean).forEach((e) => out.add(e));
            } else if (typeof stored === 'string') {
                const email = extractFirstEmail(stored);
                if (email) out.add(email);
            }
        } catch (_) {}

        return out;
    }

    async function maybeStoreAllowedEmail(email) {
        const e = normalizeEmail(email);
        if (!e) return;
        try {
            const stored = await chromeLocalGet(EE_STORAGE_ALLOWED_KEY);
            const arr = Array.isArray(stored) ? stored.slice(0) : [];
            if (!arr.map(normalizeEmail).includes(e)) arr.push(e);
            await chromeLocalSet({ [EE_STORAGE_ALLOWED_KEY]: arr.slice(0, 10) });
        } catch (_) {}
    }

    function resetElevenLabsCookies() {
        return new Promise((resolve) => {
            try {
                if (!chrome || !chrome.runtime || !chrome.runtime.sendMessage) return resolve({ ok: false, error: 'no chrome.runtime' });
                chrome.runtime.sendMessage({ action: 'RESET_ELEVENLABS_COOKIES' }, (resp) => {
                    resolve(resp || { ok: false, error: 'no response' });
                });
            } catch (e) {
                resolve({ ok: false, error: String(e && e.message ? e.message : e) });
            }
        });
    }

    async function cookieLogout(reason) {
        try {
            const k = 'ee_el_cookie_logout_ts';
            const last = Number(sessionStorage.getItem(k) || '0');
            const now = Date.now();
            if (last && now - last < 15000) return true; // avoid loops
            sessionStorage.setItem(k, String(now));
        } catch (_) {}

        const resp = await resetElevenLabsCookies();
        try { console.log('[EL LOGOUT] Cookie logout:', reason, resp); } catch (_) {}
        try {
            const target = `${location.origin}/app/sign-in`;
            location.replace(target);
        } catch (_) {
            try { location.reload(); } catch (__) {}
        }
        return !!(resp && resp.ok);
    }

    // Decide whether to logout:
    // - logout if a paywall/blocking modal is detected
    // - logout if the current email is NOT in allowed list (CSV), when list is provided
    (async () => {
        try {
            const allowed = await loadAllowedEmails();
            const currentEmail = findCurrentEmail();

            // If CSV is empty and we can detect the current email, learn it as allowed (prevents accidental logouts)
            if (allowed.size === 0 && currentEmail) {
                await maybeStoreAllowedEmail(currentEmail);
                allowed.add(currentEmail);
            }

            const hasCsvPolicy = allowed.size > 0;
            const isAllowed = currentEmail ? allowed.has(normalizeEmail(currentEmail)) : false;

            if (hasCsvPolicy && currentEmail && !isAllowed) {
                await cookieLogout('email_not_allowed');
                return;
            }

            if (shouldAutoLogoutNow()) {
                // Prefer cookie logout first (more robust)
                const ok = await cookieLogout('paywall_detected');
                if (ok) return;
                // If cookie logout fails for some reason, continue with UI logout below.
            } else {
                return; // no paywall, allowed user => keep UI usable
            }
        } catch (_) {
            // If our gating fails, fall through to UI logout as last resort
        }
    })();

    // Helpers visibilité / click
    function isElementVisible(el) {
        if (!el) return false;
        const cs = getComputedStyle(el);
        if (cs.visibility === 'hidden' || cs.display === 'none' || Number(cs.opacity) === 0) return false;
        const r = el.getBoundingClientRect();
        return r.width > 0 && r.height > 0;
    }

    function humanLikeClick(el) {
        if (!el) return;
        try { el.scrollIntoView({ block: 'center' }); } catch {}
        const ev = { bubbles: true, cancelable: true, view: window };
        try { el.dispatchEvent(new PointerEvent('pointerover', ev)); } catch {}
        try { el.dispatchEvent(new PointerEvent('pointerenter', ev)); } catch {}
        try { el.dispatchEvent(new PointerEvent('mouseover', ev)); } catch {}
        try { el.dispatchEvent(new PointerEvent('mousemove', ev)); } catch {}
        try { el.dispatchEvent(new PointerEvent('pointerdown', ev)); } catch {}
        try { el.dispatchEvent(new PointerEvent('mousedown', ev)); } catch {}
        try { el.dispatchEvent(new PointerEvent('pointerup', ev)); } catch {}
        try { el.dispatchEvent(new PointerEvent('mouseup', ev)); } catch {}
        try { el.dispatchEvent(new PointerEvent('click', ev)); } catch {}
        try { el.click(); } catch {}
    }

    function delay(ms) { return new Promise(r => setTimeout(r, ms)); }

    // Fonction pour attendre la présence d'un élément dans le DOM
    function waitForElement(selector, timeout = 10000) {
        return new Promise((resolve, reject) => {
            const observer = new MutationObserver((mutations) => {
                const element = document.querySelector(selector);
                if (element) {
                    observer.disconnect();
                    resolve(element);
                }
            });

            observer.observe(document.body, {
                childList: true,
                subtree: true
            });

            // Vérifier immédiatement si l'élément existe
            const element = document.querySelector(selector);
            if (element) {
                observer.disconnect();
                resolve(element);
            }

            // Timeout si l'élément n'est pas trouvé
            setTimeout(() => {
                observer.disconnect();
                reject(new Error('Element not found'));
            }, timeout);
        });
    }

    // Attendre le premier élément qui matche parmi plusieurs sélecteurs
    function waitForOneOf(selectors, timeout = 12000) {
        return new Promise((resolve, reject) => {
            const pick = () => selectors.map(s => document.querySelector(s)).find(Boolean);
            const immediate = pick();
            if (immediate) return resolve(immediate);

            const obs = new MutationObserver(() => {
                const el = pick();
                if (el) {
                    obs.disconnect();
                    resolve(el);
                }
            });
            obs.observe(document.body, { childList: true, subtree: true, attributes: true });
            const t = setTimeout(() => {
                obs.disconnect();
                reject(new Error('Element not found for any selector: ' + selectors.join(', ')));
            }, timeout);
        });
    }

    function findButtonByText(regex) {
        const btns = Array.from(document.querySelectorAll('button'));
        return btns.find(b => regex.test((b.textContent || '').trim()));
    }

    function findClickableByText(textRegex) {
        const nodes = Array.from(document.querySelectorAll('button, a, [role="button"], [role="menuitem"], div[role="menuitem"], li[role="menuitem"]'));
        for (const el of nodes) {
            if (!isElementVisible(el)) continue;
            const txt = ((el.innerText || el.textContent || '').trim());
            if (textRegex.test(txt)) return el;
        }
        return null;
    }

    // Injection dans le contexte page pour capter les navigations SPA réelles
    function injectHistoryHook() {
        try {
            const script = document.createElement('script');
            script.textContent = `(() => {
                if (window.__el_history_hook_installed) return; 
                window.__el_history_hook_installed = true;
                const notify = () => { try { window.dispatchEvent(new Event('el:navigation')); } catch {}
                };
                const ps = history.pushState; 
                history.pushState = function() { const r = ps.apply(this, arguments); notify(); return r; };
                const rs = history.replaceState; 
                history.replaceState = function() { const r = rs.apply(this, arguments); notify(); return r; };
                window.addEventListener('popstate', notify);
                const ofetch = window.fetch; 
                window.fetch = function() { return ofetch.apply(this, arguments).then((res) => { try { notify(); } catch {} return res; }); };
                const open = XMLHttpRequest.prototype.open;
                XMLHttpRequest.prototype.open = function() { this.addEventListener('load', () => { try { notify(); } catch {} }); return open.apply(this, arguments); };
                // Mutations DOM significatives
                const mo = new MutationObserver(() => notify());
                try { mo.observe(document.documentElement, { childList: true, subtree: true }); } catch {}
            })();`;
            (document.documentElement || document.head || document.body).appendChild(script);
            script.remove();
        } catch {}
    }

    // Fonction principale pour la déconnexion
    async function autoLogout() {
        try {
            if (sessionStorage.getItem('el_logout_done') === '1') return;
            if (!(location.hostname.endsWith('elevenlabs.io') && location.pathname.startsWith('/app'))) return;

            console.log('[EL LOGOUT] Début séquence sur', location.href);

            // 1) Ouvrir le menu profil (FR/EN) avec sélecteurs élargis et fallback texte
            let profileButton = null;
            try {
                profileButton = await waitForOneOf([
                    'button[aria-label="Your profile"]',
                    'button[aria-label="Votre profil"]',
                    'button[aria-label*="profile" i]',
                    'button[aria-label*="profil" i]'
                ], 10000);
            } catch (_) {}
            if (!profileButton) {
                profileButton = findClickableByText(/Mon compte|My account|Votre profil|Your profile|Account|Profil|Profile|Avatar/i);
            }
            if (!profileButton) throw new Error('Profile button not found');
            console.log('[EL LOGOUT] Bouton profil trouvé, clic');
            humanLikeClick(profileButton);
            await delay(300);

            // 2) Cliquer sur "Se déconnecter" (FR/EN) avec recherche large
            let logoutButton = null;
            try {
                logoutButton = await waitForOneOf([
                    '[aria-label="Sign out"]',
                    '[aria-label="Se déconnecter"]',
                    '[title*="Sign out" i]',
                    '[title*="déconnect" i]'
                ], 8000);
            } catch (_) {}
            if (!logoutButton) {
                logoutButton = findClickableByText(/Se déconnecter|Sign out|Log out|Déconnexion/i);
            }
            if (!logoutButton) throw new Error('Logout button not found');
            console.log('[EL LOGOUT] Bouton déconnexion trouvé, clic');
            humanLikeClick(logoutButton);

            sessionStorage.setItem('el_logout_done', '1');

            // 3) Recharger la page après 5s pour déclencher l'auto-login
            console.log('[EL LOGOUT] Déconnexion cliquée, reload dans 5s');
            setTimeout(() => {
                // Ne pas effacer le flag pour éviter toute boucle
                location.reload();
            }, 5000);
        } catch (error) {
            console.error('[EL LOGOUT] Erreur lors de la déconnexion:', error);
            // Nouvelle tentative légère après 2s si pas réussi
            setTimeout(() => {
                try { sessionStorage.removeItem('el_logout_done'); } catch {}
                autoLogout();
            }, 2000);
        }
    }

    // Exécuter la déconnexion automatique
    autoLogout();

    // Support des navigations SPA (pushState/replaceState) pour relancer l'auto-logout après redirection interne
    try {
        if (!window.__el_logout_hooks_installed) {
            window.__el_logout_hooks_installed = true;
            injectHistoryHook();
            let lastUrl = location.href;
            let debounceTimer = null;
            const runDebounced = () => {
                if (debounceTimer) clearTimeout(debounceTimer);
                debounceTimer = setTimeout(() => {
                    try { autoLogout(); } catch {}
                }, 250);
            };
            const triggerIfChanged = () => {
                const current = location.href;
                if (current !== lastUrl) {
                    lastUrl = current;
                    // Petite latence pour laisser le DOM se mettre à jour
                    // Ne pas effacer le flag ici pour éviter les re-déclenchements
                    runDebounced();
                }
            };

            const originalPushState = history.pushState;
            history.pushState = function() {
                const ret = originalPushState.apply(this, arguments);
                try { triggerIfChanged(); } catch {}
                return ret;
            };

            const originalReplaceState = history.replaceState;
            history.replaceState = function() {
                const ret = originalReplaceState.apply(this, arguments);
                try { triggerIfChanged(); } catch {}
                return ret;
            };

            window.addEventListener('popstate', triggerIfChanged);
            window.addEventListener('el:navigation', triggerIfChanged);
            // Observer DOM pour transitions React/Next
            try {
                const domObserver = new MutationObserver(() => {
                    if (location.hostname.endsWith('elevenlabs.io') && location.pathname.startsWith('/app')) {
                        runDebounced();
                    }
                });
                domObserver.observe(document.body, { childList: true, subtree: true });
            } catch {}
            // Fallback: polling léger au cas où l'app modifie la location sans History API
            setInterval(triggerIfChanged, 250);
        }
    } catch (_) {}

})();
