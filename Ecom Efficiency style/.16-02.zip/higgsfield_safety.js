(function () {
  'use strict';

  // --- Debug (Higgsfield) ---
  const EE_HIGGSFIELD_DEBUG = true;
  const __eeSeen = {
    banner: new WeakSet(),
    dialog: new WeakSet(),
    overlay: new WeakSet()
  };

  function eeLog() {
    if (!EE_HIGGSFIELD_DEBUG) return;
    try { console.log.apply(console, arguments); } catch (_) {}
  }

  function now() {
    try { return Date.now(); } catch (_) { return +new Date(); }
  }

  function onTarget() {
    try {
      return location.hostname === 'higgsfield.ai' || location.hostname === 'www.higgsfield.ai';
    } catch (_) {
      return false;
    }
  }

  function isBlockedPath(pathname) {
    const p = String(pathname || '');
    if (p === '/@ecomefficiency') return true;
    if (p === '/me' || p.startsWith('/me/')) return true;
    return false;
  }

  function redirectHome() {
    try {
      // Keep same origin (handles www vs non-www)
      const home = `${location.origin}/`;
      location.replace(home);
    } catch (_) {
      try { location.href = '/'; } catch (__) {}
    }
  }

  function ensureCss() {
    const id = 'ee-higgsfield-safety-css';
    if (document.getElementById(id)) return;
    const style = document.createElement('style');
    style.id = id;
    style.textContent = `
      /* Entire sensitive header area: grey + non-interactive */
      [data-ee-higgsfield-sensitive="1"] {
        filter: grayscale(1) saturate(0.15) contrast(0.95) !important;
        opacity: 0.55 !important;
        pointer-events: none !important; /* blocks click + hover */
        cursor: not-allowed !important;
      }

      /* Grey + disable profile menu trigger */
      button[data-header-menu-trigger="true"][aria-controls="profile-menu"] {
        filter: grayscale(1) saturate(0.15) contrast(0.95) !important;
        opacity: 0.55 !important;
        cursor: not-allowed !important;
      }

      /* Hide the profile menu panel itself (prevents hover-open sidebar) */
      #profile-menu {
        display: none !important;
        visibility: hidden !important;
        opacity: 0 !important;
        pointer-events: none !important;
      }

      /* If payment nags respawn, keep them hidden as last resort */
      header#header-promotion, #header-promotion { display: none !important; }
      [data-radix-portal] [role="dialog"][data-state="open"] { display: none !important; }
      [data-radix-portal] [data-radix-dialog-overlay] { display: none !important; }

      /* Requested: prevent "blurred screen" effect from payment modal */
      html, body, #__next {
        filter: none !important;
        backdrop-filter: none !important;
        -webkit-backdrop-filter: none !important;
      }
    `;
    document.documentElement.appendChild(style);

    // Add :has()-based rules separately so older engines don't drop the whole block
    try {
      const style2 = document.createElement('style');
      style2.id = 'ee-higgsfield-safety-css-has';
      style2.textContent = `
        [data-radix-popper-content-wrapper]:has(#profile-menu) { display: none !important; }
      `;
      document.documentElement.appendChild(style2);
    } catch (_) {}
  }

  function disableProfileMenuButton() {
    // Only target the intended trigger to avoid breaking credit detection in other parts of the header.
    const btn = document.querySelector('button[data-header-menu-trigger="true"][aria-controls="profile-menu"]');
    if (!btn) return false;

    // Make it non-interactive without removing it (so inner SVG/text can still be read by other scripts).
    try { btn.setAttribute('aria-disabled', 'true'); } catch (_) {}
    try { btn.setAttribute('tabindex', '-1'); } catch (_) {}
    try { btn.tabIndex = -1; } catch (_) {}
    try { btn.disabled = true; } catch (_) {}
    return true;
  }

  function markSensitiveHeaderArea() {
    // We want to disable the whole cluster containing Upgrade / Asset library / workspaces / profile,
    // but keep it in the DOM for credit detection scripts.
    const profileBtn = document.querySelector('button[data-header-menu-trigger="true"][aria-controls="profile-menu"]');
    const pricingLink = document.querySelector('a[href="/pricing"]');
    const assetLink = document.querySelector('a[href="/asset/all"]');
    let workspaceBtn = document.querySelector('div.relative.flex.items-center.h-\\[50px\\] button[aria-haspopup="true"]') || null;
    if (!workspaceBtn) {
      // :has() may not be supported in every engine; guard with try/catch.
      try {
        workspaceBtn = document.querySelector('button[aria-haspopup="true"]:has(span.truncate)') || null;
      } catch (_) {}
    }

    // Mark individual nodes too (so even if container selection fails, the items are still disabled)
    const nodesToMark = [profileBtn, pricingLink, assetLink, workspaceBtn].filter(Boolean);
    for (const n of nodesToMark) {
      try { n.setAttribute('data-ee-higgsfield-sensitive', '1'); } catch (_) {}
    }

    const seed = profileBtn || pricingLink || assetLink || workspaceBtn;
    if (!seed) return false;

    // Prefer the exact wrapper shown in your HTML snippet
    let container =
      seed.closest('div.shrink-0.grid.grid-flow-col-dense.items-center') ||
      seed.closest('div.shrink-0') ||
      null;

    // Fallback: find a common ancestor that contains both pricing and profile
    if (!container && profileBtn && pricingLink) {
      let a = profileBtn.parentElement;
      while (a && a !== document.documentElement) {
        if (a.querySelector && a.querySelector('a[href="/pricing"]')) { container = a; break; }
        a = a.parentElement;
      }
    }

    if (!container) return false;

    try { container.setAttribute('data-ee-higgsfield-sensitive', '1'); } catch (_) {}
    return true;
  }

  function swallowClicksOnProfileButton() {
    // Capturing listener to reliably block clicks even if site re-enables the button.
    if (window.__eeHiggsfieldSwallowProfileClicks) return;
    window.__eeHiggsfieldSwallowProfileClicks = true;

    const swallow = (e) => {
      try {
        const t = e.target;
        const btn = t && t.closest
          ? t.closest('button[data-header-menu-trigger="true"][aria-controls="profile-menu"]')
          : null;
        if (!btn) return;
        e.preventDefault();
        e.stopPropagation();
      } catch (_) {}
    };

    // Also block hover-trigger events that may open sidebars/menus.
    ['click', 'mousedown', 'mouseup', 'pointerdown', 'pointerup', 'touchstart', 'touchend', 'contextmenu', 'keydown', 'mouseover', 'pointerover']
      .forEach((evt) => document.addEventListener(evt, swallow, true));
  }

  function hideProfileMenuIfPresent() {
    // Best-effort: if the app injects a menu/popover for the profile, hide/remove it.
    const menu = document.getElementById('profile-menu');
    if (menu) {
      try { menu.style.display = 'none'; } catch (_) {}
      try { menu.setAttribute('aria-hidden', 'true'); } catch (_) {}
    }

    // Some libs wrap the menu in a popper/portal wrapper
    try {
      const wrappers = Array.from(document.querySelectorAll('[data-radix-popper-content-wrapper]'));
      for (const w of wrappers) {
        if (w.querySelector && w.querySelector('#profile-menu')) {
          try { w.style.display = 'none'; } catch (_) {}
        }
      }
    } catch (_) {}
  }

  // ===== Requested: remove banner + payment popup on Higgsfield =====
  function hideElementHard(el, kind) {
    if (!el || el.nodeType !== 1) return false;
    try {
      el.style.setProperty('display', 'none', 'important');
      el.style.setProperty('visibility', 'hidden', 'important');
      el.style.setProperty('opacity', '0', 'important');
      el.style.setProperty('pointer-events', 'none', 'important');
    } catch (_) {}
    try { el.setAttribute('aria-hidden', 'true'); } catch (_) {}
    try { el.setAttribute('data-ee-hidden', kind || '1'); } catch (_) {}
    try { el.inert = true; } catch (_) {} // Chromium supports inert
    return true;
  }

  function unblurPage() {
    // Remove any residual blur/filter/backdrop-filter that can remain after modals
    const roots = [];
    try { roots.push(document.documentElement); } catch (_) {}
    try { roots.push(document.body); } catch (_) {}
    try {
      const next = document.getElementById('__next');
      if (next) roots.push(next);
    } catch (_) {}

    for (const r of roots) {
      if (!r || !r.style) continue;
      try { r.style.setProperty('filter', 'none', 'important'); } catch (_) {}
      try { r.style.setProperty('backdrop-filter', 'none', 'important'); } catch (_) {}
      try { r.style.setProperty('-webkit-backdrop-filter', 'none', 'important'); } catch (_) {}
    }

    // Also neutralize common "blur" utility classes/inline styles on containers
    try {
      const maybeBlurred = document.querySelectorAll(
        '[style*="backdrop-filter"],[style*="filter: blur"],[class*="backdrop-blur"],[class*="blur"]'
      );
      for (const el of maybeBlurred) {
        try { el.style.setProperty('filter', 'none', 'important'); } catch (_) {}
        try { el.style.setProperty('backdrop-filter', 'none', 'important'); } catch (_) {}
        try { el.style.setProperty('-webkit-backdrop-filter', 'none', 'important'); } catch (_) {}
      }
    } catch (_) {}
  }

  function restoreInteractivity() {
    // Some modal implementations disable the underlying app using inert/aria-hidden/pointer-events.
    // If we hide the modal visually, we must also re-enable interactions.
    let removedInert = 0;
    let removedAriaHidden = 0;

    const shouldSkip = (el) => {
      try {
        if (!el || el.nodeType !== 1) return true;
        // Don't touch elements we intentionally hid (modals/overlays)
        if (el.hasAttribute && el.hasAttribute('data-ee-hidden')) return true;
        if (el.closest && el.closest('[data-ee-hidden]')) return true;
        return false;
      } catch (_) {
        return false;
      }
    };

    // 1) Remove inert flags
    try {
      const inertEls = document.querySelectorAll('[inert]');
      inertEls.forEach((el) => {
        if (shouldSkip(el)) return;
        try { el.inert = false; } catch (_) {}
        try { el.removeAttribute('inert'); } catch (_) {}
        removedInert++;
      });
    } catch (_) {}

    // 2) Remove aria-hidden that blocks interactions on major roots
    try {
      const roots = [];
      const next = document.getElementById('__next');
      if (next) roots.push(next);
      if (document.body) roots.push(document.body);

      roots.forEach((el) => {
        if (shouldSkip(el)) return;
        try {
          if (el.getAttribute && el.getAttribute('aria-hidden') === 'true') {
            el.removeAttribute('aria-hidden');
            removedAriaHidden++;
          }
        } catch (_) {}
        try {
          if (el.getAttribute && el.getAttribute('data-aria-hidden') === 'true') {
            el.removeAttribute('data-aria-hidden');
            removedAriaHidden++;
          }
        } catch (_) {}
      });
    } catch (_) {}

    // 3) Ensure pointer-events are enabled on the main app container
    try {
      const next = document.getElementById('__next');
      if (next && !shouldSkip(next)) {
        next.style.setProperty('pointer-events', 'auto', 'important');
      }
      if (document.body) {
        document.body.style.setProperty('pointer-events', 'auto', 'important');
      }
    } catch (_) {}

    // 4) Undo common "modal open" scroll locks (not required for clicks, but helps UX)
    try {
      if (document.body) document.body.style.setProperty('overflow', 'auto', 'important');
    } catch (_) {}

    // Log once in a while when we actually change something
    try {
      if ((removedInert || removedAriaHidden) && !window.__eeHiggsfieldInteractivityLoggedAt) {
        window.__eeHiggsfieldInteractivityLoggedAt = Date.now();
        eeLog('[EE][HIGGSFIELD] Restored interactivity', { removedInert, removedAriaHidden });
        setTimeout(() => { try { delete window.__eeHiggsfieldInteractivityLoggedAt; } catch (_) {} }, 1500);
      }
    } catch (_) {}
  }

  function removePromoBanner() {
    try {
      const headers = document.querySelectorAll('header#header-promotion, #header-promotion');
      for (const h of headers) {
        if (!h) continue;
        try {
          if (!__eeSeen.banner.has(h)) {
            __eeSeen.banner.add(h);
            eeLog('[EE][HIGGSFIELD] Banner detected -> hiding', h);
          }
        } catch (_) {}
        // IMPORTANT: do not remove React-managed nodes (can cause client-side exceptions).
        hideElementHard(h, 'banner');
      }
    } catch (_) {}
  }

  function removePaymentNagDialogs() {
    let removedAny = false;

    // Match the Radix dialog structure you pasted (role=dialog + data-state=open + often id starts with "radix-")
    let dialogs = [];
    try {
      dialogs = Array.from(document.querySelectorAll('div[role="dialog"][data-state="open"], [data-radix-portal] div[role="dialog"]'));
    } catch (_) {}

    for (const dlg of dialogs) {
      if (!dlg || dlg.nodeType !== 1) continue;

      let txt = '';
      try { txt = String(dlg.textContent || '').toLowerCase(); } catch (_) {}

      const looksLikePayment =
        txt.includes('payment required') ||
        txt.includes('payment failed') ||
        txt.includes('billing issue') ||
        txt.includes('update payment method') ||
        txt.includes('on-demand usage is currently suspended') ||
        txt.includes("couldn't collect") ||
        txt.includes('on-demand');

      const hasCenteredFixedClass = (() => {
        try {
          const cn = dlg.className;
          return typeof cn === 'string' && cn.includes('fixed') && cn.includes('left-1/2') && cn.includes('top-1/2');
        } catch (_) { return false; }
      })();

      const hasRadixId = (() => {
        try { return typeof dlg.id === 'string' && dlg.id.startsWith('radix-'); } catch (_) { return false; }
      })();

      if (!looksLikePayment && !hasCenteredFixedClass && !hasRadixId) continue;

      try {
        if (!__eeSeen.dialog.has(dlg)) {
          __eeSeen.dialog.add(dlg);
          eeLog('[EE][HIGGSFIELD] Payment dialog detected -> hiding', { id: dlg.id, className: dlg.className }, dlg);
        }
      } catch (_) {}

      // IMPORTANT: do not remove portal/dialog nodes (React can crash on unmount).
      try {
        const portal = dlg.closest('div[data-radix-portal]');
        if (portal) hideElementHard(portal, 'payment-portal');
        else hideElementHard(dlg, 'payment-dialog');
        removedAny = true;
      } catch (_) {}
    }

    // Hide overlays that might still block clicks / blur the page (even if dialog already hidden)
    if (removedAny) {
      try {
        const overlays = document.querySelectorAll('[data-radix-dialog-overlay], [data-radix-dialog-overlay=""], [data-radix-portal] [data-radix-dialog-overlay]');
        overlays.forEach((el) => {
          try {
            if (!__eeSeen.overlay.has(el)) {
              __eeSeen.overlay.add(el);
              eeLog('[EE][HIGGSFIELD] Overlay detected -> hiding (radix)', el);
            }
          } catch (_) {}
          hideElementHard(el, 'payment-overlay');
        });
      } catch (_) {}
    }

    // Additional fullscreen overlays used by Higgsfield (ex: <div class="fixed inset-0 bg-black/80 backdrop-blur-sm ...">)
    try {
      const extra = document.querySelectorAll(
        'div.fixed.inset-0[data-state="open"], div.fixed.inset-0[aria-hidden="true"], div.fixed.inset-0[data-aria-hidden="true"]'
      );
      extra.forEach((el) => {
        try {
          const cn = String(el.className || '');
          const looksLikeBlurOverlay =
            cn.includes('backdrop-blur') ||
            cn.includes('bg-black') ||
            cn.includes('bg-slate') ||
            cn.includes('bg-neutral');
          if (!looksLikeBlurOverlay) return;

          if (!__eeSeen.overlay.has(el)) {
            __eeSeen.overlay.add(el);
            eeLog('[EE][HIGGSFIELD] Overlay detected -> hiding (fullscreen blur)', el);
          }
        } catch (_) {}
        hideElementHard(el, 'fullscreen-overlay');
      });
    } catch (_) {}
  }

  function runUiBlockers() {
    removePromoBanner();
    removePaymentNagDialogs();
    unblurPage();
    restoreInteractivity();
  }

  function handleRoute() {
    if (!onTarget()) return;
    if (isBlockedPath(location.pathname)) {
      redirectHome();
      return;
    }

    ensureCss();
    runUiBlockers();
    markSensitiveHeaderArea();
    swallowClicksOnProfileButton();
    disableProfileMenuButton();
    hideProfileMenuIfPresent();
  }

  // Throttle re-application to avoid heavy loops on SPA re-renders.
  let __eeHfLastRunAt = 0;
  let __eeHfScheduled = false;
  function scheduleHandleRoute() {
    const t = now();
    if (t - __eeHfLastRunAt > 200) {
      __eeHfLastRunAt = t;
      try { handleRoute(); } catch (_) {}
      return;
    }
    if (__eeHfScheduled) return;
    __eeHfScheduled = true;
    setTimeout(() => {
      __eeHfScheduled = false;
      __eeHfLastRunAt = now();
      try { handleRoute(); } catch (_) {}
    }, 220);
  }

  // Run ASAP
  scheduleHandleRoute();

  // User requested: watch every 0.5s (popup can come later)
  try {
    if (!window.__eeHiggsfieldUiWatchdog) {
      window.__eeHiggsfieldUiWatchdog = true;
      const start = () => {
        eeLog('[EE][HIGGSFIELD] UI watchdog enabled (500ms)');
        setInterval(() => {
          try { runUiBlockers(); } catch (_) {}
        }, 500);
      };

      // Delay until after initial React hydration to avoid minified React errors / client-side exceptions
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => setTimeout(start, 600), { once: true });
      } else {
        setTimeout(start, 600);
      }
    }
  } catch (_) {}

  // Observe SPA navigations
  (function patchHistory() {
    try {
      const pushState = history.pushState;
      const replaceState = history.replaceState;
      history.pushState = function () {
        const r = pushState.apply(this, arguments);
        setTimeout(scheduleHandleRoute, 0);
        return r;
      };
      history.replaceState = function () {
        const r = replaceState.apply(this, arguments);
        setTimeout(scheduleHandleRoute, 0);
        return r;
      };
      window.addEventListener('popstate', scheduleHandleRoute, true);
    } catch (_) {}
  })();

  // Keep it applied if the app re-renders
  try {
    const mo = new MutationObserver(() => {
      try { scheduleHandleRoute(); } catch (_) {}
    });
    mo.observe(document.documentElement, { childList: true, subtree: true });
    setTimeout(() => { try { mo.disconnect(); } catch (_) {} }, 60000);
  } catch (_) {}
})();

