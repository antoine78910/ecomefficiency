// sendshort_privacy_blur.js
// Privacy: blur + grayscale + non-clickable shorts grid on SendShort
(function () {
  'use strict';

  if (!location || !String(location.hostname || '').endsWith('sendshort.ai')) return;
  if (location.hostname !== 'app.sendshort.ai') return;

  const STYLE_ID = 'ee-sendshort-privacy-style';
  const NOTE_ID = 'ee-sendshort-privacy-note';

  function ensureStyle() {
    try {
      if (document.getElementById(STYLE_ID)) return;
      const style = document.createElement('style');
      style.id = STYLE_ID;
      style.textContent = `
        /* Target the main shorts grid container (stable class + sentry markers) */
        .my-shorts,
        [data-sentry-component="ShortsGrid"] {
          position: relative !important;
          user-select: none !important;
        }

        /* Blur/grayscale the CONTENT, but keep the privacy note sharp */
        .my-shorts > *:not(#${NOTE_ID}),
        [data-sentry-component="ShortsGrid"] > *:not(#${NOTE_ID}) {
          filter: grayscale(1) blur(7px) !important;
          opacity: 0.55 !important;
          pointer-events: none !important;
          user-select: none !important;
          cursor: not-allowed !important;
        }

        /* Also block interactions deeper in the tree */
        .my-shorts > *:not(#${NOTE_ID}) *,
        [data-sentry-component="ShortsGrid"] > *:not(#${NOTE_ID}) * {
          pointer-events: none !important;
          user-select: none !important;
          cursor: not-allowed !important;
        }

        /* Privacy note (visible, unblurred) */
        #${NOTE_ID} {
          position: sticky;
          top: 12px;
          z-index: 9999;
          width: fit-content;
          max-width: min(720px, calc(100% - 24px));
          margin: 12px auto 8px auto;
          padding: 10px 14px;
          border-radius: 12px;
          background: rgba(0, 0, 0, 0.72);
          color: #fff;
          font: 600 13px/1.25 Inter, system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
          letter-spacing: 0.2px;
          pointer-events: none;
          user-select: none;
          box-shadow: 0 10px 30px rgba(0,0,0,0.25);
          border: 1px solid rgba(255,255,255,0.12);
          backdrop-filter: blur(6px);
          -webkit-backdrop-filter: blur(6px);
        }
      `;
      (document.head || document.documentElement).appendChild(style);
    } catch (_) {}
  }

  function findGridContainer() {
    try {
      return (
        document.querySelector('.MuiGrid-root.my-shorts') ||
        document.querySelector('.my-shorts') ||
        document.querySelector('[data-sentry-component="ShortsGrid"]')
      );
    } catch (_) {
      return null;
    }
  }

  function ensurePrivacyNote() {
    try {
      const grid = findGridContainer();
      if (!grid) return;
      if (grid.querySelector && grid.querySelector('#' + NOTE_ID)) return;

      const note = document.createElement('div');
      note.id = NOTE_ID;
      note.textContent = "We respect your privacy — this is a shared account. Shorts are blurred for members' privacy.";
      // Insert at the top of the grid container
      grid.insertBefore(note, grid.firstChild || null);
    } catch (_) {}
  }

  function installSwallow() {
    try {
      if (window.__eeSendshortPrivacySwallowInstalled) return;
      window.__eeSendshortPrivacySwallowInstalled = true;

      const swallow = (e) => {
        try {
          const t = e.target;
          if (!t || !t.closest) return;
          const grid =
            t.closest('.my-shorts') ||
            t.closest('[data-sentry-component="ShortsGrid"]');
          if (!grid) return;
          e.preventDefault();
          e.stopPropagation();
          if (e.stopImmediatePropagation) e.stopImmediatePropagation();
          return false;
        } catch (_) {}
      };

      ['click', 'mousedown', 'mouseup', 'pointerdown', 'pointerup', 'touchstart', 'touchend', 'contextmenu', 'keydown']
        .forEach((evt) => document.addEventListener(evt, swallow, true));
    } catch (_) {}
  }

  function start() {
    ensureStyle();
    ensurePrivacyNote();
    installSwallow();

    // Re-apply if the app hot-swaps roots (SPA/MUI)
    try {
      const mo = new MutationObserver(() => {
        try { ensureStyle(); } catch (_) {}
        try { ensurePrivacyNote(); } catch (_) {}
      });
      mo.observe(document.documentElement, { childList: true, subtree: true });
      setTimeout(() => { try { mo.disconnect(); } catch (_) {} }, 5 * 60 * 1000);
    } catch (_) {}
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
})();

