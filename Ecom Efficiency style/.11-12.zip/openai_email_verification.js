(function() {
  'use strict';

  let lastCode = null;
  let isRequesting = false;

  function onTarget() {
    try {
      if (location.hostname !== 'auth.openai.com') return false;
      const path = location.pathname || '';
      return path.includes('email-verification') || path.includes('mfa-challenge');
    } catch (_) {
      return false;
    }
  }

  function isEmailOtpPage() {
    try {
      return location.pathname.includes('/mfa-challenge/email-otp');
    } catch (_) { return false; }
  }

  function ensureOverlay() {
    if (!onTarget()) return;
    if (document.getElementById('ee-otp-overlay')) return;
    const overlay = document.createElement('div');
    overlay.id = 'ee-otp-overlay';
    Object.assign(overlay.style, {
      position: 'fixed', top: '12px', right: '12px', zIndex: '2147483647',
      width: '220px', minHeight: '80px', background: 'rgba(0,0,0,0.7)', color: '#fff',
      borderRadius: '10px', padding: '12px', display: 'flex', flexDirection: 'column',
      alignItems: 'center', gap: '8px', boxShadow: '0 4px 16px rgba(0,0,0,0.25)'
    });

    const spinner = document.createElement('div');
    Object.assign(spinner.style, {
      width: '28px', height: '28px', border: '3px solid rgba(255,255,255,0.3)',
      borderTopColor: '#fff', borderRadius: '50%', animation: 'ee-otp-spin 1s linear infinite'
    });
    const style = document.createElement('style');
    style.textContent = '@keyframes ee-otp-spin{to{transform:rotate(360deg)}}';

    const label = document.createElement('div');
    label.textContent = 'loading for your code';
    label.style.fontSize = '12px';
    label.style.opacity = '0.9';

    const result = document.createElement('div');
    result.id = 'ee-otp-result';
    Object.assign(result.style, { fontSize: '16px', fontWeight: 'bold' });

    const copyBtn = document.createElement('button');
    copyBtn.id = 'ee-otp-copy';
    copyBtn.textContent = 'Copy code';
    Object.assign(copyBtn.style, { display: 'none', fontSize: '12px', padding: '6px 10px', borderRadius: '6px', border: '1px solid #888', background: '#222', color: '#fff', cursor: 'pointer' });

    const retryBtn = document.createElement('button');
    retryBtn.id = 'ee-otp-retry';
    retryBtn.textContent = 'Retry';
    Object.assign(retryBtn.style, { display: 'none', fontSize: '12px', padding: '6px 10px', borderRadius: '6px', border: '1px solid #888', background: '#222', color: '#fff', cursor: 'pointer' });
    retryBtn.onclick = () => { 
      lastCode = null; 
      isRequesting = false;
      const r = document.getElementById('ee-otp-result'); 
      if (r) r.textContent = ''; 
      requestOtp(); 
    };

    const helpLink = document.createElement('a');
    helpLink.id = 'ee-otp-help';
    helpLink.textContent = 'If you don\'t have any code, copy paste the code you see on this page';
    helpLink.href = 'http://51.83.103.21:20016/otp';
    helpLink.target = '_blank';
    Object.assign(helpLink.style, { 
      display: 'block', 
      fontSize: '10px', 
      color: '#888', 
      textDecoration: 'underline', 
      cursor: 'pointer',
      textAlign: 'center',
      marginTop: '6px',
      wordBreak: 'break-word',
      opacity: '0.8'
    });

    overlay.appendChild(style);
    overlay.appendChild(spinner);
    overlay.appendChild(label);
    overlay.appendChild(result);
    overlay.appendChild(copyBtn);
    overlay.appendChild(retryBtn);
    overlay.appendChild(helpLink);

    document.documentElement.appendChild(overlay);
  }

  function setCode(code) {
    const result = document.getElementById('ee-otp-result');
    const copyBtn = document.getElementById('ee-otp-copy');
    const retryBtn = document.getElementById('ee-otp-retry');
    const helpLink = document.getElementById('ee-otp-help');
    if (!result || !copyBtn) return;
    result.textContent = code;
    copyBtn.style.display = 'inline-block';
    if (retryBtn) retryBtn.style.display = 'none';
    // Le lien d'aide reste toujours visible maintenant

    tryAutoFill(code);
    copyBtn.onclick = async function() {
      try {
        await navigator.clipboard.writeText(code);
        copyBtn.textContent = 'Copied';
        setTimeout(() => { copyBtn.textContent = 'Copy code'; }, 1200);
      } catch (_) {}
    };
  }

  async function requestOtp() {
    console.log('[EE-OTP] requestOtp called, isRequesting:', isRequesting, 'lastCode:', lastCode);
    if (isRequesting) {
      console.log('[EE-OTP] Already requesting, skipping');
      return;
    }
    if (lastCode) {
      console.log('[EE-OTP] Using cached code:', lastCode);
      setCode(lastCode);
      return;
    }
    
    console.log('[EE-OTP] Fetching new code...');
    isRequesting = true;
    
    // Essayer plusieurs fois avec des délais
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        console.log('[EE-OTP] Attempt', attempt + 1, 'of 3');
        
        // Utiliser une promesse avec timeout pour éviter les problèmes de message channel
        const response = await new Promise((resolve, reject) => {
          const timeout = setTimeout(() => {
            reject(new Error('Request timeout after 15 seconds'));
          }, 15000);
          
          chrome.runtime.sendMessage({ type: 'FETCH_OPENAI_OTP' }, (response) => {
            clearTimeout(timeout);
            
            // Vérifier les erreurs de Chrome
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
              return;
            }
            
            resolve(response);
          });
        });
        
        console.log('[EE-OTP] Response from background:', response);
        
        if (response && response.ok && response.code && response.code.toString().length >= 4) {
          lastCode = response.code;
          console.log('[EE-OTP] Code received:', response.code);
          setCode(response.code);
          isRequesting = false;
          return; // Succès, sortir de la boucle
        } else {
          console.log('[EE-OTP] No valid code found:', response);
          if (attempt === 2) { // Dernière tentative
            const result = document.getElementById('ee-otp-result');
            const retryBtn = document.getElementById('ee-otp-retry');
            if (result) result.textContent = (response && response.error) ? ('Error: ' + response.error) : 'No code found';
            if (retryBtn) retryBtn.style.display = 'inline-block';
          }
        }
      } catch (e) {
        console.error('[EE-OTP] Error attempt', attempt + 1, ':', e);
        if (attempt === 2) { // Dernière tentative
          const result = document.getElementById('ee-otp-result');
          const retryBtn = document.getElementById('ee-otp-retry');
          if (result) result.textContent = 'Error: ' + String(e);
          if (retryBtn) retryBtn.style.display = 'inline-block';
        }
      }
      
      // Attendre avant la prochaine tentative (sauf pour la dernière)
      if (attempt < 2) {
        console.log('[EE-OTP] Waiting before retry...');
        await new Promise(resolve => setTimeout(resolve, 2000 + attempt * 1000));
      }
    }
    
    isRequesting = false;
  }

  // Try to find and fill the OTP input
  function findOtpInput() {
    // Match input attributes per provided sample
    const inputs = Array.from(document.querySelectorAll('input[type="text"][name="code"], input[autocomplete="one-time-code"], input[inputmode="numeric"]'));
    return inputs.find((el) => el && el.maxLength === 6 || (el.getAttribute && el.getAttribute('maxlength') === '6')) || null;
  }

  function tryAutoFill(code) {
    // Ne plus remplir automatiquement l'input pour éviter les interférences
    // L'utilisateur peut copier-coller manuellement le code affiché
    console.log('[EE-OTP] Code available for manual copy-paste:', code);
  }

  // Fonction de clic automatique supprimée pour éviter les interférences
  // L'utilisateur peut maintenant interagir manuellement avec la page

  // --- MFA navigation helpers ---
  let mfaNavTimer = null;

  function clickLinkByTextOrHref(options = []) {
    for (const opt of options) {
      const { href, text } = opt;
      const candidates = Array.from(document.querySelectorAll('a,button'));
      const found = candidates.find((el) => {
        const t = (el.textContent || '').toLowerCase().trim();
        const h = (el.getAttribute('href') || '').trim();
        const okHref = href ? h === href || h === href + '/' : true;
        const okText = text ? t.includes(text.toLowerCase()) : true;
        return okHref && okText && el.offsetParent !== null;
      });
      if (found) {
        console.log('[EE-OTP] Clicking link/button:', found.outerHTML.slice(0, 140));
        try { found.click(); return true; } catch (_) {}
      }
    }
    return false;
  }

  function scheduleMfaNavigation() {
    if (mfaNavTimer) return;
    mfaNavTimer = setInterval(() => {
      if (location.hostname !== 'auth.openai.com') return;
      const path = location.pathname || '';

      // Stop timer once we reach the email OTP page
      if (isEmailOtpPage()) {
        console.log('[EE-OTP] Reached /mfa-challenge/email-otp, stopping nav timer');
        clearInterval(mfaNavTimer);
        mfaNavTimer = null;
        return;
      }

      // Step 1: on /mfa-challenge/ (with trailing slash OR token) -> click "Try another method"
      if (/^\/mfa-challenge(\/|$)/.test(path) && !path.includes('email-otp')) {
        const clickedTry = clickLinkByTextOrHref([
          { href: '/mfa-challenge', text: 'try another method' },
          { text: 'try another method' }
        ]);
        if (clickedTry) return;
      }

      // Step 2: on /mfa-challenge (no trailing slash) -> click Email option
      if (path === '/mfa-challenge') {
        const clickedEmail = clickLinkByTextOrHref([
          { href: '/mfa-challenge/email-otp', text: 'email' },
          { text: 'email' }
        ]);
        if (clickedEmail) return;
      }
    }, 600);
  }

  function run() {
    // Always start MFA navigation helper on auth.openai.com
    if (location.hostname === 'auth.openai.com') {
      scheduleMfaNavigation();
    }
    if (!onTarget()) return;
    // Only show overlay + request code on email-verification or email-otp page
    if (!isEmailOtpPage() && !location.pathname.includes('email-verification')) {
      return;
    }
    ensureOverlay();
    requestOtp();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run);
  } else {
    run();
  }

  // React to SPA navigations and rerenders
  const mo = new MutationObserver(() => {
    if (onTarget()) {
      ensureOverlay();
      if (isEmailOtpPage() || location.pathname.includes('email-verification')) {
        // Force new request on each navigation to get latest code
        lastCode = null;
        isRequesting = false;
        requestOtp();
        // Also attempt to auto-fill if we already have a code visible
        const txt = (document.getElementById('ee-otp-result') || {}).textContent || '';
        const m = txt && txt.match(/\b(\d{6})\b/);
        if (m && m[1]) tryAutoFill(m[1]);
      }
    }
  });
  mo.observe(document.documentElement, { childList: true, subtree: true });

  // Detect route changes via history API
  const _ps = history.pushState, _rs = history.replaceState;
  function onNav(){ setTimeout(() => { if (onTarget()) run(); }, 50); }
  history.pushState = function(){ const r = _ps.apply(this, arguments); onNav(); return r; };
  history.replaceState = function(){ const r = _rs.apply(this, arguments); onNav(); return r; };
  window.addEventListener('popstate', onNav, true);
})();


