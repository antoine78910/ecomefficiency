// remove_dropship_banner.js
(function() {
  // Exécute sur toutes les pages de dropship.io
  if (!window.location.href.startsWith('https://app.dropship.io/')) return;

  function markDisabled(el) {
    try {
      el.style.pointerEvents = 'none';
      el.style.opacity = '0.5';
      el.style.userSelect = 'none';
      el.setAttribute('aria-disabled', 'true');
      el.setAttribute('tabindex', '-1');
      el.title = 'Désactivé par extension';
    } catch (_) {}
  }

  function swallowEvents(el) {
    if (!el || el.__eeDropshipSwallow) return;
    el.__eeDropshipSwallow = true;
    const swallow = (e) => {
      try { e.preventDefault(); } catch (_) {}
      try { e.stopPropagation(); } catch (_) {}
      try { e.stopImmediatePropagation && e.stopImmediatePropagation(); } catch (_) {}
      return false;
    };
    ['click','mousedown','mouseup','pointerdown','pointerup','touchstart','touchend','contextmenu','keydown'].forEach(evt => {
      try { el.addEventListener(evt, swallow, true); } catch (_) {}
    });
  }

  function removeElements() {
    // Supprime la bannière limited-banner
    const banner = document.querySelector('div.limited-banner');
    if (banner) banner.remove();
    // Supprime les éléments adLibrary-item-insights
    document.querySelectorAll('div.adLibrary-item-insights').forEach(el => el.remove());

    // Supprime le bouton "Upgrade plan" (classes peuvent changer → fallback par texte)
    try {
      const btns = Array.from(document.querySelectorAll('button, a[role="button"], div[role="button"]')).slice(0, 5000);
      for (const el of btns) {
        const txt = String(el.textContent || '').trim().toLowerCase();
        const cls = String(el.className || '');
        const isUpgradeByClass = /\bmain-sidebar-free-button\b/.test(cls) || /\bfree-button\b/.test(cls);
        const isUpgradeByText = txt === 'upgrade plan' || txt === 'upgrade' || txt.includes('upgrade plan');
        if (isUpgradeByClass || isUpgradeByText) {
          try { el.remove(); } catch (_) { try { el.style.display = 'none'; } catch (__) {} }
        }
      }
    } catch (_) {}

    // Griser/désactiver le bouton profil / user menu (classes peuvent changer)
    try {
      const candidates = new Set();
      document.querySelectorAll('.user-dropdown, [class*="user-dropdown"], [class*="userDropdown"], [class*="profile-dropdown"], [class*="profileDropdown"]').forEach(n => candidates.add(n));

      // Heuristic: buttons/areas with avatar + dropdown-ish class
      const maybeButtons = Array.from(document.querySelectorAll('button, a[role="button"], div[role="button"]')).slice(0, 4000);
      for (const el of maybeButtons) {
        const cls = String(el.className || '').toLowerCase();
        if (!(cls.includes('user') || cls.includes('profile') || cls.includes('account'))) continue;
        if (!(cls.includes('drop') || cls.includes('menu') || cls.includes('avatar'))) continue;
        candidates.add(el);
      }

      // Also: anything containing an email in a user-ish container
      const userish = Array.from(document.querySelectorAll('aside, nav, header, [class*="sidebar"], [class*="Sidebar"]')).slice(0, 50);
      for (const root of userish) {
        const els = Array.from(root.querySelectorAll('button, a, div')).slice(0, 1500);
        for (const el of els) {
          const t = String(el.textContent || '').trim();
          if (!t || t.length > 120) continue;
          if (t.includes('@') && /user|profile|account|dropdown|menu/i.test(String(el.className || ''))) {
            candidates.add(el);
          }
        }
      }

      candidates.forEach(el => { markDisabled(el); swallowEvents(el); });
    } catch (_) {}
  }

  function start() {
    removeElements();
    // MutationObserver (preferred) + small interval fallback
    try {
      const mo = new MutationObserver(() => { try { removeElements(); } catch (_) {} });
      mo.observe(document.documentElement, { childList: true, subtree: true, attributes: true });
      setTimeout(() => { try { mo.disconnect(); } catch (_) {} }, 5 * 60 * 1000);
    } catch (_) {}
    setInterval(() => { try { removeElements(); } catch (_) {} }, 900);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
})();
