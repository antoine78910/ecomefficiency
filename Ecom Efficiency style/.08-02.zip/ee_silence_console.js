(function () {
  'use strict';

  // Silence extension logs in the content-script world.
  // (Does not affect the website's own console output unless that page itself is overridden.)
  try {
    const noop = function () {};
    const c = console;
    if (!c) return;
    // Keep a reference for potential debugging in-page if needed.
    // eslint-disable-next-line no-underscore-dangle
    c.__ee_original__ = c.__ee_original__ || {
      log: c.log,
      info: c.info,
      warn: c.warn,
      error: c.error,
      debug: c.debug,
      trace: c.trace,
      group: c.group,
      groupCollapsed: c.groupCollapsed,
      groupEnd: c.groupEnd
    };
    c.log = noop;
    c.info = noop;
    c.warn = noop;
    c.error = noop;
    c.debug = noop;
    c.trace = noop;
    c.group = noop;
    c.groupCollapsed = noop;
    c.groupEnd = noop;
  } catch (_) {}
})();

