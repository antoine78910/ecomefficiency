(function () {
  'use strict';

  function now() {
    try { return Date.now(); } catch (_) { return +new Date(); }
  }

  function onTarget() {
    try {
      return location.hostname === 'higgsfield.ai' || location.hostname === 'www.higgsfield.ai';
    } catch (_) {
      return false;
    }
  }

  function isBlockedPath(pathname) {
    const p = String(pathname || '');
    if (p === '/@ecomefficiency') return true;
    if (p === '/me' || p.startsWith('/me/')) return true;
    return false;
  }

  function redirectHome() {
    try {
      // Keep same origin (handles www vs non-www)
      const home = `${location.origin}/`;
      location.replace(home);
    } catch (_) {
      try { location.href = '/'; } catch (__) {}
    }
  }

  function ensureCss() {
    const id = 'ee-higgsfield-safety-css';
    if (document.getElementById(id)) return;
    const style = document.createElement('style');
    style.id = id;
    style.textContent = `
      /* Entire sensitive header area: grey + non-interactive */
      [data-ee-higgsfield-sensitive="1"] {
        filter: grayscale(1) saturate(0.15) contrast(0.95) !important;
        opacity: 0.55 !important;
        pointer-events: none !important; /* blocks click + hover */
        cursor: not-allowed !important;
      }

      /* Grey + disable profile menu trigger */
      button[data-header-menu-trigger="true"][aria-controls="profile-menu"] {
        filter: grayscale(1) saturate(0.15) contrast(0.95) !important;
        opacity: 0.55 !important;
        cursor: not-allowed !important;
      }

      /* Hide the profile menu panel itself (prevents hover-open sidebar) */
      #profile-menu {
        display: none !important;
        visibility: hidden !important;
        opacity: 0 !important;
        pointer-events: none !important;
      }
    `;
    document.documentElement.appendChild(style);

    // Add :has()-based rules separately so older engines don't drop the whole block
    try {
      const style2 = document.createElement('style');
      style2.id = 'ee-higgsfield-safety-css-has';
      style2.textContent = `
        [data-radix-popper-content-wrapper]:has(#profile-menu) { display: none !important; }
      `;
      document.documentElement.appendChild(style2);
    } catch (_) {}
  }

  function disableProfileMenuButton() {
    // Only target the intended trigger to avoid breaking credit detection in other parts of the header.
    const btn = document.querySelector('button[data-header-menu-trigger="true"][aria-controls="profile-menu"]');
    if (!btn) return false;

    // Make it non-interactive without removing it (so inner SVG/text can still be read by other scripts).
    try { btn.setAttribute('aria-disabled', 'true'); } catch (_) {}
    try { btn.setAttribute('tabindex', '-1'); } catch (_) {}
    try { btn.tabIndex = -1; } catch (_) {}
    try { btn.disabled = true; } catch (_) {}
    return true;
  }

  function markSensitiveHeaderArea() {
    // We want to disable the whole cluster containing Upgrade / Asset library / workspaces / profile,
    // but keep it in the DOM for credit detection scripts.
    const profileBtn = document.querySelector('button[data-header-menu-trigger="true"][aria-controls="profile-menu"]');
    const pricingLink = document.querySelector('a[href="/pricing"]');
    const assetLink = document.querySelector('a[href="/asset/all"]');
    let workspaceBtn = document.querySelector('div.relative.flex.items-center.h-\\[50px\\] button[aria-haspopup="true"]') || null;
    if (!workspaceBtn) {
      // :has() may not be supported in every engine; guard with try/catch.
      try {
        workspaceBtn = document.querySelector('button[aria-haspopup="true"]:has(span.truncate)') || null;
      } catch (_) {}
    }

    // Mark individual nodes too (so even if container selection fails, the items are still disabled)
    const nodesToMark = [profileBtn, pricingLink, assetLink, workspaceBtn].filter(Boolean);
    for (const n of nodesToMark) {
      try { n.setAttribute('data-ee-higgsfield-sensitive', '1'); } catch (_) {}
    }

    const seed = profileBtn || pricingLink || assetLink || workspaceBtn;
    if (!seed) return false;

    // Prefer the exact wrapper shown in your HTML snippet
    let container =
      seed.closest('div.shrink-0.grid.grid-flow-col-dense.items-center') ||
      seed.closest('div.shrink-0') ||
      null;

    // Fallback: find a common ancestor that contains both pricing and profile
    if (!container && profileBtn && pricingLink) {
      let a = profileBtn.parentElement;
      while (a && a !== document.documentElement) {
        if (a.querySelector && a.querySelector('a[href="/pricing"]')) { container = a; break; }
        a = a.parentElement;
      }
    }

    if (!container) return false;

    try { container.setAttribute('data-ee-higgsfield-sensitive', '1'); } catch (_) {}
    return true;
  }

  function swallowClicksOnProfileButton() {
    // Capturing listener to reliably block clicks even if site re-enables the button.
    if (window.__eeHiggsfieldSwallowProfileClicks) return;
    window.__eeHiggsfieldSwallowProfileClicks = true;

    const swallow = (e) => {
      try {
        const t = e.target;
        const btn = t && t.closest
          ? t.closest('button[data-header-menu-trigger="true"][aria-controls="profile-menu"]')
          : null;
        if (!btn) return;
        e.preventDefault();
        e.stopPropagation();
      } catch (_) {}
    };

    // Also block hover-trigger events that may open sidebars/menus.
    ['click', 'mousedown', 'mouseup', 'pointerdown', 'pointerup', 'touchstart', 'touchend', 'contextmenu', 'keydown', 'mouseover', 'pointerover']
      .forEach((evt) => document.addEventListener(evt, swallow, true));
  }

  function hideProfileMenuIfPresent() {
    // Best-effort: if the app injects a menu/popover for the profile, hide/remove it.
    const menu = document.getElementById('profile-menu');
    if (menu) {
      try { menu.style.display = 'none'; } catch (_) {}
      try { menu.setAttribute('aria-hidden', 'true'); } catch (_) {}
    }

    // Some libs wrap the menu in a popper/portal wrapper
    try {
      const wrappers = Array.from(document.querySelectorAll('[data-radix-popper-content-wrapper]'));
      for (const w of wrappers) {
        if (w.querySelector && w.querySelector('#profile-menu')) {
          try { w.style.display = 'none'; } catch (_) {}
        }
      }
    } catch (_) {}
  }

  function handleRoute() {
    if (!onTarget()) return;
    if (isBlockedPath(location.pathname)) {
      redirectHome();
      return;
    }

    ensureCss();
    markSensitiveHeaderArea();
    swallowClicksOnProfileButton();
    disableProfileMenuButton();
    hideProfileMenuIfPresent();
  }

  // Throttle re-application to avoid heavy loops on SPA re-renders.
  let __eeHfLastRunAt = 0;
  let __eeHfScheduled = false;
  function scheduleHandleRoute() {
    const t = now();
    if (t - __eeHfLastRunAt > 200) {
      __eeHfLastRunAt = t;
      try { handleRoute(); } catch (_) {}
      return;
    }
    if (__eeHfScheduled) return;
    __eeHfScheduled = true;
    setTimeout(() => {
      __eeHfScheduled = false;
      __eeHfLastRunAt = now();
      try { handleRoute(); } catch (_) {}
    }, 220);
  }

  // Run ASAP
  scheduleHandleRoute();

  // Observe SPA navigations
  (function patchHistory() {
    try {
      const pushState = history.pushState;
      const replaceState = history.replaceState;
      history.pushState = function () {
        const r = pushState.apply(this, arguments);
        setTimeout(scheduleHandleRoute, 0);
        return r;
      };
      history.replaceState = function () {
        const r = replaceState.apply(this, arguments);
        setTimeout(scheduleHandleRoute, 0);
        return r;
      };
      window.addEventListener('popstate', scheduleHandleRoute, true);
    } catch (_) {}
  })();

  // Keep it applied if the app re-renders
  try {
    const mo = new MutationObserver(() => {
      try { scheduleHandleRoute(); } catch (_) {}
    });
    mo.observe(document.documentElement, { childList: true, subtree: true });
    setTimeout(() => { try { mo.disconnect(); } catch (_) {} }, 60000);
  } catch (_) {}
})();

