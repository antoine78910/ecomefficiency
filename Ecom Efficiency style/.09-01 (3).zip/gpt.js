// gpt.js - Auto-login for OpenAI Auth (email + password)
(() => {
  'use strict';

  // Host gating: support chatgpt.com overlay, and keep login flow on auth.openai.com
  const host = location.hostname;

  // On chatgpt.com: inject a non-clickable purple rectangle at bottom-right to prevent click-through
  if (host === 'chatgpt.com' || host.endsWith('.chatgpt.com')) {
    const CHAT_EMAIL = 'admin@ecomefficiency.com';
    const CHAT_PROFILE_NAME = 'EcomAgent';
    const CHAT_PROFILE_EMAIL = 'admin@ecomefficiency.com';
    let __accountPopupClicked = false;

    // Minimal setter for chatgpt.com branch
    function setNativeValueLocal(el, value) {
      try {
        const proto = Object.getPrototypeOf(el);
        const desc = Object.getOwnPropertyDescriptor(proto, 'value') || Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
        if (desc && typeof desc.set === 'function') desc.set.call(el, value); else el.value = value;
      } catch { el.value = value; }
    }

    function reactInputEvents(el, lastChar = ' ') {
      el.dispatchEvent(new InputEvent('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      el.dispatchEvent(new KeyboardEvent('keydown', { key: lastChar, bubbles: true }));
      el.dispatchEvent(new KeyboardEvent('keyup', { key: lastChar, bubbles: true }));
      el.dispatchEvent(new Event('blur', { bubbles: true }));
    }

    function queryEmailInput() {
      const selectors = [
        'input#email[name="email"][autocomplete="email"]',
        'input#email[name="email"]',
        'input[name="email"][type="email"]',
        'input[autocomplete="email"][name="email"]',
        'input[aria-label="Email address"][name="email"]'
      ];
      for (const s of selectors) {
        const el = document.querySelector(s);
        if (el) return el;
      }
      return null;
    }

    function isVisibleLocal(el) {
      try {
        if (!el) return false;
        const cs = window.getComputedStyle(el);
        if (cs.visibility === 'hidden' || cs.display === 'none' || Number(cs.opacity) === 0) return false;
        const r = el.getBoundingClientRect();
        return r.width > 0 && r.height > 0;
      } catch (_) {
        return true;
      }
    }

    function findAccountPopupButton() {
      // We look for the specific "account choice" row containing both the profile name and email.
      const candidates = Array.from(document.querySelectorAll('div[role="button"], button[role="button"]'));
      const nameNeedle = CHAT_PROFILE_NAME.toLowerCase();
      const emailNeedle = CHAT_PROFILE_EMAIL.toLowerCase();
      for (const el of candidates) {
        const t = String(el.textContent || '').toLowerCase();
        if (!t) continue;
        if (!t.includes(nameNeedle)) continue;
        if (!t.includes(emailNeedle)) continue;
        if (!isVisibleLocal(el)) continue;
        return el;
      }
      return null;
    }

    function tryClickAccountPopupOnce() {
      if (__accountPopupClicked) return false;
      // Extra guard: avoid repeated clicking across SPA navigations
      try {
        if (sessionStorage.getItem('gpt_account_popup_clicked') === '1') {
          __accountPopupClicked = true;
          return false;
        }
      } catch (_) {}

      const btn = findAccountPopupButton();
      if (!btn) return false;
      console.log('[GPT-LOGIN] Account popup button found, clicking...');
      try { btn.scrollIntoView({ block: 'center', behavior: 'auto' }); } catch (_) {}
      try { btn.click(); } catch (_) {}
      __accountPopupClicked = true;
      try { sessionStorage.setItem('gpt_account_popup_clicked', '1'); } catch (_) {}
      return true;
    }

    function tryFillEmailModalOnce() {
      const emailInput = queryEmailInput();
      if (!emailInput) return false;
      emailInput.scrollIntoView({ block: 'center' });
      emailInput.focus();
      setNativeValueLocal(emailInput, CHAT_EMAIL);
      reactInputEvents(emailInput, CHAT_EMAIL.slice(-1) || ' ');
      const continueBtn = document.querySelector('button.btn[type="submit"]')
        || Array.from(document.querySelectorAll('button')).find(b => /continue/i.test(b.textContent || ''))
        || null;
      if (continueBtn) {
        continueBtn.click();
      }
      return true;
    }

    function tryFillEmailModalWithRetries() {
      let tries = 0;
      const maxTries = 60; // ~15s at 250ms
      const timer = setInterval(() => {
        tries++;
        if (tryFillEmailModalOnce()) {
          clearInterval(timer);
          return;
        }
        if (tries >= maxTries) clearInterval(timer);
      }, 250);

      // Also observe DOM mutations to catch late modal mount
      const obs = new MutationObserver(() => {
        if (tryFillEmailModalOnce()) {
          obs.disconnect();
        }
      });
      obs.observe(document.documentElement, { childList: true, subtree: true });
    }

    // Auto-click the login button if present
    function autoClickLogin() {
      // If the account-choice popup is present, select the right account first.
      if (tryClickAccountPopupOnce()) {
        // Give the UI a moment to settle before searching for login/email modal.
        setTimeout(() => { tryFillEmailModalWithRetries(); }, 250);
        return false;
      }

      const welcomeBtn = document.querySelector('button[data-testid="welcome-login-button"]');
      const loginBtn = document.querySelector('button[data-testid="login-button"]');
      const target = (welcomeBtn && welcomeBtn.offsetParent !== null) ? welcomeBtn : (loginBtn && loginBtn.offsetParent !== null ? loginBtn : null);
      if (target) {
        console.log('[GPT-LOGIN] Login button found, clicking...', target.dataset.testid || target.getAttribute('data-testid'));
        target.click();
        // After clicking, attempt to fill the modal email if it appears
        setTimeout(() => { tryFillEmailModalWithRetries(); }, 200);
        return true;
      }
      // If no button yet, still try to fill modal if it's already open
      tryFillEmailModalWithRetries();
      return false;
    }

    // Try immediately and on DOM changes
    if (!autoClickLogin()) {
      const observer = new MutationObserver(() => {
        if (autoClickLogin()) {
          observer.disconnect();
        }
      });
      observer.observe(document.documentElement, { childList: true, subtree: true });
    }

    // Also watch specifically for the account popup (it can appear after navigation)
    // This stays lightweight and stops once clicked.
    const accountObserver = new MutationObserver(() => {
      if (tryClickAccountPopupOnce()) {
        accountObserver.disconnect();
      }
    });
    accountObserver.observe(document.documentElement, { childList: true, subtree: true });

    function injectBottomRightBlocker() {
      if (document.getElementById('gpt-nonclickable-rectangle')) return;
      const blocker = document.createElement('div');
      blocker.id = 'gpt-nonclickable-rectangle';
      const style = blocker.style;
      style.position = 'fixed';
      style.left = '6px';
      style.bottom = '6px';
      style.width = '256px';
      style.height = '70px';
      style.background = 'transparent';
      style.border = '1px solid transparent';
      style.borderRadius = '10px';
      style.boxShadow = '0 6px 18px rgba(0,0,0,0.25)';
      style.backdropFilter = 'saturate(120%)';
      style.userSelect = 'none';
      style.cursor = 'not-allowed';
      style.zIndex = '2147483647';
      style.pointerEvents = 'auto';
      blocker.setAttribute('aria-hidden', 'true');
      blocker.setAttribute('title', 'Zone inactive');
      blocker.setAttribute('draggable', 'false');

      const swallow = (e) => { e.preventDefault(); e.stopImmediatePropagation(); e.stopPropagation(); };
      ['pointerdown','pointerup','pointermove','click','dblclick','contextmenu','mousedown','mouseup','touchstart','touchend']
        .forEach(evt => blocker.addEventListener(evt, swallow, { capture: true }));

      document.body.appendChild(blocker);
    }

    if (document.readyState === 'loading') {
      window.addEventListener('DOMContentLoaded', injectBottomRightBlocker, { once: true });
    } else {
      injectBottomRightBlocker();
    }
    return;
  }

  // Otherwise, only proceed for auth.openai.com
  if (host !== 'auth.openai.com') return;

  const EMAIL = 'admin@ecomefficiency.com';
  const PASSWORD = 'IOjH?8pl5UI?,!#ZAi:?jl';

  const isEmailPage = () => /\/log-in-or-create-account(\b|\/|$)/.test(location.pathname);
  const isPasswordPage = () => /\/log-in\/password(\b|\/|$)/.test(location.pathname);

  function log(...args) {
    console.log('[GPT-LOGIN]', ...args);
  }

  function isVisible(el) {
    if (!el) return false;
    const cs = window.getComputedStyle(el);
    if (cs.visibility === 'hidden' || cs.display === 'none' || Number(cs.opacity) === 0) return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }

  function setNativeValue(input, value) {
    try {
      const proto = Object.getPrototypeOf(input);
      const desc = Object.getOwnPropertyDescriptor(proto, 'value') || Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
      if (desc && typeof desc.set === 'function') {
        desc.set.call(input, value);
      } else {
        input.value = value;
      }
    } catch {
      input.value = value;
    }
  }

  function fireTypingEvents(input, lastChar = ' ') {
    input.dispatchEvent(new Event('input', { bubbles: true, cancelable: true }));
    input.dispatchEvent(new Event('change', { bubbles: true, cancelable: true }));
    const k = { key: lastChar, bubbles: true, cancelable: true };
    input.dispatchEvent(new KeyboardEvent('keydown', k));
    input.dispatchEvent(new KeyboardEvent('keypress', k));
    input.dispatchEvent(new KeyboardEvent('keyup', k));
    input.dispatchEvent(new Event('blur', { bubbles: true }));
  }

  // Simulation de mouvement de souris humain
  function simulateHumanMouseMovement(element) {
    const rect = element.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    
    // Ajouter un peu de variation pour simuler un mouvement humain
    const offsetX = (Math.random() - 0.5) * 10;
    const offsetY = (Math.random() - 0.5) * 10;
    
    const finalX = centerX + offsetX;
    const finalY = centerY + offsetY;
    
    // Simuler le mouvement de la souris vers l'élément
    const mouseMoveEvent = new MouseEvent('mousemove', {
      clientX: finalX,
      clientY: finalY,
      bubbles: true,
      cancelable: true
    });
    
    document.dispatchEvent(mouseMoveEvent);
    
    return { x: finalX, y: finalY };
  }

  // Simulation de clic humain avec mouvement de souris très réaliste
  function humanClick(element) {
    return new Promise(async (resolve) => {
      // Faire défiler l'élément en vue si nécessaire
      element.scrollIntoView({ behavior: 'smooth', block: 'center' });
      
      // Attendre que le scroll se termine complètement
      await new Promise(r => setTimeout(r, 500 + Math.random() * 500));
      
      // Simuler un mouvement de souris plus réaliste avec plusieurs étapes
      const rect = element.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      
      // Mouvement de souris en plusieurs étapes (comme un humain)
      const steps = 3 + Math.floor(Math.random() * 3); // 3-5 étapes
      for (let i = 0; i < steps; i++) {
        const progress = i / (steps - 1);
        const offsetX = (Math.random() - 0.5) * 20 * (1 - progress);
        const offsetY = (Math.random() - 0.5) * 20 * (1 - progress);
        
        const x = centerX + offsetX;
        const y = centerY + offsetY;
        
        const moveEvent = new MouseEvent('mousemove', {
          clientX: x,
          clientY: y,
          bubbles: true,
          cancelable: true
        });
        
        document.dispatchEvent(moveEvent);
        
        // Délai variable entre les mouvements
        await new Promise(r => setTimeout(r, 50 + Math.random() * 100));
      }
      
      // Position finale avec un petit ajustement
      const finalX = centerX + (Math.random() - 0.5) * 5;
      const finalY = centerY + (Math.random() - 0.5) * 5;
      
      // Hover sur l'élément (comme un humain qui survole avant de cliquer)
      const hoverEvent = new MouseEvent('mouseover', {
        clientX: finalX,
        clientY: finalY,
        bubbles: true,
        cancelable: true
      });
      element.dispatchEvent(hoverEvent);
      
      // Attendre un peu comme un humain qui hésite
      await new Promise(r => setTimeout(r, 200 + Math.random() * 400));
      
      // Événements de clic avec délais plus réalistes
      const clickEvents = [
        { type: 'mouseenter', delay: 50 + Math.random() * 100 },
        { type: 'mousemove', delay: 30 + Math.random() * 70 },
        { type: 'mousedown', delay: 100 + Math.random() * 200 },
        { type: 'mouseup', delay: 50 + Math.random() * 100 },
        { type: 'click', delay: 200 + Math.random() * 300 }
      ];
      
      for (const eventData of clickEvents) {
        const event = new MouseEvent(eventData.type, {
          clientX: finalX,
          clientY: finalY,
          bubbles: true,
          cancelable: true,
          button: 0,
          buttons: eventData.type === 'mousedown' ? 1 : 0
        });
        
        element.dispatchEvent(event);
        
        // Délai variable entre les événements
        await new Promise(r => setTimeout(r, eventData.delay));
      }
      
      // Pause finale plus longue comme un humain qui attend
      await new Promise(r => setTimeout(r, 500 + Math.random() * 1000));
      
      resolve();
    });
  }

  function typeCharByChar(input, text) {
    return new Promise(async (resolve) => {
      setNativeValue(input, '');
      input.dispatchEvent(new Event('input', { bubbles: true }));
      
      // Simulation d'écriture très humaine avec variations de vitesse
      for (let i = 0; i < text.length; i++) {
        const ch = text[i];
        
        // Délai variable entre 100-300ms pour simuler une frappe humaine lente
        const delay = Math.random() * 200 + 100;
        
        // Parfois faire une pause plus longue (simulation de réflexion ou d'erreur)
        if (Math.random() < 0.15) {
          await new Promise(r => setTimeout(r, 300 + Math.random() * 500));
        }
        
        // Parfois simuler une erreur de frappe (supprimer et retaper)
        if (Math.random() < 0.05 && i > 0) {
          // Simuler une erreur de frappe
          const backspaceEvent = new KeyboardEvent('keydown', { 
            key: 'Backspace', 
            bubbles: true, 
            cancelable: true,
            keyCode: 8,
            which: 8
          });
          input.dispatchEvent(backspaceEvent);
          
          setNativeValue(input, input.value.slice(0, -1));
          input.dispatchEvent(new Event('input', { bubbles: true }));
          
          await new Promise(r => setTimeout(r, 200 + Math.random() * 300));
        }
        
        // Événements de frappe plus réalistes
        input.dispatchEvent(new KeyboardEvent('keydown', { 
          key: ch, 
          bubbles: true, 
          cancelable: true,
          keyCode: ch.charCodeAt(0),
          which: ch.charCodeAt(0)
        }));
        
        setNativeValue(input, (input.value || '') + ch);
        
        input.dispatchEvent(new Event('input', { bubbles: true }));
        
        input.dispatchEvent(new KeyboardEvent('keypress', { 
          key: ch, 
          bubbles: true, 
          cancelable: true,
          keyCode: ch.charCodeAt(0),
          which: ch.charCodeAt(0)
        }));
        
        input.dispatchEvent(new KeyboardEvent('keyup', { 
          key: ch, 
          bubbles: true, 
          cancelable: true,
          keyCode: ch.charCodeAt(0),
          which: ch.charCodeAt(0)
        }));
        
        await new Promise(r => setTimeout(r, delay));
      }
      
      // Pause finale plus longue avant les événements de fin
      await new Promise(r => setTimeout(r, 300 + Math.random() * 500));
      
      input.dispatchEvent(new Event('change', { bubbles: true }));
      input.dispatchEvent(new Event('blur', { bubbles: true }));
      resolve();
    });
  }

  function waitFor(selector, timeout = 15000, { visible = false } = {}) {
    return new Promise((resolve, reject) => {
      const pick = () => {
        const all = Array.from(document.querySelectorAll(selector));
        return visible ? all.find(isVisible) : (all[0] || null);
      };
      const immediate = pick();
      if (immediate) return resolve(immediate);

      const obs = new MutationObserver(() => {
        const el = pick();
        if (el) {
          obs.disconnect();
          resolve(el);
        }
      });
      obs.observe(document.documentElement, { childList: true, subtree: true, attributes: true });
      const t = setTimeout(() => {
        obs.disconnect();
        reject(new Error(`Timeout waiting for ${selector}`));
      }, timeout);
    });
  }

  async function handleEmailPage() {
    try {
      log('Email page detected');
      const emailSelectors = [
        'input[type="email"][name="email"]',
        'input[type="email"][autocomplete="email"]',
        'input[type="email"]',
        'input[placeholder*="adresse" i]'
      ];
      let emailInput = null;
      for (const sel of emailSelectors) {
        try { emailInput = await waitFor(sel, 20000, { visible: true }); if (emailInput) break; } catch {}
      }
      if (!emailInput) throw new Error('Email input not found');

      // Simulation d'un focus humain avec délai plus long
      await new Promise(r => setTimeout(r, 500 + Math.random() * 1000));
      emailInput.focus();
      
      // Attendre plus longtemps avant de commencer à taper (comme un humain qui lit)
      await new Promise(r => setTimeout(r, 300 + Math.random() * 700));
      
      setNativeValue(emailInput, EMAIL);
      fireTypingEvents(emailInput, EMAIL.slice(-1));
      if (!emailInput.value) {
        await typeCharByChar(emailInput, EMAIL);
      }
      
      // Pause après la saisie comme un humain qui vérifie (plus longue)
      await new Promise(r => setTimeout(r, 800 + Math.random() * 1200));
      log('Email filled');

      // Prefer the submit within the same form; exclude provider buttons (Google/Microsoft/Apple)
      let continueBtn = null;
      const form = emailInput.closest('form');
      if (form) {
        continueBtn = form.querySelector('button[name="intent"][value="email"]')
          || Array.from(form.querySelectorAll('button[type="submit"], button'))
            .find(b => !/google|microsoft|apple/i.test((b.getAttribute('value') || '') + ' ' + (b.dataset.provider || ''))
              && /\bcontinue\b|\bcontinuer\b/i.test(b.textContent || ''))
          || null;
      }
      if (!continueBtn) {
        const pageButtons = Array.from(document.querySelectorAll('button[type="submit"], button'))
          .filter(b => !/google|microsoft|apple/i.test((b.getAttribute('value') || '') + ' ' + (b.dataset.provider || '')));
        continueBtn = pageButtons.find(b => b.matches('button[name="intent"][value="email"]'))
          || pageButtons.find(b => /\bcontinue\b|\bcontinuer\b/i.test(b.textContent || ''))
          || null;
      }
      if (!continueBtn) throw new Error('Continue button not found (email page)');
      if (continueBtn.getAttribute('aria-disabled') === 'true') {
        await new Promise(r => setTimeout(r, 300));
      }
      
      // Utiliser la simulation de clic humain
      await humanClick(continueBtn);
      log('Continue clicked (email page)');
    } catch (e) {
      log('Email page error:', e.message);
    }
  }

  async function handlePasswordPage() {
    try {
      log('Password page detected');
      const pwdSelectors = [
        'input[type="password"][name="current-password"]',
        'input#current-password',
        'input[autocomplete="current-password"]',
        'input[type="password"]'
      ];
      let pwdInput = null;
      for (const sel of pwdSelectors) {
        try { pwdInput = await waitFor(sel, 20000, { visible: true }); if (pwdInput) break; } catch {}
      }
      if (!pwdInput) throw new Error('Password input not found');

      // Simulation d'un focus humain avec délai plus long
      await new Promise(r => setTimeout(r, 500 + Math.random() * 1000));
      pwdInput.focus();
      
      // Attendre plus longtemps avant de commencer à taper (comme un humain qui lit)
      await new Promise(r => setTimeout(r, 300 + Math.random() * 700));
      
      setNativeValue(pwdInput, PASSWORD);
      fireTypingEvents(pwdInput, PASSWORD.slice(-1));
      if (!pwdInput.value) {
        await typeCharByChar(pwdInput, PASSWORD);
      }
      
      // Pause après la saisie comme un humain qui vérifie (plus longue)
      await new Promise(r => setTimeout(r, 800 + Math.random() * 1200));
      log('Password filled');

      // Prefer the submit inside the password form; exclude provider buttons (Google/Microsoft/Apple)
      let continueBtn = null;
      const form = pwdInput.closest('form');
      if (form) {
        continueBtn = form.querySelector('button[name="intent"][value="password"]')
          || Array.from(form.querySelectorAll('button[type="submit"], button'))
            .find(b => !/google|microsoft|apple/i.test((b.getAttribute('value') || '') + ' ' + (b.dataset.provider || ''))
              && /\bcontinue\b|\bcontinuer\b/i.test(b.textContent || ''))
          || null;
      }
      // Fallback search on page but explicitly exclude provider buttons
      if (!continueBtn) {
        const pageButtons = Array.from(document.querySelectorAll('button[type="submit"], button'))
          .filter(b => !/google|microsoft|apple/i.test((b.getAttribute('value') || '') + ' ' + (b.dataset.provider || '')));
        continueBtn = pageButtons.find(b => b.matches('button[name="intent"][value="password"]'))
          || pageButtons.find(b => /\bcontinue\b|\bcontinuer\b/i.test(b.textContent || ''))
          || null;
      }
      if (!continueBtn) throw new Error('Continue submit not found (password page)');
      if (continueBtn.getAttribute('aria-disabled') === 'true') {
        await new Promise(r => setTimeout(r, 300));
      }
      
      // Utiliser la simulation de clic humain
      await humanClick(continueBtn);
      log('Continue clicked (password page)');
    } catch (e) {
      log('Password page error:', e.message);
    }
  }

  function route() {
    if (isEmailPage()) {
      handleEmailPage();
    } else if (isPasswordPage()) {
      handlePasswordPage();
    }
  }

  // Lightweight scheduler to avoid heavy observers that might interfere with page
  let scheduled = false;
  let tries = 0;
  function schedule() {
    if (scheduled) return;
    scheduled = true;
    setTimeout(() => {
      scheduled = false;
      tries++;
      route();
      if (tries < 20) schedule();
    }, 600);
  }

  // Re-run on URL changes (polling only)
  let last = location.href;
  setInterval(() => {
    if (location.href !== last) {
      last = location.href;
      tries = 0;
      schedule();
    }
  }, 700);

  // Initial kick
  schedule();
})();