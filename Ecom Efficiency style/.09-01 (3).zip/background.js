// background.js

chrome.runtime.onInstalled.addListener(() => {
  // S'assurer que l'API notifications est prête
  console.log("Extension installée et prête !");
});

// ============================================
// MIDJOURNEY AUTO LOGIN - RELOAD DISCORD
// ============================================
let discordReloadTimer = null;
let discordTabId = null;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  
  // Message de Midjourney: "J'ai cliqué sur Continue with Discord"
  if (message.action === 'midjourney_discord_clicked') {
    console.log('[Background] 🎯 Continue with Discord cliqué - Préparation du reload dans 10s');
    
    // Attendre 10 secondes puis chercher l'onglet Discord et le reloader
    if (discordReloadTimer) {
      clearTimeout(discordReloadTimer);
    }
    
    discordReloadTimer = setTimeout(() => {
      console.log('[Background] ⏰ 10 secondes écoulées - Recherche de l\'onglet Discord...');
      
      // Fonction pour vérifier et reloader Discord
      function checkAndReloadDiscord(attemptCount = 0) {
        chrome.tabs.query({}, (tabs) => {
          const discordTab = tabs.find(tab => tab.url && tab.url.includes('discord.com'));
          
          if (!discordTab) {
            console.log('[Background] ❌ Aucun onglet Discord trouvé');
            return;
          }
          
          console.log(`[Background] 🔍 Tentative ${attemptCount + 1} - Onglet Discord:`, discordTab.url);
          
          // Vérifier si on est sur /login OU /oauth2/authorize
          if (discordTab.url.includes('/login') || discordTab.url.includes('/oauth2/authorize')) {
            console.log('[Background] ✅ Discord est sur /login ou /oauth2/authorize - RELOAD en cours...');
            
            // Reload sans callback pour éviter les problèmes
            chrome.tabs.reload(discordTab.id);
            console.log('[Background] 🔄 Commande de reload envoyée !');
            
            // Vérifier après 2 secondes que le reload a bien eu lieu
            setTimeout(() => {
              chrome.tabs.get(discordTab.id, (tab) => {
                console.log('[Background] 📊 État après reload:', tab.url);
              });
            }, 2000);
          } else {
            // Pas encore sur une page Discord pertinente, réessayer
            if (attemptCount < 10) {
              console.log('[Background] ⏳ Discord pas encore prêt, nouvelle tentative dans 1s...');
              setTimeout(() => checkAndReloadDiscord(attemptCount + 1), 1000);
            } else {
              console.log('[Background] ⏱️ Timeout - Reload forcé...');
              chrome.tabs.reload(discordTab.id);
              console.log('[Background] 🔄 Commande de reload envoyée (forcé) !');
            }
          }
        });
      }
      
      // Démarrer la vérification
      checkAndReloadDiscord();
      
    }, 10000); // 10 secondes
    
    sendResponse({ success: true });
    return true;
  }
  if (message.action === 'showNotification') {
    // Vérifier que l'API de notifications est disponible
    if (chrome.notifications) {
      chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icon.png',  // L'icône de la notification
        title: 'OTP Code Required',
        message: 'Please go to the auto-login channel on Discord to get your OTP code.',
        priority: 2
      });
    } else {
      console.error('L\'API de notifications n\'est pas disponible');
    }
  }

  // ============================================
  // FOREPLAY COOKIE RESET
  // ============================================
  if (message.action === 'RESET_FOREPLAY_COOKIES') {
    console.log('[Background] 🍪 Resetting Foreplay cookies requested');

    (async () => {
      try {
        const cookies = [];
        const getAll = (domain) =>
          new Promise((resolve) => {
            try {
              chrome.cookies.getAll({ domain }, (items) => resolve(items || []));
            } catch (_) {
              resolve([]);
            }
          });

        // Get cookies both for apex domain and host-only subdomain cookies.
        const list1 = await getAll('foreplay.co');
        const list2 = await getAll('app.foreplay.co');
        for (const c of list1) cookies.push(c);
        for (const c of list2) cookies.push(c);

        // Dedupe by (name|domain|path|storeId)
        const seen = new Set();
        const uniq = [];
        for (const c of cookies) {
          const k = `${c.name}|${c.domain}|${c.path}|${c.storeId}`;
          if (seen.has(k)) continue;
          seen.add(k);
          uniq.push(c);
        }

        const removeOne = (cookie, protocol) =>
          new Promise((resolve) => {
            try {
              const host = String(cookie.domain || '').replace(/^\./, '');
              const path = cookie.path || '/';
              const url = `${protocol}://${host}${path}`;
              chrome.cookies.remove(
                { url, name: cookie.name, storeId: cookie.storeId },
                (details) => resolve(!!details)
              );
            } catch (_) {
              resolve(false);
            }
          });

        let removed = 0;
        for (const cookie of uniq) {
          // For secure cookies, only https can work.
          const protocols = cookie.secure ? ['https'] : ['https', 'http'];
          let ok = false;
          for (const p of protocols) {
            // eslint-disable-next-line no-await-in-loop
            ok = await removeOne(cookie, p);
            if (ok) break;
          }
          if (ok) removed++;
        }

        console.log(`[Background] 🗑️ Foreplay cookies found=${uniq.length}, removed=${removed}`);
        sendResponse({ ok: true, found: uniq.length, removed });
      } catch (e) {
        console.error('[Background] ❌ Foreplay cookie reset failed:', e);
        sendResponse({ ok: false, error: String(e && e.message ? e.message : e) });
      }
    })();

    return true; // async response
  }

  if (message && message.type === 'FETCH_SHEET_HTML' && message.url) {
    (async () => {
      try {
        const controller = new AbortController();
        const timeoutMs = Number(message.timeoutMs || 20000);
        const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

        const res = await fetch(message.url, {
          credentials: 'omit',
          cache: 'no-store',
          redirect: 'follow',
          headers: {
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,text/plain;q=0.8,*/*;q=0.7'
          },
          signal: controller.signal
        });
        clearTimeout(timeoutId);

        const text = await res.text();
        sendResponse({
          ok: res.ok,
          status: res.status,
          statusText: res.statusText,
          url: res.url,
          text
        });
      } catch (e) {
        sendResponse({ ok: false, error: String(e) });
      }
    })();
    return true; // keep the message channel open for async sendResponse
  }

  if (message && message.type === 'FETCH_OPENAI_OTP') {
    console.log('[EE-BG] FETCH_OPENAI_OTP request received');
    
    // Utiliser une fonction async immédiate pour éviter les problèmes de message channel
    (async () => {
      try {
        const tryUrls = [
          // Primary (current prod)
          'http://51.83.103.21:20016/otp'
        ];
        let lastErr = null;
        
        // Essayer plusieurs fois avec des délais différents
        for (let attempt = 0; attempt < 3; attempt++) {
          console.log('[EE-BG] Attempt', attempt + 1, 'of 3');
          
          for (let i = 0; i < tryUrls.length; i++) {
            const baseUrl = tryUrls[i];
            // Cache-bust (some proxies can cache aggressively even with no-store)
            const url = baseUrl + '?t=' + Date.now();
            console.log('[EE-BG] Trying URL:', url);
            try {
              const controller = new AbortController();
              const timeoutId = setTimeout(() => controller.abort(), 10000); // 10s timeout
              
              const res = await fetch(url, { 
                cache: 'no-store',
                mode: 'cors',
                credentials: 'omit',
                headers: {
                  'Accept': 'application/json',
                  'Cache-Control': 'no-cache',
                  'Pragma': 'no-cache'
                },
                signal: controller.signal
              });
              
              clearTimeout(timeoutId);
              console.log('[EE-BG] Response status:', res.status);
              
              // Always read the body once; some servers return JSON with wrong content-type
              const rawText = await res.text().catch(() => '');
              let json = null;
              try { json = rawText ? JSON.parse(rawText) : null; } catch (_) {}
              if (json) console.log('[EE-BG] JSON response:', json);
              else if (rawText) console.log('[EE-BG] Text response:', rawText);
              
              if (!res.ok) {
                const errMsg =
                  (json && (json.error || json.message)) ||
                  (rawText && rawText.slice(0, 240)) ||
                  ('HTTP ' + res.status + ' (' + baseUrl + ')');
                console.log('[EE-BG] Error response:', errMsg);
                lastErr = new Error(errMsg);
                continue; // try next URL
              }
              
              // Vérifier que le code existe et n'est pas vide
              const code = (json && json.code) || '';
              if (code && code.toString().length >= 4) {
                console.log('[EE-BG] Success, sending code:', code);
                sendResponse({ ok: true, code: code, sourceUrl: baseUrl });
                return; // Important: return après sendResponse
              } else {
                console.log('[EE-BG] Code empty or invalid:', code);
                lastErr = new Error('Code empty or invalid');
                continue;
              }
            } catch (e) {
              console.log('[EE-BG] Fetch error:', e);
              lastErr = new Error(String(baseUrl) + ': ' + String(e && e.message ? e.message : e));
            }
          }
          
          // Attendre avant la prochaine tentative
          if (attempt < 2) {
            console.log('[EE-BG] Waiting before retry...');
            await new Promise(resolve => setTimeout(resolve, 1000 + attempt * 1000));
          }
        }
        
        // Si on arrive ici, toutes les tentatives ont échoué
        const errorMsg = lastErr ? lastErr.message : 'IMAP server not reachable after 3 attempts';
        console.log('[EE-BG] Final error:', errorMsg);
        sendResponse({ ok: false, error: errorMsg });
        
      } catch (e) {
        console.log('[EE-BG] Unexpected error:', e);
        sendResponse({ ok: false, error: String(e && e.message ? e.message : e) });
      }
    })();
    return true; 
  }

  // NOUVEAU HANDLER POUR VMAKE
  if (message && message.type === 'FETCH_VMAKE_OTP') {
    console.log('[EE-BG] FETCH_VMAKE_OTP request received');
    
    (async () => {
      try {
        const accountParam = message.account || '3';
        // Primary server (current): 51.83.103.21
        // Fallback server (older): 46.224.61.179
        const baseUrls = [
          `http://51.83.103.21:20016/otp-vmake${accountParam}`,
          `http://46.224.61.179:20016/otp-vmake${accountParam}`
        ];
        let lastErr = null;
        
        // Essayer 3 fois
        for (let attempt = 0; attempt < 3; attempt++) {
          console.log('[EE-BG-VMAKE] Attempt', attempt + 1, 'of 3', 'account=', accountParam);
          
          try {
              const controller = new AbortController();
              const timeoutId = setTimeout(() => controller.abort(), 10000); // 10s timeout
              
              // Try each URL (primary then fallback) on each attempt
              for (let i = 0; i < baseUrls.length; i++) {
                const baseUrl = baseUrls[i];
                const url = baseUrl + '?t=' + Date.now(); // cache-bust
                console.log('[EE-BG-VMAKE] Trying URL:', url);

                try {
                  const res = await fetch(url, {
                    cache: 'no-store',
                    mode: 'cors',
                    credentials: 'omit',
                    headers: {
                      'Accept': 'application/json,text/plain,*/*',
                      'Cache-Control': 'no-cache',
                      'Pragma': 'no-cache'
                    },
                    signal: controller.signal
                  });

                  console.log('[EE-BG-VMAKE] Response status:', res.status, 'for', baseUrl);

                  const text = await res.text().catch(() => '');
                  if (text) console.log('[EE-BG-VMAKE] Raw response:', text);

                  let json = null;
                  try { json = text ? JSON.parse(text) : null; } catch (_) {}

                  if (!res.ok) {
                    const msg =
                      (json && (json.error || json.message)) ||
                      (text && text.slice(0, 240)) ||
                      `HTTP ${res.status}`;
                    lastErr = new Error(msg);
                    continue;
                  }

                  // Server can return JSON {"code":"3723"} (known)
                  // but also tolerate plain text by extracting digits.
                  let code = (json && json.code) ? String(json.code).trim() : '';
                  if (!code && text) {
                    const m = String(text).match(/\b\d{4,8}\b/);
                    if (m) code = String(m[0]).trim();
                  }

                  if (code && code.length >= 4) {
                    clearTimeout(timeoutId);
                    console.log('[EE-BG-VMAKE] Success, sending code:', code, 'from', baseUrl);
                    sendResponse({ ok: true, code: code, sourceUrl: baseUrl });
                    return;
                  }

                  lastErr = new Error('Code empty or invalid');
                } catch (e) {
                  lastErr = e;
                  console.log('[EE-BG-VMAKE] Fetch error for', baseUrl, e);
                }
              }

              clearTimeout(timeoutId);

          } catch (e) {
            console.log('[EE-BG-VMAKE] Fetch error:', e);
            lastErr = e;
          }
          
          // Attendre avant retry
          if (attempt < 2) await new Promise(r => setTimeout(r, 2000));
        }
        
        sendResponse({ ok: false, error: lastErr ? lastErr.message : 'Failed after 3 attempts' });

      } catch (e) {
        console.log('[EE-BG-VMAKE] Unexpected error:', e);
        sendResponse({ ok: false, error: String(e) });
      }
    })();
    
    return true; // Async response
  }


  // ============================================
  // FOREPLAY INITIAL RESET (One-time per session)
  // ============================================
  if (message.action === 'CHECK_AND_RESET_FOREPLAY_INIT') {
      // IMPORTANT:
      // On ne fait plus de "reset préventif" Foreplay, car ça provoque un logout même quand la session est OK
      // (ex: arrivée sur dashboard). Le logout auto doit dépendre uniquement de la modale "Free trial expired"
      // (géré par foreplay_auto_logout.js).
      sendResponse({ resetPerformed: false, disabled: true });
      return true;
  }

});

// Cache pour suivre les resets Foreplay (variable globale simple)
const foreplayResetCache = {};

/************************************'chrome://extensions/'  //
 ************************************/
function blockChromeURLs() {
  const blockedChromeUrls = [
    'chrome://settings',
    'chrome://password-manager',
    'chrome://history',
    'chrome://downloads/',
    'chrome://extensions/',
    'https://app.trendtrack.io/en/workspace/w-1-z0L28yN/settings*',
    'https://app.trendtrack.io/en/workspace/w-1-YiSH7pB/settings*',
    'https://myaccount.google.com/*',
    'https://app.winninghunter.com/profile',
    'https://www.kalodata.com/me*',
    'https://checkout.stripe.com/c/pay/*'
    // Vous pouvez ajouter d'autres URLs chrome:// ici
  ];

  chrome.webNavigation.onBeforeNavigate.addListener(
    function(details) {
      const url = details.url;
      
      // Vérifier les URLs bloquées avec patterns
      const isBlocked = blockedChromeUrls.some(blocked => {
        if (blocked.includes('*')) {
          // Remplacer * par .* pour regex
          const pattern = blocked.replace(/\*/g, '.*');
          const regex = new RegExp('^' + pattern);
          return regex.test(url);
        }
        return url.startsWith(blocked);
      });
      
      if (isBlocked) {
        console.log("Accès bloqué à : ", url);
        
        // Redirection vers la page de blocage
        chrome.tabs.update(details.tabId, {
          url: chrome.runtime.getURL('blocked.html')
        });
      }
    },
    {
      // Filtrer toutes les URLs (pas seulement chrome://)
      url: [
        { schemes: ['chrome', 'https', 'http'] }
      ]
    }
  );
}

/************************************
 * 2) BLOCAGE DES URLS AFTERLIB
 ************************************/
// Liste des URLs à bloquer (Afterlib)
const blockedAfterlibUrls = [
  "https://app.foreplay.co/dashboard?settings=account",
  'https://app.trendtrack.io/en/workspace/w-1-z0L28yN/settings*',
  'https://app.trendtrack.io/en/workspace/w-1-YiSH7pB/settings*',
  'https://app.winninghunter.com/profile',
  'https://billing.stripe.com/',
  'https://one.google.com/*',
  'https://www.kalodata.com/me*',
  // Ajoutez d'autres URLs ici si nécessaire
];


/************************************
 * 3) INITIALISATION
 ************************************/
// Appel des deux fonctions de blocage
blockChromeURLs();

/************************************
 * 4) BLOCAGE DES URLS HTTPS (myaccount.google.com)
 ************************************/
chrome.webNavigation.onBeforeNavigate.addListener(
  function(details) {
    const url = details.url;
    if (url.startsWith('https://myaccount.google.com/')) {
      console.log("Accès bloqué à : ", url);
      chrome.tabs.update(details.tabId, {
        url: chrome.runtime.getURL('blocked.html')
      });
    }
  },
  {
    url: [
      { urlPrefix: 'https://myaccount.google.com/' }
    ]
  }
);

/************************************
 * 5) BLOCAGE SPÉCIFIQUE KALODATA /me
 ************************************/
chrome.webNavigation.onBeforeNavigate.addListener(
  function(details) {
    const url = details.url;
    if (url.startsWith('https://www.kalodata.com/me')) {
      console.log("Accès bloqué à Kalodata /me : ", url);
      chrome.tabs.update(details.tabId, {
        url: chrome.runtime.getURL('blocked.html')
      });
    }
  },
  {
    url: [
      { urlPrefix: 'https://www.kalodata.com/me' }
    ]
  }
);

/************************************
 * 6) BLOCAGE KALODATA AVEC REGEX
 ************************************/
chrome.webNavigation.onBeforeNavigate.addListener(
  function(details) {
    const url = details.url;
    if (/https:\/\/www\.kalodata\.com\/me/.test(url)) {
      console.log("Accès bloqué à Kalodata /me (regex) : ", url);
      chrome.tabs.update(details.tabId, {
        url: chrome.runtime.getURL('blocked.html')
      });
    }
  },
  {
    url: [
      { urlMatches: "https://www.kalodata.com/me*" }
    ]
  }
);

/************************************
 * 7) SURVEILLANCE DES ONGLETS KALODATA
 ************************************/
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && tab.url.includes('kalodata.com/me')) {
    console.log("Onglet Kalodata /me détecté, blocage:", tab.url);
    chrome.tabs.update(tabId, {
      url: chrome.runtime.getURL('blocked.html')
    });
  }
});


// background.js



// background.js

chrome.webRequest.onBeforeRequest.addListener(
  function (details) {
    const url = details.url || '';
    
    // Redirige immédiatement la page de paramètres Trendtrack vers /en/home
    if (details.type === 'main_frame' && /https:\/\/app\.trendtrack\.io\/en\/workspace\/[^/]+\/settings.*/.test(url)) {
      return { redirectUrl: 'https://app.trendtrack.io/en/home' };
    }

    // Bloquer/rediriger Stripe Checkout pay page
    if (details.type === 'main_frame' && /^https:\/\/checkout\.stripe\.com\/c\/pay\/.*/.test(url)) {
      return { redirectUrl: chrome.runtime.getURL('blocked.html') };
    }
    
    // Blocage spécifique pour Kalodata /me
    if (details.type === 'main_frame' && /https:\/\/www\.kalodata\.com\/me.*/.test(url)) {
      console.log("Blocage Kalodata /me:", url);
      return { cancel: true };
    }
    
    // Annule la requête pour bloquer l'accès aux autres URLs ciblées
    return { cancel: true };
  },
  {
    // Liste des patterns d'URLs à bloquer
    urls: [
      "https://app.foreplay.co/dashboard?settings=account",
      "https://app.trendtrack.io/en/workspace/w-1-z0L28yN/settings*",
      "https://app.trendtrack.io/en/workspace/w-1-YiSH7pB/settings*",
      "https://app.winninghunter.com/profile",
      "https://billing.stripe.com/",
      "https://checkout.stripe.com/c/pay/*",
      "https://one.google.com/*",
      "https://www.kalodata.com/me*"
    ]
  },
  ["blocking"]
);



// background.js

// Injection de gpt.js désormais gérée par manifest content_scripts (évite double injection)


// Gestionnaire pour l'injection du script de login Foreplay
function handleForeplayLogin(tabId, changeInfo, tab) {
  // On injecte sur tout le domaine app.foreplay.co pour gérer aussi le popup de paiement échoué
  if (changeInfo.status === 'complete' && tab.url && tab.url.startsWith('https://app.foreplay.co/')) {
    console.log('[Background] Injection du script Foreplay (Login + Monitoring)');
    
    // Injection du script de login
    chrome.scripting.executeScript({
      target: { tabId: tabId },
      files: ['foreplay_login.js']
    }).catch(err => {
      console.error('Erreur lors de l\'injection du script:', err);
    });
  }
}

// Écouter les mises à jour d'onglet pour détecter les chargements de page
chrome.tabs.onUpdated.addListener(handleForeplayLogin);

// Vérifier aussi les onglets déjà ouverts
chrome.tabs.query({url: 'https://app.foreplay.co/*'}, (tabs) => {
  tabs.forEach(tab => {
    handleForeplayLogin(tab.id, {status: 'complete'}, tab);
  });
});
