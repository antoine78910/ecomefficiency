(function () {
  'use strict';

  // Single instance guard
  if (window.__EE_HIGGSFIELD_EMAIL_SIGNIN_ACTIVE) return;
  window.__EE_HIGGSFIELD_EMAIL_SIGNIN_ACTIVE = true;

  const EMAIL = 'admin@ecomefficiency.com';
  const PASSWORD = 'JHvtviciyz?75jhbe3!';

  function onHost() {
    try { return location.hostname.endsWith('higgsfield.ai'); } catch (_) { return false; }
  }

  function isExtensionDisabled() {
    try {
      return sessionStorage.getItem('HF_EXTENSION_DISABLED') === '1';
    } catch (_) {
      return false;
    }
  }

  function path() {
    try { return String(location.pathname || ''); } catch (_) { return ''; }
  }

  function normPath() {
    // Remove trailing slashes for robustness
    const p = path();
    return p.replace(/\/+$/, '') || '/';
  }

  function isVisible(el) {
    try {
      if (!el) return false;
      const cs = window.getComputedStyle(el);
      if (cs.visibility === 'hidden' || cs.display === 'none' || Number(cs.opacity) === 0) return false;
      const r = el.getBoundingClientRect();
      return r.width > 0 && r.height > 0;
    } catch (_) {
      return true;
    }
  }

  function setNativeValue(input, value) {
    try {
      const proto = Object.getPrototypeOf(input);
      const desc =
        Object.getOwnPropertyDescriptor(proto, 'value') ||
        Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
      if (desc && typeof desc.set === 'function') desc.set.call(input, value);
      else input.value = value;
    } catch (_) {
      try { input.value = value; } catch (_) {}
    }
  }

  function fillInputStable(input, value) {
    if (!input) return;
    try { input.focus && input.focus(); } catch (_) {}
    setNativeValue(input, value);
    try { input.dispatchEvent(new Event('input', { bubbles: true })); } catch (_) {}
  }

  function waitFor(fn, timeoutMs = 20000) {
    return new Promise((resolve, reject) => {
      const start = Date.now();
      const tick = () => {
        try {
          const v = fn();
          if (v) return resolve(v);
        } catch (_) {}
        if (Date.now() - start > timeoutMs) return reject(new Error('Timeout'));
        setTimeout(tick, 120);
      };
      tick();
    });
  }

  function autoDisableExtension() {
    try {
      sessionStorage.setItem('HF_EXTENSION_DISABLED', '1');
      const otpOverlay = document.getElementById('hf-otp-overlay');
      if (otpOverlay) otpOverlay.style.display = 'none';
    } catch (_) {}
  }

  async function handleAuthSignIn() {
    // https://higgsfield.ai/auth/sign-in?source=header
    if (isExtensionDisabled()) return;
    if (!onHost()) return;
    if (normPath() !== '/auth/sign-in') return;

    // Click only once per tab session
    try {
      if (sessionStorage.getItem('HF_EMAIL_SIGNIN_CLICKED') === '1') return;
    } catch (_) {}

    const link = Array.from(document.querySelectorAll('a[href="/auth/email/sign-in"]'))
      .find((a) => isVisible(a) && /continue\s+with\s+email/i.test(a.textContent || '')) || null;
    if (!link) return;

    try { sessionStorage.setItem('HF_EMAIL_SIGNIN_CLICKED', '1'); } catch (_) {}
    try { link.click(); } catch (_) {}
  }

  async function handleAuthEmailSignIn() {
    // https://higgsfield.ai/auth/email/sign-in
    if (isExtensionDisabled()) return;
    if (!onHost()) return;
    if (normPath() !== '/auth/email/sign-in') return;

    // Fill only once per load
    try {
      if (sessionStorage.getItem('HF_EMAILPASS_FILLED') === '1') return;
    } catch (_) {}

    // Wait a bit for Clerk to mount
    await new Promise((r) => setTimeout(r, 800));

    const emailInput = await waitFor(() => {
      const el =
        document.querySelector('input[type="email"][name="email"][placeholder="Email"]') ||
        document.querySelector('input[type="email"][name="email"]');
      return (el && isVisible(el)) ? el : null;
    }, 25000);

    const pwdInput = await waitFor(() => {
      const el =
        document.querySelector('input[type="password"][name="password"][placeholder="Password"]') ||
        document.querySelector('input[type="password"][name="password"]');
      return (el && isVisible(el)) ? el : null;
    }, 25000);

    // Fill inputs
    fillInputStable(emailInput, EMAIL);
    await new Promise((r) => setTimeout(r, 250));
    fillInputStable(pwdInput, PASSWORD);

    try { sessionStorage.setItem('HF_EMAILPASS_FILLED', '1'); } catch (_) {}

    // Disable extension 10 seconds after filling
    setTimeout(() => {
      autoDisableExtension();
    }, 10000);
  }

  async function handleAuthLogin() {
    // https://higgsfield.ai/auth/login
    if (isExtensionDisabled()) return;
    if (!onHost()) return;
    if (normPath() !== '/auth/login') return;

    // Fill only once per load
    try {
      if (sessionStorage.getItem('HF_EMAILPASS_FILLED_LOGIN') === '1') return;
    } catch (_) {}

    // Wait a bit for Clerk to mount
    await new Promise((r) => setTimeout(r, 800));

    // Check if there are email/password inputs directly on this page
    const emailInput = await waitFor(() => {
      const el = document.querySelector('input[type="email"][name="email"]') ||
                  document.querySelector('input[type="email"]');
      return (el && isVisible(el)) ? el : null;
    }, 25000).catch(() => null);

    const passwordInput = await waitFor(() => {
      const el = document.querySelector('input[type="password"][name="password"]') ||
                  document.querySelector('input[type="password"]');
      return (el && isVisible(el)) ? el : null;
    }, 25000).catch(() => null);

    if (emailInput && passwordInput) {
      // This page has the login form directly - fill inputs
      fillInputStable(emailInput, EMAIL);
      await new Promise((r) => setTimeout(r, 250));
      fillInputStable(passwordInput, PASSWORD);

      try { sessionStorage.setItem('HF_EMAILPASS_FILLED_LOGIN', '1'); } catch (_) {}

      // Disable extension 10 seconds after filling
      setTimeout(() => {
        autoDisableExtension();
      }, 10000);
    } else {
      // Try to find and click "Continue with Email" link if it exists
      const link = Array.from(document.querySelectorAll('a[href="/auth/email/sign-in"], a[href*="email/sign-in"]'))
        .find((a) => isVisible(a) && /continue\s+with\s+email|email/i.test(a.textContent || '')) || null;
      
      if (link) {
        try { sessionStorage.setItem('HF_EMAIL_SIGNIN_CLICKED', '1'); } catch (_) {}
        try { link.click(); } catch (_) {}
      }
    }
  }

  async function run() {
    // Clear legacy flags that used to cause reload loops
    try {
      sessionStorage.removeItem('HIGGSFIELD_RELOAD_NEEDED');
      sessionStorage.removeItem('HIGGSFIELD_RELOAD_DONE');
      sessionStorage.removeItem('HIGGSFIELD_RELOAD_DEADLINE_MS');
    } catch (_) {}

    // Run all handlers (only one will match the current path)
    try { await handleAuthSignIn(); } catch (_) {}
    try { await handleAuthEmailSignIn(); } catch (_) {}
    try { await handleAuthLogin(); } catch (_) {}
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run, { once: true });
  } else {
    run();
  }

  // SPA support: client-side navigation won't reinject content scripts.
  // We watch for path changes and re-run the handlers (guarded by sessionStorage flags).
  let __lastPath = '';
  const __pathTimer = setInterval(() => {
    try {
      if (isExtensionDisabled()) return; // Don't run if extension is disabled
      if (!onHost()) return;
      const p = normPath();
      if (p === __lastPath) return;
      __lastPath = p;
      run();
    } catch (_) {}
  }, 500);
})();

