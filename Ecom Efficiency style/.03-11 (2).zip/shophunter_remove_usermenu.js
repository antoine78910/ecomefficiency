(function() {
  'use strict';

  function removeUserMenu() {
    try {
      var btn = document.getElementById('usermenu-button');
      if (btn) {
        btn.remove();
        try { console.log('[shophunter] Removed #usermenu-button'); } catch (_) {}
      }
    } catch (_) {}
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', removeUserMenu);
  } else {
    removeUserMenu();
  }

  var observer = new MutationObserver(function() {
    removeUserMenu();
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });
})();


