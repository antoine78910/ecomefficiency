// =======================
// Higgsfield Credits Notification
// =======================
// Détecte les crédits faibles (<50) via le cercle SVG de progression dans le profil
// Affiche un popup style Pipiads indiquant quand les crédits seront réinitialisés (dimanche à 12h)

(function() {
    'use strict';

    console.log('[Higgsfield Credits] Script started');

    // Fonction pour calculer le prochain dimanche à 12h
    function getNextSundayNoon() {
        const now = new Date();
        const currentDay = now.getDay(); // 0 = Sunday, 1 = Monday, etc.
        const currentHour = now.getHours();
        const currentMinutes = now.getMinutes();

        // Créer une date pour le prochain dimanche à 12h00
        const nextSunday = new Date(now);
        
        // Si c'est dimanche et avant 12h, c'est aujourd'hui à 12h
        if (currentDay === 0 && (currentHour < 12 || (currentHour === 12 && currentMinutes === 0))) {
            nextSunday.setHours(12, 0, 0, 0);
            return nextSunday;
        }
        
        // Sinon, calculer le nombre de jours jusqu'au prochain dimanche
        const daysUntilSunday = (7 - currentDay) % 7 || 7; // Si déjà dimanche après 12h, prendre le suivant
        if (currentDay === 0 && currentHour >= 12) {
            nextSunday.setDate(now.getDate() + 7); // Semaine prochaine
        } else {
            nextSunday.setDate(now.getDate() + daysUntilSunday);
        }
        
        nextSunday.setHours(12, 0, 0, 0);
        return nextSunday;
    }

    // Fonction pour calculer le temps restant avant le prochain refill
    function getTimeUntilNextRefill() {
        const nextSunday = getNextSundayNoon();
        const now = new Date();
        const timeUntilRefill = nextSunday - now;
        
        const days = Math.floor(timeUntilRefill / (1000 * 60 * 60 * 24));
        const hours = Math.floor((timeUntilRefill % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((timeUntilRefill % (1000 * 60 * 60)) / (1000 * 60));
        
        return { days, hours, minutes };
    }

    // Fonction pour détecter les crédits restants via le SVG
    function getCreditsFromSVG() {
        // Chercher le cercle avec stroke-dasharray et stroke-dashoffset
        const progressCircle = document.querySelector('svg circle[stroke-dasharray][stroke-dashoffset]');
        
        if (!progressCircle) {
            console.log('[Higgsfield Credits] Progress circle not found');
            return null;
        }

        const dashArray = parseFloat(progressCircle.getAttribute('stroke-dasharray'));
        const dashOffset = parseFloat(progressCircle.getAttribute('stroke-dashoffset'));

        if (!isFinite(dashArray) || !isFinite(dashOffset) || dashArray <= 0) {
            console.log('[Higgsfield Credits] Invalid dash values:', { dashArray, dashOffset });
            return null;
        }

        // Le pourcentage restant = (dashOffset / dashArray) * 100
        const percentageRemaining = (dashOffset / dashArray) * 100;
        console.log('[Higgsfield Credits] SVG values:', { dashArray, dashOffset, percentageRemaining: percentageRemaining.toFixed(2) + '%' });

        // Essayer de trouver le nombre total de crédits dans le DOM autour du SVG
        let totalCredits = 100; // Valeur par défaut
        const svgParent = progressCircle.closest('svg')?.parentElement;
        if (svgParent) {
            // Chercher des nombres autour du SVG (dans le parent ou les parents proches)
            const textContent = svgParent.textContent || '';
            const matches = textContent.match(/\d+/g);
            if (matches && matches.length > 0) {
                // Prendre le plus grand nombre trouvé comme total possible
                const numbers = matches.map(m => parseInt(m, 10)).filter(n => n > 0 && n <= 10000);
                if (numbers.length > 0) {
                    const maxNumber = Math.max(...numbers);
                    // Si on trouve un nombre raisonnable (entre 50 et 10000), l'utiliser
                    if (maxNumber >= 50 && maxNumber <= 10000) {
                        totalCredits = maxNumber;
                    }
                }
            }
        }

        // Calculer les crédits restants approximatifs
        const remainingCredits = Math.round((percentageRemaining / 100) * totalCredits);
        console.log('[Higgsfield Credits] Estimated credits:', { totalCredits, remainingCredits });

        return { remainingCredits, percentageRemaining, totalCredits };
    }

    // Fonction pour créer la notification personnalisée
    function createCustomNotification() {
        // Vérifier si la notification existe déjà
        if (document.getElementById('higgsfield-custom-credits-notif')) {
            console.log('[Higgsfield Credits] Custom notification already exists');
            return;
        }

        // Vérifier si l'utilisateur a déjà fermé la notification pour cette session
        const dismissedForSession = sessionStorage.getItem('higgsfield_credits_notif_dismissed');
        if (dismissedForSession === '1') {
            console.log('[Higgsfield Credits] Notification already dismissed for this session');
            return;
        }

        const timeUntilRefill = getTimeUntilNextRefill();
        console.log('[Higgsfield Credits] Time until next refill:', timeUntilRefill);
        
        // Formater le timer
        let timerText = '';
        if (timeUntilRefill.days > 0) {
            timerText = `${timeUntilRefill.days} day${timeUntilRefill.days > 1 ? 's' : ''}`;
        } else if (timeUntilRefill.hours > 0) {
            timerText = `${timeUntilRefill.hours} hour${timeUntilRefill.hours > 1 ? 's' : ''}`;
        } else {
            timerText = `${timeUntilRefill.minutes} minute${timeUntilRefill.minutes > 1 ? 's' : ''}`;
        }

        // Créer la notification
        const notifDiv = document.createElement('div');
        notifDiv.id = 'higgsfield-custom-credits-notif';
        notifDiv.style.cssText = `
            position: fixed;
            top: 140px;
            right: 20px;
            width: 360px;
            background: #1a1a2e;
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(138, 43, 226, 0.4);
            z-index: 999999;
            color: white;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            animation: slideIn 0.3s ease-out;
        `;

        notifDiv.innerHTML = `
            <style>
                @keyframes slideIn {
                    from {
                        transform: translateX(100px);
                        opacity: 0;
                    }
                    to {
                        transform: translateX(0);
                        opacity: 1;
                    }
                }

                /* Place a bit higher on smaller screens so it stays visible */
                @media (max-width: 1200px) {
                    #higgsfield-custom-credits-notif {
                        top: 100px !important;
                        right: 12px !important;
                        width: 320px !important;
                    }
                }
                
                #higgsfield-custom-credits-notif .close-btn {
                    position: absolute;
                    top: 12px;
                    right: 12px;
                    background: transparent;
                    border: 1px solid rgba(138, 43, 226, 0.3);
                    color: rgba(138, 43, 226, 0.8);
                    width: 28px;
                    height: 28px;
                    border-radius: 6px;
                    cursor: pointer;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    transition: all 0.2s ease;
                    font-size: 18px;
                    font-weight: 600;
                }
                
                #higgsfield-custom-credits-notif .close-btn:hover {
                    background: rgba(138, 43, 226, 0.15);
                    border-color: rgba(138, 43, 226, 0.6);
                    color: rgba(138, 43, 226, 1);
                }
                
                #higgsfield-custom-credits-notif .timer {
                    font-size: 42px;
                    font-weight: 700;
                    margin: 15px 0;
                    color: #a78bfa;
                }
                
                #higgsfield-custom-credits-notif .label {
                    font-size: 13px;
                    opacity: 0.7;
                    margin-bottom: 8px;
                    letter-spacing: 0.3px;
                    text-transform: uppercase;
                    font-size: 11px;
                }
            </style>
            
            <button class="close-btn" id="close-higgsfield-credits-notif" title="Close">×</button>
            
            <div style="font-size: 24px; font-weight: 700; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; justify-content: center;">
                <span style="font-size: 28px;">⚠️</span>
                <span>No More Credits</span>
            </div>
            
            <div class="label">Credits will be added in</div>
            <div class="timer">${timerText}</div>
        `;

        document.body.appendChild(notifDiv);
        console.log('[Higgsfield Credits] Custom notification created');

        // Ajouter les event listeners
        const closeBtn = document.getElementById('close-higgsfield-credits-notif');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                // Marquer comme dismissed pour cette session uniquement
                sessionStorage.setItem('higgsfield_credits_notif_dismissed', '1');
                console.log('[Higgsfield Credits] Notification dismissed for this session');
                
                notifDiv.style.animation = 'slideIn 0.3s ease-in reverse';
                setTimeout(() => {
                    notifDiv.remove();
                    console.log('[Higgsfield Credits] Notification closed');
                }, 300);
            });
        }
    }

    // Fonction pour supprimer la notification si elle est affichée
    function removeCustomNotification() {
        const notif = document.getElementById('higgsfield-custom-credits-notif');
        if (notif) {
            try { notif.remove(); } catch (_) {}
            console.log('[Higgsfield Credits] Existing notification removed (sufficient credits)');
        }
    }

    // Fonction pour vérifier les crédits
    function checkCredits() {
        const creditsInfo = getCreditsFromSVG();
        
        if (!creditsInfo) {
            console.log('[Higgsfield Credits] Could not detect credits from SVG');
            return false;
        }

        const { remainingCredits } = creditsInfo;
        console.log('[Higgsfield Credits] Current credits:', remainingCredits);

        if (remainingCredits < 50) {
            console.log('[Higgsfield Credits] Low credits detected (<50)!');
            createCustomNotification();
            return true;
        } else {
            console.log('[Higgsfield Credits] Credits are sufficient (>=50), ensuring no popup');
            removeCustomNotification();
        }
        
        return false;
    }

    // Observer les changements du DOM pour détecter l'apparition du SVG
    const observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
            if (mutation.addedNodes.length > 0 || mutation.attributeName === 'stroke-dashoffset' || mutation.attributeName === 'stroke-dasharray') {
                // Attendre un peu que le DOM soit stable
                setTimeout(() => {
                    checkCredits();
                }, 500);
                break;
            }
        }
    });

    // Démarrer l'observation
    function startObserving() {
        if (document.body) {
            observer.observe(document.body, {
                childList: true,
                subtree: true,
                attributes: true,
                attributeFilter: ['stroke-dashoffset', 'stroke-dasharray']
            });
            console.log('[Higgsfield Credits] Observer started');
            
            // Faire une première vérification
            setTimeout(() => {
                checkCredits();
            }, 2000);
            
            // Vérifier périodiquement (toutes les 10 secondes)
            setInterval(() => {
                checkCredits();
            }, 10000);
        } else {
            setTimeout(startObserving, 100);
        }
    }

    // Attendre que le DOM soit prêt
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', startObserving);
    } else {
        startObserving();
    }

    console.log('[Higgsfield Credits] Initialization complete');

})();
