// Auto-login script for https://app.tryatria.com/login
(function () {
    console.log('[ATRIA AUTO LOGIN] Script chargé');

    // --- FAST EXIT WHEN ALREADY CONNECTED ---
    // If the current URL starts with the workspace prefix, the user is already logged in.
    // In that situation, ensure any overlay created by a previous attempt is removed and stop the script.
    if (window.location.href.startsWith('https://app.tryatria.com/workspace')) {
        console.log('[ATRIA AUTO LOGIN] Déjà connecté - suppression des overlays');
        const stuckOverlay = document.getElementById('login-overlay');
        if (stuckOverlay) stuckOverlay.remove();
        const stuckOverlay2 = document.getElementById('__atria_overlay');
        if (stuckOverlay2) stuckOverlay2.remove();
        return; // nothing else to do
    }

    // === Loading Bar (dynamic with percentage & check-mark) ===
// Affiche la loading bar style ElevenLabs
    function showLoadingBar() {
    if (document.getElementById('login-overlay')) return;

    // Overlay
    const overlay = document.createElement('div');
    overlay.id = 'login-overlay';
    Object.assign(overlay.style, {
        position: 'fixed',
        top: '0',
        left: '0',
        width: '100%',
        height: '100%',
        backgroundColor: 'rgba(0,0,0,1)',
        zIndex: '2147483647',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center'
    });

    // Progress container
    const progressContainer = document.createElement('div');
    Object.assign(progressContainer.style, {
        width: '80%',
        maxWidth: '600px',
        backgroundColor: '#e5e7eb',
        borderRadius: '10px',
        height: '30px',
        overflow: 'hidden',
        position: 'relative'
    });

    // Progress bar
    const progressBar = document.createElement('div');
    progressBar.id = 'progress-bar';
    Object.assign(progressBar.style, {
        width: '0%',
        height: '100%',
        backgroundColor: '#3b82f6',
        transition: 'width 1s ease-in-out',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        color: '#fff',
        fontWeight: 'bold'
    });

    // Percentage label
    const percentageLabel = document.createElement('span');
    percentageLabel.id = 'percentage-label';
    percentageLabel.textContent = '0%';
    progressBar.appendChild(percentageLabel);

    // Checkmark (hidden)
    const checkmarkContainer = document.createElement('div');
    checkmarkContainer.id = 'checkmark-container';
    Object.assign(checkmarkContainer.style, {
        display: 'none',
        marginTop: '20px',
        opacity: '0',
        transition: 'opacity 0.6s ease-in-out'
    });
    const checkmarkSVG = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    checkmarkSVG.setAttribute('width', '60');
    checkmarkSVG.setAttribute('height', '60');
    checkmarkSVG.setAttribute('viewBox', '0 0 24 24');
    const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    path.setAttribute('d', 'M20 6L9 17l-5-5');
    path.setAttribute('fill', 'none');
    path.setAttribute('stroke', '#10B981');
    path.setAttribute('stroke-width', '3');
    path.setAttribute('stroke-linecap', 'round');
    path.setAttribute('stroke-linejoin', 'round');
    path.style.strokeDasharray = '48';
    path.style.strokeDashoffset = '48';
    path.style.transition = 'stroke-dashoffset 2s ease-in-out';
    checkmarkSVG.appendChild(path);
    checkmarkContainer.appendChild(checkmarkSVG);

    // Bottom text
    const textBelow = document.createElement('div');
    textBelow.innerText = 'Ecom Efficiency';
    Object.assign(textBelow.style, {
        marginTop: '20px',
        color: '#fff',
        fontSize: '24px',
        fontWeight: 'bold'
    });

    // Append
    progressContainer.appendChild(progressBar);
    overlay.appendChild(progressContainer);
    overlay.appendChild(textBelow);
    overlay.appendChild(checkmarkContainer);
    document.body.appendChild(overlay);
}

/* DUPLICATE BLOCK COMMENTED OUT
        Object.assign(overlay.style, {
            position: 'fixed',
            top: '0',
            left: '0',
            width: '100%',
            height: '100%',
            backgroundColor: 'rgba(0,0,0,1)',
            zIndex: '2147483647',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center',
            alignItems: 'center'
        });

        const progressContainer = document.createElement('div');
        Object.assign(progressContainer.style, {
            width: '80%',
            maxWidth: '600px',
            backgroundColor: '#e5e7eb',
            borderRadius: '10px',
            height: '30px',
            overflow: 'hidden'
        });

        const progressBar = document.createElement('div');
        progressBar.id = 'progress-bar';
        Object.assign(progressBar.style, {
            width: '0%',
            height: '100%',
            backgroundColor: '#3b82f6',
            transition: 'width 1s ease-in-out'
        });

        progressContainer.appendChild(progressBar);
        overlay.appendChild(progressContainer);

        const textBelow = document.createElement('div');
        textBelow.innerText = 'Ecom Efficiency';
        Object.assign(textBelow.style, {
            marginTop: '20px',
            color: '#fff',
            fontSize: '24px',
            fontWeight: 'bold'
        });
        overlay.appendChild(textBelow);

        document.body.appendChild(overlay);
    }

    */
    function updateLoadingBar(percent) {
    const progressBar = document.getElementById('progress-bar');
    const percentageLabel = document.getElementById('percentage-label');
    if (progressBar && percentageLabel) {
        progressBar.style.width = percent + '%';
        // animate percentage text
        let currentPercent = parseInt(percentageLabel.innerText.replace('%', '')) || 0;
        const target = percent;
        const increment = target > currentPercent ? 1 : -1;
        clearInterval(progressBar.__interval);
        progressBar.__interval = setInterval(() => {
            currentPercent += increment;
            percentageLabel.innerText = currentPercent + '%';
            if ((increment > 0 && currentPercent >= target) || (increment < 0 && currentPercent <= target)) {
                clearInterval(progressBar.__interval);
            }
        }, 15);
    }
}


    function startFinalAnimation() {
    const progressBar = document.getElementById('progress-bar');
    const progressContainer = progressBar?.parentElement;
    const checkmarkContainer = document.getElementById('checkmark-container');
    const checkPath = checkmarkContainer?.querySelector('path');
    if (progressContainer && checkmarkContainer && checkPath) {
        progressContainer.style.opacity = '0';
        progressContainer.style.transition = 'opacity 1s ease-in-out';
        setTimeout(() => {
            progressContainer.style.display = 'none';
            checkmarkContainer.style.display = 'block';
            setTimeout(() => {
                checkmarkContainer.style.opacity = '1';
                checkPath.style.strokeDashoffset = '0';
            }, 50);
        }, 1000);
    }
}

// ===== GESTION DE L'ÉCRAN NOIR POUR LE LOGIN =====

function removeBlackScreen() {
    const overlay = document.getElementById('login-overlay');
    if (overlay) {
        console.log('[ATRIA AUTO LOGIN] 🖤➡️ Suppression de l\'écran noir');
        overlay.style.transition = 'opacity 0.5s ease-in-out';
        overlay.style.opacity = '0';
        setTimeout(() => {
            if (overlay && overlay.parentNode) {
                document.body.style.overflow = '';
                overlay.remove();
            }
        }, 500);
    } else {
        console.log('[ATRIA AUTO LOGIN] 🖤 Aucun écran noir à supprimer');
    }
}

function monitorLoginSuccess() {
    let checkCount = 0;
    const maxChecks = 30; // 15 secondes maximum (500ms * 30)
    
    const checkForPageChange = () => {
        checkCount++;
        console.log(`[ATRIA AUTO LOGIN] 👀 Vérification ${checkCount}/${maxChecks} - URL actuelle: ${window.location.href}`);
        
        // Si on n'est plus sur la page de login, succès !
        if (!window.location.href.startsWith('https://app.tryatria.com/login')) {
            console.log('[ATRIA AUTO LOGIN] ✅ Login réussi - changement de page détecté');
            removeBlackScreen();
            return;
        }
        
        // Vérifier s'il y a des messages d'erreur
        const errorElement = document.querySelector('.error, .alert, .alert-danger, [class*="error"], [class*="invalid"], .ant-message-error, .ant-notification-notice-error');
        if (errorElement && errorElement.textContent.trim()) {
            console.log('[ATRIA AUTO LOGIN] ❌ Message d\'erreur détecté:', errorElement.textContent.trim());
            console.log('[ATRIA AUTO LOGIN] 🖤 Écran noir maintenu - échec du login');
            return;
        }
        
        // Si on atteint le maximum de vérifications et qu'on est toujours sur la page de login
        if (checkCount >= maxChecks) {
            console.log('[ATRIA AUTO LOGIN] ⏰ Timeout - toujours sur la page de login après 15 secondes');
            console.log('[ATRIA AUTO LOGIN] 🖤 Écran noir maintenu - login probablement échoué');
            return;
        }
        
        // Continuer à vérifier
        setTimeout(checkForPageChange, 500);
    };
    
    // Commencer la surveillance après un délai pour laisser le temps au serveur de répondre
    setTimeout(checkForPageChange, 1000);
}

function hideLoadingBar() {
        const overlay = document.getElementById('login-overlay');
        if (overlay) overlay.remove();
    }
function showFullScreenOverlay(attempt = 1) {
        if (document.getElementById('__atria_overlay')) return;
        if (!document.body || !document.head) {
            if (attempt < 20) {
                return setTimeout(() => showFullScreenOverlay(attempt + 1), 50);
            }
            return;
        }
        const overlay = document.createElement('div');
        overlay.id = '__atria_overlay';
        overlay.style.position = 'fixed';
        overlay.style.top = '0';
        overlay.style.left = '0';
        overlay.style.width = '100vw';
        overlay.style.height = '100vh';
        overlay.style.background = '#000';
        overlay.style.zIndex = '999999';
        overlay.style.display = 'flex';
        overlay.style.flexDirection = 'column';
        overlay.style.alignItems = 'center';
        overlay.style.justifyContent = 'center';

        const text = document.createElement('div');
        text.textContent = 'Ecom Efficiency';
        text.style.color = '#fff';
        text.style.fontSize = '3rem';
        text.style.fontWeight = 'bold';
        text.style.fontFamily = 'Segoe UI, Arial, sans-serif';
        text.style.letterSpacing = '0.05em';
        overlay.appendChild(text);

        document.body.appendChild(overlay);
    }

    function hideFullScreenOverlay() {
        const overlay = document.getElementById('__atria_overlay');
        if (overlay) overlay.remove();
    }

    // Affiche l'overlay tout de suite et bloque le scroll tant qu'on est sur /login
    showLoadingBar();
    try { document.body.style.overflow = 'hidden'; } catch {}
    updateLoadingBar(20);

    // --- SURVEILLANCE DE L'URL POUR SUPPRIMER L'OVERLAY SI REDIRIGÉ ---
    const _atria_urlWatcher = setInterval(() => {
        // Maintenir l'overlay tant qu'on est sur /login pour ne pas dévoiler les logins
        if (!window.location.href.startsWith('https://app.tryatria.com/login')) {
            removeBlackScreen();
            clearInterval(_atria_urlWatcher);
        } else {
            // S'assurer que l'overlay est présent et au-dessus de tout
            if (!document.getElementById('login-overlay')) {
                showLoadingBar();
            }
            const overlay = document.getElementById('login-overlay');
            if (overlay) {
                overlay.style.zIndex = '2147483647';
            }
            try { document.body.style.overflow = 'hidden'; } catch {}
        }
    }, 300);

    function reactInput(element, value) {
        const nativeInputValueSetter = Object.getOwnPropertyDescriptor(element.__proto__, 'value').set;
        nativeInputValueSetter.call(element, value);
        element.dispatchEvent(new Event('input', { bubbles: true }));
        element.dispatchEvent(new Event('change', { bubbles: true }));
    }
    function fillAndLogin(attempt = 1) {
        if (!window.location.href.startsWith('https://app.tryatria.com/login')) {
            console.log('[ATRIA AUTO LOGIN] Plus sur la page de login - suppression de l\'écran noir');
            removeBlackScreen(); // Nous ne sommes plus sur la page de login → retirer l'overlay
            return;
        }
        const emailInput = document.getElementById('login_email');
        const passwordInput = document.getElementById('login_password');
        const loginBtn = document.querySelector('button[type="submit"].ant-btn-primary');
        if (emailInput && passwordInput && loginBtn) {
            console.log('[ATRIA AUTO LOGIN] Champs trouvés, tentative de remplissage');
            reactInput(emailInput, 'admin@ecomefficiency.com');
            reactInput(passwordInput, 'L.AK-r2YZSVWw$?GjJK');
            setTimeout(() => {
                console.log('[ATRIA AUTO LOGIN] Clic sur le bouton login');
                console.log('[ATRIA AUTO LOGIN] 🖤 Écran noir maintenu - surveillance du changement de page...');
                
                // Surveiller le changement de page après le login
                monitorLoginSuccess();
                
                loginBtn.click();
                
                // progression finale et maintenir overlay jusqu'au redirect
                updateLoadingBar(100);
                setTimeout(() => {
                    startFinalAnimation();
                    console.log('[ATRIA AUTO LOGIN] 🖤 Écran de chargement maintenu jusqu\'au changement d\'URL');
                }, 800);
    
            }, 400);
        } else {
            if (attempt < 30) {
                console.log(`[ATRIA AUTO LOGIN] Attente des champs... (tentative ${attempt})`);
                setTimeout(() => fillAndLogin(attempt + 1), 250);
            } else {
                console.warn('[ATRIA AUTO LOGIN] Impossible de trouver les champs après plusieurs tentatives.');
                console.log('[ATRIA AUTO LOGIN] 🖤 Écran noir maintenu - champs de login introuvables');
                // Ne pas supprimer l'écran noir car on est probablement encore sur la page de login
            }
        }
    }
    // Attendre que le DOM soit prêt
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => setTimeout(fillAndLogin, 200));
    } else {
        setTimeout(fillAndLogin, 200);
    }
})();
