// remove_dropship_banner.js
(function() {
  // Exécute sur toutes les pages de dropship.io
  if (!window.location.href.startsWith('https://app.dropship.io/')) return;

  function removeElements() {
    // Supprime la bannière limited-banner
    const banner = document.querySelector('div.limited-banner');
    if (banner) banner.remove();
    // Supprime les éléments adLibrary-item-insights
    document.querySelectorAll('div.adLibrary-item-insights').forEach(el => el.remove());
    // Supprime les boutons Upgrade
    document.querySelectorAll('button.main-sidebar-free-button').forEach(btn => btn.remove());
    // Rends les user-dropdown non cliquables
    document.querySelectorAll('.user-dropdown').forEach(el => {
      el.style.pointerEvents = 'none';
      el.style.opacity = '0.5';
      el.style.userSelect = 'none';
      el.title = 'Désactivé par extension';
    });
  }
  // Vérifie toutes les 0.1 secondes si les éléments existent
  setInterval(removeElements, 100);
})();
