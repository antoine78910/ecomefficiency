// popup.js – gère le choix du compte Pipiads

document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('button[data-target]').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.getAttribute('data-target'); // account1 / account2 / account3
      const url = `https://ecomefficiency.xyz/${target}.html`;

      chrome.tabs.query({ url }, tabs => {
        if (tabs && tabs.length) {
          chrome.tabs.update(tabs[0].id, { active: true });
        } else {
          chrome.tabs.create({ url });
        }
      });

      window.close();
    });
  });
});

// Ajoute un écouteur pour le bouton "OK" lorsque la popup est chargée

document.addEventListener('DOMContentLoaded', () => {
  const okButton = document.getElementById('okButton');
  if (okButton) {
    okButton.addEventListener('click', () => {
      // Ferme la popup
      window.close();
    });
  }
});