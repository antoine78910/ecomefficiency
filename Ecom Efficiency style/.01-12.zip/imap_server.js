const express = require('express');
const { ImapFlow } = require('imapflow');
require('dotenv').config();

const app = express();

// CORS pour permettre l'accès depuis l'extension
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
  } else {
    next();
  }
});
const PORT = process.env.PORT || process.env.IMAP_SERVER_PORT || 20016;

function mask(s) { return s ? s.replace(/.(?=.{4})/g, '*') : s; }

app.get('/otp', async (req, res) => {
  console.log('[imap] OTP request received at', new Date().toISOString());
  const imapHost = process.env.IMAP_HOST; // e.g., "imap.neospace.email"
  const imapPort = Number(process.env.IMAP_PORT || 993);
  const imapUser = process.env.IMAP_USER; // full email address
  const imapPass = process.env.IMAP_PASS; // app password
  const imapTLS  = String(process.env.IMAP_TLS || 'true') === 'true';
  const imapMethod = (process.env.IMAP_METHOD || 'LOGIN').toUpperCase(); // LOGIN or PLAIN

  console.log('[imap] Config:', { 
    host: imapHost, 
    port: imapPort, 
    user: imapUser ? imapUser.substring(0, 3) + '***' : 'missing',
    tls: imapTLS,
    method: imapMethod 
  });

  if (!imapHost || !imapUser || !imapPass) {
    console.error('[imap] Missing env vars', { host: !!imapHost, user: !!imapUser, pass: !!imapPass });
    return res.status(500).json({ error: 'Missing IMAP env vars' });
  }

  const client = new ImapFlow({
    host: imapHost,
    port: imapPort,
    secure: imapTLS,
    auth: { user: imapUser, pass: imapPass, method: imapMethod }
  });

  let code = '';
  try {
    await client.connect();
    const lock = await client.getMailboxLock('INBOX');
    try {
      // Search latest 20 unseen first, else latest 20
      let seq; 
      const unseen = await client.search({ seen: false }, { uid: true });
      if (unseen.length > 0) {
        seq = unseen.slice(-20);
      } else {
        const all = await client.search({}, { uid: true });
        seq = all.slice(-20);
      }
      seq = seq.reverse();

      for (const uid of seq) {
        const { content } = await client.download(uid, null, { uid: true });
        const raw = await contentToUtf8(content);
        // Quick filter to messages from OpenAI or referencing auth.openai.com
        const looksLikeOpenAI = /openai|auth\.openai\.com/i.test(raw);
        if (!looksLikeOpenAI) continue;
        // Extract the first 6-digit code in the message
        const m = raw.match(/\b(\d{6})\b/);
        if (m && m[1]) { code = m[1]; break; }
      }
    } finally {
      lock.release();
    }
  } catch (e) {
    console.error('[imap] Error while fetching OTP:', e);
    return res.status(500).json({ 
      error: (e && e.message) ? e.message : String(e),
      response: e && e.response,
      responseStatus: e && e.responseStatus,
      responseText: e && e.responseText,
      serverResponseCode: e && e.serverResponseCode
    });
  } finally {
    try { await client.logout(); } catch (_) {}
  }

  console.log('[imap] Sending response:', { code });
  res.json({ code });
});

async function contentToUtf8(content) {
  if (!content) return '';
  // Node stream
  if (typeof content.on === 'function') {
    return new Promise((resolve, reject) => {
      let data = '';
      content.on('data', chunk => { data += Buffer.from(chunk).toString('utf8'); });
      content.on('end', () => resolve(data));
      content.on('error', reject);
    });
  }
  // Buffer or Uint8Array
  if (Buffer.isBuffer(content)) return content.toString('utf8');
  if (content instanceof Uint8Array) return Buffer.from(content).toString('utf8');
  if (typeof content === 'string') return content;
  try { return String(content || ''); } catch (_) { return ''; }
}

app.listen(PORT, () => {
  console.log(`[imap_server] listening on ${PORT}`);
});

app.get('/health', (req, res) => {
  res.json({ ok: true, port: Number(PORT) });
});

// Route racine pour éviter "Cannot GET /"
app.get('/', (req, res) => {
  res.json({ 
    message: 'IMAP Server is running', 
    endpoints: ['/otp', '/health'],
    port: Number(PORT) 
  });
});


