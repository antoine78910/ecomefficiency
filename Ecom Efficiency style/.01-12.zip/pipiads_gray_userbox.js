// Greys out and disables interaction with the Pipiads user dropdown/menu block
(function() {
    'use strict';

    function applyGrey(el) {
        if (!el || el.dataset._pipiadsGrey === '1') return;
        el.style.filter = 'grayscale(100%)';
        el.style.opacity = '0.5';
        el.style.pointerEvents = 'none';
        el.style.userSelect = 'none';
        el.dataset._pipiadsGrey = '1';
    }

    function greyTargets() {
        let changed = false;

        // Grey the whole user box if present
        const userBox = document.querySelector('div.pp-dropdown.user-box');
        if (userBox) {
            applyGrey(userBox);
            changed = true;
        }

        // Grey the dropdown content block as a fallback
        const dropdown = document.querySelector('div.menu-dropdown.user-info-drop');
        if (dropdown) {
            applyGrey(dropdown);
            changed = true;
        }

        // Grey the inner menu list if present
        const mainList = document.querySelector('ul.menu-dropdown__main.userCenterDrop');
        if (mainList) {
            applyGrey(mainList);
            changed = true;
        }

        return changed;
    }

    function start() {
        greyTargets();
        const obs = new MutationObserver(() => {
            greyTargets();
        });
        obs.observe(document.documentElement, { childList: true, subtree: true });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', start);
    } else {
        start();
    }
})();


