// auto_login_shophunter.js
(function() {
    'use strict';

    const EMAIL = 'alishaeys@gmail.com';
    const PASSWORD = 'L.AK-r2YZSVWw$?';

    // ===== Loading Overlay =====
    function showLoadingOverlay() {
        if (document.getElementById('shophunter-loading-overlay')) return;

        const overlay = document.createElement('div');
        overlay.id = 'shophunter-loading-overlay';
        Object.assign(overlay.style, {
            position: 'fixed',
            inset: '0',
            width: '100vw',
            height: '100vh',
            background: 'linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%)',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: '2147483647',
            fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Inter, sans-serif'
        });

        const title = document.createElement('div');
        title.textContent = 'ECOM EFFICIENCY';
        Object.assign(title.style, {
            color: '#8b45c4',
            fontSize: '28px',
            fontWeight: '900',
            letterSpacing: '2.5px',
            marginBottom: '20px',
            textShadow: '0 0 18px rgba(139,69,196,0.35)'
        });

        const subtitle = document.createElement('div');
        subtitle.textContent = 'Logging in to Shophunter...';
        Object.assign(subtitle.style, {
            color: '#d1d5db',
            fontSize: '14px',
            marginBottom: '24px'
        });

        const spinner = document.createElement('div');
        Object.assign(spinner.style, {
            width: '50px',
            height: '50px',
            border: '4px solid rgba(139,69,196,0.25)',
            borderTop: '4px solid #8b45c4',
            borderRadius: '50%',
            animation: 'shh-spin 1s linear infinite'
        });

        const style = document.createElement('style');
        style.id = 'shophunter-loading-style';
        style.textContent = '@keyframes shh-spin { 0% { transform: rotate(0deg);} 100% { transform: rotate(360deg);} }';

        document.head.appendChild(style);
        overlay.appendChild(title);
        overlay.appendChild(subtitle);
        overlay.appendChild(spinner);
        document.body.appendChild(overlay);
    }

    function hideLoadingOverlay() {
        const overlay = document.getElementById('shophunter-loading-overlay');
        if (overlay) {
            overlay.style.opacity = '0';
            overlay.style.transition = 'opacity 300ms ease';
            setTimeout(() => overlay.remove(), 320);
        }
        const style = document.getElementById('shophunter-loading-style');
        if (style) style.remove();
    }

    function waitForElement(selector, timeout = 15000) {
        return new Promise((resolve, reject) => {
            const existing = document.querySelector(selector);
            if (existing) return resolve(existing);

            const observer = new MutationObserver(() => {
                const el = document.querySelector(selector);
                if (el) {
                    observer.disconnect();
                    resolve(el);
                }
            });
            observer.observe(document.documentElement || document.body, { childList: true, subtree: true });

            setTimeout(() => {
                observer.disconnect();
                reject(new Error('Timeout waiting for selector: ' + selector));
            }, timeout);
        });
    }

    function setInputValue(input, value) {
        input.focus();
        input.value = value;
        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
        input.blur();
    }

    async function autoLogin() {
        try {
            // Show overlay and set up safety timeouts
            showLoadingOverlay();
            let cleared = false;
            const clearOverlay = () => { if (!cleared) { cleared = true; hideLoadingOverlay(); } };

            // Ensure overlay disappears if we navigate away from login
            const navWatcher = setInterval(() => {
                if (!location.href.includes('/login')) {
                    clearInterval(navWatcher);
                    clearOverlay();
                }
            }, 400);

            // Hard timeout (15s)
            const timeoutId = setTimeout(() => {
                clearOverlay();
            }, 15000);

            // Target inputs by placeholder as provided
            const emailInput = await waitForElement('input[type="email"][placeholder="Enter your email"]');
            const passwordInput = await waitForElement('input[type="password"][placeholder="Enter your password"]');

            setInputValue(emailInput, EMAIL);
            await new Promise(r => setTimeout(r, 200));
            setInputValue(passwordInput, PASSWORD);

            // Find Sign In button
            let signInBtn = document.querySelector('button[type="button"] span, button span');
            let button = null;
            if (signInBtn && /sign\s*in/i.test(signInBtn.textContent || '')) {
                button = signInBtn.closest('button');
            }
            if (!button) {
                const candidates = Array.from(document.querySelectorAll('button'));
                button = candidates.find(b => /sign\s*in|log\s*in/i.test((b.textContent || '').trim()));
            }
            if (!button) throw new Error('Sign In button not found');

            if (button.disabled) {
                let tries = 0;
                while (button.disabled && tries < 20) {
                    await new Promise(r => setTimeout(r, 150));
                    tries++;
                }
            }

            // Observe URL change to hide overlay after click
            const afterClickWatcher = setInterval(() => {
                if (!location.href.includes('/login')) {
                    clearInterval(afterClickWatcher);
                    clearOverlay();
                    clearTimeout(timeoutId);
                }
            }, 300);

            button.click();
        } catch (e) {
            console.error('[SHOPHUNTER] Auto-login failed:', e);
            hideLoadingOverlay();
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', autoLogin);
    } else {
        autoLogin();
    }
})();


