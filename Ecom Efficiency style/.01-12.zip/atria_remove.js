(function(){
    'use strict';

    const TARGET_SELECTOR = 'div.ant-dropdown-trigger.flex.items-center.gap-2.cursor-pointer.pt-4.mb-3';
    const MAX_WAIT_MS = 15000;
    const CHECK_INTERVAL = 300;

    /**
     * Try to locate the dropdown trigger and disable it.
     */
    function disableAvatarButton(){
        const el = document.querySelector(TARGET_SELECTOR);
        if(!el) return false;
        el.style.pointerEvents = 'none';
        el.style.opacity = '0.6';
        return true;
    }

    /**
     * Add a fixed violet square bottom-right, purely decorative / non-interactive.
     */
    function addPurpleSquare(){
        if(document.getElementById('atria-purple-square')) return;
        const box = document.createElement('div');
        box.id = 'atria-purple-square';
        Object.assign(box.style, {
            position: 'fixed',
            bottom: '10px',
            right: '10px',
            width: '80px',
            height: '80px',
            backgroundColor: 'transparent',
            pointerEvents: 'auto',
            zIndex: '2147483647',
            borderRadius: '4px'
        });
        document.body.appendChild(box);
    }

    function run(){
        addPurpleSquare();
        if(disableAvatarButton()) return;

        // Poll until element exists or timeout.
        const start = Date.now();
        const interval = setInterval(()=>{
            if(disableAvatarButton()){
                clearInterval(interval);
            } else if(Date.now()-start > MAX_WAIT_MS){
                clearInterval(interval);
            }
        }, CHECK_INTERVAL);
    }

    if(document.readyState === 'loading'){
        document.addEventListener('DOMContentLoaded', run);
    }else{
        run();
    }
})();
