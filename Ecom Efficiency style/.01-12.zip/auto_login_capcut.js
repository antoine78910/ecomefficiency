// auto_login_capcut.js
(function () {
  'use strict';

  // --- AUTO LOGIN CAPCUT (email/password flow) ---
  const isCapcutLogin = (location.hostname === 'www.capcut.com') && (/^\/fr-fr\/login(\b|\/|$)/.test(location.pathname));
  if (!isCapcutLogin) return;

  console.log('[CapCut] Auto-login (email/password) started on:', location.href);
  console.log('[CapCut][Diag] Host:', location.hostname, 'Path:', location.pathname);

  // --- Loading overlay (CSP-safe, JS animation) ---
  function showLoadingOverlay() {
    if (document.getElementById('capcut-loading-overlay')) return;

    const overlay = document.createElement('div');
    overlay.id = 'capcut-loading-overlay';
    Object.assign(overlay.style, {
      position: 'fixed',
      top: '0',
      left: '0',
      width: '100vw',
      height: '100vh',
      background: 'linear-gradient(135deg, #0b0b0b 0%, #171717 100%)',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'center',
      zIndex: '2147483647',
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
      pointerEvents: 'auto'
    });

    const logo = document.createElement('div');
    logo.textContent = 'ECOM EFFICIENCY';
    Object.assign(logo.style, {
      color: '#8b45c4',
      fontSize: '26px',
      fontWeight: '900',
      letterSpacing: '3px',
      marginBottom: '24px',
      textShadow: '0 0 18px rgba(139, 69, 196, 0.35)'
    });
    overlay.appendChild(logo);

    const spinner = document.createElement('div');
    Object.assign(spinner.style, {
      width: '46px',
      height: '46px',
      border: '4px solid rgba(139, 69, 196, 0.2)',
      borderTop: '4px solid #8b45c4',
      borderRadius: '50%'
    });
    overlay.appendChild(spinner);

    let __capcutSpinnerAngle = 0;
    const __capcutAnimateSpinner = () => {
      __capcutSpinnerAngle = (__capcutSpinnerAngle + 6) % 360;
      spinner.style.transform = `rotate(${__capcutSpinnerAngle}deg)`;
      requestAnimationFrame(__capcutAnimateSpinner);
    };
    requestAnimationFrame(__capcutAnimateSpinner);

    // Swallow interactions
    const swallow = (e) => { e.stopPropagation(); e.preventDefault(); };
    ['click','mousedown','mouseup','pointerdown','pointerup','contextmenu','touchstart','touchend','wheel'].forEach(evt => {
      overlay.addEventListener(evt, swallow, true);
    });

    document.body.appendChild(overlay);
    console.log('[CapCut][Overlay] Displayed');
  }

  function hideLoadingOverlay() {
    const overlay = document.getElementById('capcut-loading-overlay');
    if (!overlay) return;
    overlay.style.opacity = '0';
    overlay.style.transition = 'opacity 250ms ease';
    setTimeout(() => {
      overlay.remove();
      console.log('[CapCut][Overlay] Hidden');
    }, 260);
  }

  function monitorUrlChangeAndHide() {
    let current = window.location.href;
    const timer = setInterval(() => {
      if (window.location.href !== current) {
        console.log('[CapCut][Overlay] URL changed:', current, '->', window.location.href);
        current = window.location.href;
        if (!/\/login(\b|\/)/.test(location.pathname)) {
          hideLoadingOverlay();
        clearInterval(timer);
        }
      }
    }, 400);
    // Safety: hide after 25s to avoid being stuck if login fails
    setTimeout(hideLoadingOverlay, 25000);
    return timer;
  }

  function waitForElement(selector, timeout = 15000) {
    return new Promise((resolve, reject) => {
      const found = document.querySelector(selector);
      if (found) return resolve(found);

      const observer = new MutationObserver(() => {
        const el = document.querySelector(selector);
        if (el) {
          observer.disconnect();
          resolve(el);
        }
      });
      observer.observe(document.body, { childList: true, subtree: true });

      setTimeout(() => {
        observer.disconnect();
        reject(new Error(`Element not found: ${selector}`));
      }, timeout);
    });
  }

  function isVisible(el) {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    if (style.visibility === 'hidden' || style.display === 'none' || parseFloat(style.opacity || '1') === 0) return false;
    const rect = el.getBoundingClientRect();
    return !!(el.offsetParent || rect.width > 0 || rect.height > 0);
  }

  function waitForVisibleElement(selector, timeout = 20000) {
    return new Promise((resolve, reject) => {
      const pickVisible = () => {
        const all = Array.from(document.querySelectorAll(selector));
        if (pickVisible.__firstLog !== false) {
          console.log('[CapCut][Diag] waitForVisibleElement selector:', selector, 'candidates:', all.length);
          pickVisible.__firstLog = false;
        }
        return all.find(isVisible) || null;
      };
      const immediate = pickVisible();
      if (immediate) return resolve(immediate);

      const observer = new MutationObserver(() => {
        const el = pickVisible();
        if (el) {
          observer.disconnect();
          resolve(el);
        }
      });
      observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['style', 'class'] });

      const timer = setTimeout(() => {
        observer.disconnect();
        reject(new Error(`Visible element not found: ${selector}`));
      }, timeout);
    });
  }

  function fastFillField(field, text) {
    console.log('[CapCut][Fill] Target input:', field && field.outerHTML ? field.outerHTML.slice(0, 140) + '...' : field);
    field.focus();
    try {
      const proto = Object.getPrototypeOf(field);
      const valueSetter = Object.getOwnPropertyDescriptor(proto, 'value')?.set || Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
      console.log('[CapCut][Fill] Using native value setter:', !!valueSetter);
      if (valueSetter) {
        valueSetter.call(field, text);
      } else {
        field.value = text;
      }
    } catch (err) {
      console.warn('[CapCut][Fill] Setter failed, direct assignment. Err:', err);
      field.value = text;
    }
    try {
      field.dispatchEvent(new Event('input', { bubbles: true, cancelable: true }));
      // Essayez InputEvent si disponible
      if (typeof InputEvent === 'function') {
        field.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, data: text.slice(-1) || '' }));
      }
      field.dispatchEvent(new Event('change', { bubbles: true, cancelable: true }));
      // Simuler une frappe finale pour certains frameworks
      const lastChar = (text || '').slice(-1) || ' ';
      const keyInit = { key: lastChar, bubbles: true, cancelable: true };
      field.dispatchEvent(new KeyboardEvent('keydown', keyInit));
      field.dispatchEvent(new KeyboardEvent('keypress', keyInit));
      field.dispatchEvent(new KeyboardEvent('keyup', keyInit));
      field.dispatchEvent(new Event('blur', { bubbles: true }));
    } catch (err2) {
      console.warn('[CapCut][Fill] Event dispatch error:', err2);
    }
    console.log('[CapCut][Fill] Value now length:', (field.value || '').length, 'attr value length:', (field.getAttribute('value') || '').length);
  }

  async function fillPasswordRobust(pwdInput, text) {
    if (!pwdInput) return 0;
    console.log('[CapCut][Pwd] Robust fill start');
    fastFillField(pwdInput, text);
    let len = (pwdInput.value || '').length;
    console.log('[CapCut][Pwd] After fastFill length:', len);
    if (len > 0) return len;

    // Char-by-char fallback
    try {
      const proto = Object.getPrototypeOf(pwdInput);
      const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set || Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
      if (setter) setter.call(pwdInput, ''); else pwdInput.value = '';
      pwdInput.dispatchEvent(new Event('input', { bubbles: true }));
      console.log('[CapCut][Pwd] Typing fallback engaged');
      for (const ch of text.split('')) {
        pwdInput.dispatchEvent(new KeyboardEvent('keydown', { key: ch, bubbles: true, cancelable: true }));
        if (setter) setter.call(pwdInput, (pwdInput.value || '') + ch); else pwdInput.value = (pwdInput.value || '') + ch;
        pwdInput.dispatchEvent(new Event('input', { bubbles: true }));
        pwdInput.dispatchEvent(new KeyboardEvent('keyup', { key: ch, bubbles: true, cancelable: true }));
        await new Promise(r => setTimeout(r, 25));
      }
      pwdInput.dispatchEvent(new Event('change', { bubbles: true }));
      pwdInput.dispatchEvent(new Event('blur', { bubbles: true }));
    } catch (err) {
      console.warn('[CapCut][Pwd] Fallback typing error:', err);
    }
    len = (pwdInput.value || '').length;
    console.log('[CapCut][Pwd] After fallback length:', len);
    return len;
  }

  function getElementLabel(el) {
    if (!el) return '';
    const aria = el.getAttribute && (el.getAttribute('aria-label') || '');
    const title = el.getAttribute && (el.getAttribute('title') || '');
    const value = (el.value || '').toString();
    const txt = (el.textContent || '').toString();
    return (aria || title || value || txt).trim();
  }

  function findButtonByLabels(labels, root = document) {
    const candidates = Array.from(root.querySelectorAll('button, input[type="button"], input[type="submit"], [role="button"]'));
    const lowerLabels = labels.map(l => l.toLowerCase());
    return candidates.find(el => {
      const label = getElementLabel(el).toLowerCase();
      return lowerLabels.some(l => label.includes(l));
    }) || null;
  }

  async function run() {
    try {
      // Show overlay immediately and monitor URL change
      showLoadingOverlay();
      monitorUrlChangeAndHide();

      // 1) Email
      const emailSelector = 'input[name="signUsername"], input[autocomplete="username"], input[placeholder*="adresse e-mail" i], input[placeholder*="e-mail" i]';
      const emailInput = await waitForElement(emailSelector, 20000);
      console.log('[CapCut] Email field ready');
      fastFillField(emailInput, 'ecom.efficiency1@gmail.com');
      console.log('[CapCut][Diag] Email after fill length:', (emailInput.value || '').length);

      // 2) Click "Continuer"
      await new Promise(r => setTimeout(r, 200));
      let continueBtn = findButtonByLabels(['Continuer']);
      if (!continueBtn) {
        // try specific class if present
        continueBtn = document.querySelector('button.lv_sign_in_panel_wide-primary-button');
      }
      if (!continueBtn) throw new Error('Continuer button not found');
      if (continueBtn.disabled) {
        let tries = 0;
        while (continueBtn.disabled && tries < 25) {
          await new Promise(r => setTimeout(r, 200));
          tries++;
        }
      }
      console.log('[CapCut] Clicking Continuer');
      continueBtn.click();
      console.log('[CapCut][Diag] Continuer clicked, waiting for password field...');

      // 3) Password
      const passwordSelector = 'input[type="password"], input[placeholder*="mot de passe" i]';
      const passwordInput = await waitForVisibleElement(passwordSelector, 20000);
      console.log('[CapCut] Password field ready');
      console.log('[CapCut][Diag] Password input before fill value length:', (passwordInput.value || '').length);
      await fillPasswordRobust(passwordInput, 'L.AK-r2YZSVWw$?');
      // Vérifier que le champ n'est pas vide après remplissage
      if (!passwordInput.value || passwordInput.value.length === 0) {
        // Retenter une fois avec une saisie caractère par caractère
        const text = 'L.AK-r2YZSVWw$?';
        passwordInput.focus();
        try {
          const proto = Object.getPrototypeOf(passwordInput);
          const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set || Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
          // Effacer
          if (setter) setter.call(passwordInput, ''); else passwordInput.value = '';
          passwordInput.dispatchEvent(new Event('input', { bubbles: true }));
          console.log('[CapCut][Diag] Char-by-char fallback engaged');
          for (const ch of text.split('')) {
            passwordInput.dispatchEvent(new KeyboardEvent('keydown', { key: ch, bubbles: true, cancelable: true }));
            if (setter) setter.call(passwordInput, (passwordInput.value || '') + ch); else passwordInput.value = (passwordInput.value || '') + ch;
            passwordInput.dispatchEvent(new Event('input', { bubbles: true }));
            passwordInput.dispatchEvent(new KeyboardEvent('keyup', { key: ch, bubbles: true, cancelable: true }));
            await new Promise(r => setTimeout(r, 20));
          }
          passwordInput.dispatchEvent(new Event('change', { bubbles: true }));
          passwordInput.dispatchEvent(new Event('blur', { bubbles: true }));
          console.log('[CapCut][Diag] Password after fallback value length:', (passwordInput.value || '').length);
        } catch {}
      }
      // Extra: composition events then short debounce
      try {
        passwordInput.dispatchEvent(new CompositionEvent('compositionstart', { bubbles: true }));
        passwordInput.dispatchEvent(new CompositionEvent('compositionend', { bubbles: true }));
      } catch {}
      await new Promise(r => setTimeout(r, 120));

      // 4) Click "Connexion"
      await new Promise(r => setTimeout(r, 200));
      // Re-acquire visible password field just before submit in case of re-render
      let currentPwd = (await waitForVisibleElement(passwordSelector, 5000).catch(() => null)) || passwordInput;
      if (!currentPwd || (currentPwd.value || '').length === 0) {
        console.log('[CapCut][Diag] Refill before submit as value empty or input replaced');
        await fillPasswordRobust(currentPwd || passwordInput, 'L.AK-r2YZSVWw$?');
      }
      let loginBtn = findButtonByLabels(['Connexion', 'Se connecter']);
      if (!loginBtn) {
        loginBtn = document.querySelector('button.lv_sign_in_panel_wide-sign-in-button, button.lv_sign_in_panel_wide-primary-button.lv-btn-size-large');
      }
      if (!loginBtn) {
        // fallback: press Enter in password
        const enterInit = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true };
        passwordInput.focus();
        passwordInput.dispatchEvent(new KeyboardEvent('keydown', enterInit));
        passwordInput.dispatchEvent(new KeyboardEvent('keyup', enterInit));
        console.warn('[CapCut] Login button not found, tried Enter fallback');
        return;
      }
      console.log('[CapCut][Diag] Login button candidate:', loginBtn && loginBtn.outerHTML ? loginBtn.outerHTML.slice(0, 140) + '...' : loginBtn);
      if (loginBtn.disabled) {
        let tries = 0;
        while (loginBtn.disabled && tries < 25) {
          await new Promise(r => setTimeout(r, 200));
          tries++;
        }
      }
      console.log('[CapCut] Clicking Connexion (password length:', ((currentPwd && currentPwd.value) || '').length, ')');
      loginBtn.click();
      const form = passwordInput.closest('form');
      console.log('[CapCut][Diag] Form present:', !!form);

      // Post-click validation: if warning message still visible, try Enter fallback
      setTimeout(async () => {
        const warn = document.querySelector('.lv_sign_in_panel_wide-warn');
        const pwdNow = (await waitForVisibleElement(passwordSelector, 1000).catch(() => null)) || currentPwd;
        const lenNow = (pwdNow && pwdNow.value) ? pwdNow.value.length : 0;
        console.log('[CapCut][Diag] After click, warn visible:', !!warn, 'pwd length:', lenNow);
        if ((warn && /ne peut pas être vide/i.test(warn.textContent || '')) || lenNow === 0) {
          console.warn('[CapCut] Validation shows empty password, retrying with Enter fallback');
          const enterInit = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true };
          pwdNow && pwdNow.focus();
          pwdNow && pwdNow.dispatchEvent(new KeyboardEvent('keydown', enterInit));
          pwdNow && pwdNow.dispatchEvent(new KeyboardEvent('keyup', enterInit));
        }
      }, 500);
    } catch (e) {
      console.error('[CapCut] Auto-login failed:', e);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run);
  } else {
    run();
  }
})();
