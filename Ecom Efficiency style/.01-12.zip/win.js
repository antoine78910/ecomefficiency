// win.js
(function() {
    /**
     * Affiche un overlay plein écran avec une barre de progression animée
     * afin de masquer les champs de connexion pendant l’auto-login.
     */
    function showLoadingOverlay() {
        if (document.getElementById('auto-login-overlay')) return; // déjà présent
        const overlay = document.createElement('div');
        overlay.id = 'auto-login-overlay';
        Object.assign(overlay.style, {
            position: 'fixed',
            top: '0',
            left: '0',
            width: '100vw',
            height: '100vh',
            background: 'linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%)',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center',
            alignItems: 'center',
            zIndex: '2147483647',
            fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
        });

        const logo = document.createElement('div');
        logo.textContent = 'ECOM EFFICIENCY';
        Object.assign(logo.style, {
            color: '#8b45c4',
            fontSize: '2.5em',
            fontWeight: '900',
            letterSpacing: '3px',
            marginBottom: '40px',
            textShadow: '0 0 20px rgba(139, 69, 196, 0.3)'
        });
        overlay.appendChild(logo);

        const spinner = document.createElement('div');
        Object.assign(spinner.style, {
            width: '50px',
            height: '50px',
            border: '4px solid rgba(139, 69, 196, 0.2)',
            borderTop: '4px solid #8b45c4',
            borderRadius: '50%'
        });

        if (!document.getElementById('auto-login-style')) {
            const styleElem = document.createElement('style');
            styleElem.id = 'auto-login-style';
            styleElem.textContent = '@keyframes wh-spin {0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}';
            document.head.appendChild(styleElem);
        }
        spinner.style.animation = 'wh-spin 1s linear infinite';

        overlay.appendChild(spinner);
        document.body.appendChild(overlay);
    }
    // Attendre que le DOM soit prêt
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', init);
    } else {
      init();

    // Afficher une barre de chargement pour masquer les identifiants (style Pipiads)
    function showLoadingOverlay() {
        if (document.getElementById('auto-login-overlay')) return;
        const overlay = document.createElement('div');
        overlay.id = 'auto-login-overlay';
        Object.assign(overlay.style, {
            position: 'fixed',
            top: '0',
            left: '0',
            width: '100vw',
            height: '100vh',
            background: 'linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%)',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center',
            alignItems: 'center',
            zIndex: '2147483647',
            fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
        });

        const logo = document.createElement('div');
        logo.textContent = 'ECOM EFFICIENCY';
        Object.assign(logo.style, {
            color: '#8b45c4',
            fontSize: '2.5em',
            fontWeight: '900',
            letterSpacing: '3px',
            marginBottom: '40px',
            textShadow: '0 0 20px rgba(139, 69, 196, 0.3)'
        });
        overlay.appendChild(logo);

        const spinner = document.createElement('div');
        Object.assign(spinner.style, {
            width: '50px',
            height: '50px',
            border: '4px solid rgba(139, 69, 196, 0.2)',
            borderTop: '4px solid #8b45c4',
            borderRadius: '50%'
        });

        if (!document.getElementById('auto-login-style')) {
            const styleElem = document.createElement('style');
            styleElem.id = 'auto-login-style';
            styleElem.textContent = '@keyframes wh-spin {0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}';
            document.head.appendChild(styleElem);
        }
        spinner.style.animation = 'wh-spin 1s linear infinite';

        overlay.appendChild(spinner);
        document.body.appendChild(overlay);
    }
    }
  
    function init() {
      // Affiche la barre de chargement
      showLoadingOverlay();

      // 1) Sélectionner l’input email
      const emailInput = document.querySelector('input#Email-2[name="Email"]');
      // 2) Sélectionner l’input password
      //    Si ton input password porte un autre id ou name, ajuste-le ici
      const passwordInput = document.querySelector('input[type="password"], input#Password-2[name="Password"]');
      // 3) Sélectionner le bouton de submit
      const loginBtn = document.querySelector('button.button.login.w-button');
  
      if (!emailInput || !passwordInput || !loginBtn) {
        console.warn('[auto-login] Un ou plusieurs éléments introuvables.');
        return;
      }
  
      // Remplir les champs
      emailInput.value = 'yegepo2411@lovleo.com';
      passwordInput.value = '!bcE9HL4p!QkF@D';
  
      // Optionnel : simuler un event “input” pour certains frameworks React/Vue/Angular
      emailInput.dispatchEvent(new Event('input', { bubbles: true }));
      passwordInput.dispatchEvent(new Event('input', { bubbles: true }));
  
      // Cliquer sur le bouton
      loginBtn.click();
    }
  })();
  