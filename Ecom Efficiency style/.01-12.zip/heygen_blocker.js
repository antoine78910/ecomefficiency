(function() {
    'use strict';

    console.log('[HEYGEN-BLOCKER] Script started on:', window.location.href);

    // Fonction pour supprimer le popup "manage_add_ons" sur /settings
    function removeAddOnsPopup() {
        // Chercher tous les dialogs avec role="dialog" et data-state="open"
        const dialogs = document.querySelectorAll('div[role="dialog"][data-state="open"]');
        
        for (const dialog of dialogs) {
            const dialogText = dialog.textContent || '';
            
            // Vérifier si c'est le popup des add-ons
            if (dialogText.includes('manage_add_ons') || 
                dialogText.includes('Generative Credit Pack') || 
                dialogText.includes('Priority Processing Pack')) {
                
                console.log('[HEYGEN-BLOCKER] ✅ Add-ons popup detected, removing...');
                
                // Méthode 1: Essayer de cliquer sur le bouton de fermeture
                const closeButton = dialog.querySelector('button iconpark-icon[name="close"]');
                if (closeButton && closeButton.parentElement) {
                    closeButton.parentElement.click();
                    console.log('[HEYGEN-BLOCKER] ✅ Clicked close button on add-ons popup');
                }
                
                // Méthode 2: Supprimer directement le dialog
                setTimeout(() => {
                    if (dialog.parentElement) {
                        dialog.remove();
                        console.log('[HEYGEN-BLOCKER] ✅ Add-ons popup removed directly');
                    }
                }, 200);
                
                // Supprimer aussi l'overlay (backdrop) s'il existe
                const overlay = document.querySelector('div[data-radix-dialog-overlay]');
                if (overlay) {
                    overlay.remove();
                    console.log('[HEYGEN-BLOCKER] ✅ Dialog overlay removed');
                }
                
                return true;
            }
        }
        
        return false;
    }

    // Fonction pour supprimer le bouton "Upgrade to Teams"
    function removeUpgradeButton() {
        // Sélecteurs pour le bouton upgrade
        const upgradeSelectors = [
            'button:contains("Upgrade to Teams")',
            'div[data-show-banner="false"] button',
            '.css-15d3cyv button',
            'button[class*="tw-inline-flex"]:has(iconpark-icon[name="pro"])'
        ];

        // Recherche manuelle par contenu texte
        const allButtons = document.querySelectorAll('button');
        let upgradeButton = null;

        for (const btn of allButtons) {
            const btnText = btn.textContent.trim();
            if (btnText.includes('Upgrade to Teams') || btnText.includes('Upgrade') && btnText.includes('Teams')) {
                upgradeButton = btn;
                console.log('[HEYGEN-BLOCKER] ✅ Upgrade button found by text');
                break;
            }
        }

        // Si pas trouvé par texte, chercher par icône pro
        if (!upgradeButton) {
            const proButtons = document.querySelectorAll('button');
            for (const btn of proButtons) {
                const proIcon = btn.querySelector('iconpark-icon[name="pro"]');
                if (proIcon) {
                    upgradeButton = btn;
                    console.log('[HEYGEN-BLOCKER] ✅ Upgrade button found by pro icon');
                    break;
                }
            }
        }

        // Si pas trouvé, chercher le container parent
        if (!upgradeButton) {
            const upgradeContainer = document.querySelector('div[data-show-banner="false"]');
            if (upgradeContainer) {
                upgradeButton = upgradeContainer.querySelector('button');
                console.log('[HEYGEN-BLOCKER] ✅ Upgrade button found by container');
            }
        }

        if (upgradeButton) {
            // Supprimer le bouton et son container parent si nécessaire
            const parentDiv = upgradeButton.closest('div[data-show-banner="false"]');
            if (parentDiv) {
                parentDiv.remove();
                console.log('[HEYGEN-BLOCKER] ✅ Upgrade button container removed');
            } else {
                upgradeButton.remove();
                console.log('[HEYGEN-BLOCKER] ✅ Upgrade button removed');
            }
            return true;
        }

        return false;
    }

    // Fonction pour créer les rectangles de blocage violets
    function createBlockingRectangles() {
        // Vérifier si déjà créés
        if (document.getElementById('heygen-blocker-left') || document.getElementById('heygen-blocker-right')) {
            return;
        }

        // Rectangle de gauche (bas à gauche) - agrandi et capte tous les clics
        const leftBlocker = document.createElement('div');
        leftBlocker.id = 'heygen-blocker-left';
        Object.assign(leftBlocker.style, {
            position: 'fixed',
            bottom: '0',
            left: '0',
            width: '280px',
            height: '180px',
            backgroundColor: 'transparent',
            zIndex: '2147483647',
            pointerEvents: 'auto',
            cursor: 'not-allowed'
        });

        // Rectangle de droite (bas à droite) - agrandi et capte tous les clics
        const rightBlocker = document.createElement('div');
        rightBlocker.id = 'heygen-blocker-right';
        Object.assign(rightBlocker.style, {
            position: 'fixed',
            bottom: '0',
            right: '0',
            width: '140px',
            height: '120px',
            backgroundColor: 'transparent',
            zIndex: '2147483647',
            pointerEvents: 'auto',
            cursor: 'not-allowed'
        });

        // Ajouter au DOM
        document.body.appendChild(leftBlocker);
        document.body.appendChild(rightBlocker);

        // Intercepter explicitement les clics/contextmenu sur les zones
        const swallow = (e) => { e.stopPropagation(); e.preventDefault(); };
        ['click','mousedown','mouseup','pointerdown','pointerup','contextmenu','touchstart','touchend'].forEach(evt => {
            leftBlocker.addEventListener(evt, swallow, true);
            rightBlocker.addEventListener(evt, swallow, true);
        });

        console.log('[HEYGEN-BLOCKER] ✅ Purple blocking rectangles created');
    }

    // Observer pour surveiller les changements du DOM
    function setupObserver() {
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.type === 'childList') {
                    // Vérifier s'il y a de nouveaux boutons upgrade ou popups
                    setTimeout(() => {
                        removeUpgradeButton();
                        removeAddOnsPopup();
                    }, 100);
                }
            });
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });

        console.log('[HEYGEN-BLOCKER] ✅ DOM observer setup');
    }

    // Fonction principale d'initialisation
    function initialize() {
        console.log('[HEYGEN-BLOCKER] Initializing...');

        // Supprimer le bouton upgrade initial
        removeUpgradeButton();
        
        // Supprimer le popup add-ons initial
        removeAddOnsPopup();

        // Créer les rectangles de blocage
        createBlockingRectangles();

        // Configurer l'observer pour les futurs changements
        setupObserver();

        // Réessayer la suppression du bouton et popup toutes les 2 secondes (au cas où ils apparaissent plus tard)
        setInterval(() => {
            removeUpgradeButton();
            removeAddOnsPopup();
        }, 2000);

        console.log('[HEYGEN-BLOCKER] ✅ Initialization complete');
    }

    // Démarrer quand le DOM est prêt
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initialize);
    } else {
        // Si le DOM est déjà chargé, attendre un peu puis initialiser
        setTimeout(initialize, 500);
    }

    // Réinitialiser si la page change (SPA)
    let currentUrl = window.location.href;
    setInterval(() => {
        if (window.location.href !== currentUrl) {
            currentUrl = window.location.href;
            console.log('[HEYGEN-BLOCKER] URL changed, reinitializing...');
            setTimeout(initialize, 1000);
        }
    }, 1000);

})();