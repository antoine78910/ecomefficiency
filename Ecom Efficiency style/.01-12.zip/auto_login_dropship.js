// auto_login_dropship.js
(function() {
  // Exécute uniquement sur la page de login dropship.io
  if (!window.location.href.startsWith('https://app.dropship.io/login')) return;

  const EMAIL = 'efficiencyecom@gmail.com';
  const PASSWORD = 'C.YBnm*C%t2as6_';

  // Planifier un rechargement unique 7s après le début de l'auto-login
  function scheduleOneTimeReload() {
    try {
      if (sessionStorage.getItem('DROPSHIP_RELOAD_DONE') === '1') return;
      let deadlineStr = sessionStorage.getItem('DROPSHIP_RELOAD_DEADLINE_MS');
      if (!deadlineStr) {
        deadlineStr = String(Date.now() + 7000);
        sessionStorage.setItem('DROPSHIP_RELOAD_DEADLINE_MS', deadlineStr);
      }
      const deadline = parseInt(deadlineStr, 10);
      if (!isFinite(deadline)) return;
      const delay = Math.max(0, deadline - Date.now());
      setTimeout(function() {
        try {
          if (sessionStorage.getItem('DROPSHIP_RELOAD_DONE') === '1') return;
          sessionStorage.setItem('DROPSHIP_RELOAD_DONE', '1');
          sessionStorage.removeItem('DROPSHIP_RELOAD_DEADLINE_MS');
        } catch (_) {}
        try { location.reload(); } catch (_) {}
      }, delay);
    } catch (_) {}
  }

  function fillAndSubmitDropship() {
    // Démarrer le timer de reload unique
    scheduleOneTimeReload();

    const emailInput = document.querySelector('input[type="email"][name="email"], input#email');
    if (emailInput) {
      emailInput.value = EMAIL;
      emailInput.dispatchEvent(new Event('input', { bubbles: true }));
    }
    const passwordInput = document.querySelector('input[name="password"], input#password');
    if (passwordInput) {
      passwordInput.value = PASSWORD;
      passwordInput.dispatchEvent(new Event('input', { bubbles: true }));
    }
    const loginBtn = document.querySelector('button[type="submit"].login-form-submit, button[type="submit"].ant-btn-primary');
    if (loginBtn) {
      setTimeout(() => loginBtn.click(), 300);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', fillAndSubmitDropship);
  } else {
    fillAndSubmitDropship();
  }
})();
