(function() {
  'use strict';

  const EMAIL = 'admin@ecomefficiency.com';
  const PASSWORD = 'JHvtviciyz?75jhbe3!';
  // TEMP: disable loading overlay for debugging
  const DISABLE_LOADING_OVERLAY = true;

  function onTargetPage() {
    try {
      return location.hostname.endsWith('higgsfield.ai') && location.pathname.startsWith('/auth/login');
    } catch (_) {
      return false;
    }
  }

  function isVisible(el) {
    if (!el) return false;
    const cs = getComputedStyle(el);
    if (cs.visibility === 'hidden' || cs.display === 'none' || Number(cs.opacity) === 0) return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }

  function waitForSelector(selector, timeoutMs = 15000) {
    return new Promise(function(resolve, reject) {
      const start = Date.now();
      const check = function() {
        const el = document.querySelector(selector);
        if (el && isVisible(el)) return resolve(el);
        if (Date.now() - start >= timeoutMs) return reject(new Error('Timeout waiting for ' + selector));
        setTimeout(check, 100);
      };
      check();
    });
  }

  // ===== Overlay de chargement (même style que Pipiads) =====
  function showLoadingOverlay() {
    if (DISABLE_LOADING_OVERLAY) return;
    if (document.getElementById('higgsfield-loading-overlay')) return;

    const overlay = document.createElement('div');
    overlay.id = 'higgsfield-loading-overlay';
    Object.assign(overlay.style, {
      position: 'fixed',
      top: '0',
      left: '0',
      width: '100vw',
      height: '100vh',
      background: 'linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%)',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'center',
      zIndex: '2147483647',
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
    });

    const logo = document.createElement('div');
    logo.textContent = 'ECOM EFFICIENCY';
    Object.assign(logo.style, {
      color: '#8b45c4',
      fontSize: '2.5em',
      fontWeight: '900',
      letterSpacing: '3px',
      marginBottom: '40px',
      textShadow: '0 0 20px rgba(139, 69, 196, 0.3)'
    });
    overlay.appendChild(logo);

    const spinner = document.createElement('div');
    Object.assign(spinner.style, {
      width: '50px',
      height: '50px',
      border: '4px solid rgba(139, 69, 196, 0.2)',
      borderTop: '4px solid #8b45c4',
      borderRadius: '50%'
    });

    // CSS animation via <style>
    if (!document.getElementById('higgsfield-loading-style')) {
      const style = document.createElement('style');
      style.id = 'higgsfield-loading-style';
      style.textContent = '@keyframes higgsfield-spin {0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}';
      document.head.appendChild(style);
    }
    spinner.style.animation = 'higgsfield-spin 1s linear infinite';

    overlay.appendChild(spinner);
    document.body.appendChild(overlay);
  }

  function hideLoadingOverlay() {
    const overlay = document.getElementById('higgsfield-loading-overlay');
    if (overlay) {
      overlay.style.opacity = '0';
      overlay.style.transition = 'opacity 0.5s ease';
      setTimeout(function() {
        try { overlay.remove(); } catch (_) {}
      }, 500);
    }
  }

  // Retire l'overlay dès qu'on n'est plus sur /auth/login
  let __urlWatcher = null;
  function startUrlWatcher() {
    if (__urlWatcher) return;
    __urlWatcher = setInterval(function() {
      if (!onTargetPage()) {
        hideLoadingOverlay();
        clearInterval(__urlWatcher);
        __urlWatcher = null;
      }
    }, 500);
  }

  async function run() {
    if (!onTargetPage()) return;
    try {
      // Force remove any leftover overlay nodes from other scripts
      var overlay = document.getElementById('auto-login-overlay');
      if (overlay) overlay.remove();
      var styleEl = document.getElementById('auto-login-style');
      if (styleEl) styleEl.remove();
      // Ensure our Higgsfield overlay is not shown while debugging
      hideLoadingOverlay();
    } catch (_) {}
    try {
      // Afficher l'overlay pour masquer les logs/écran
      showLoadingOverlay();
      startUrlWatcher();

      const emailInput = await waitForSelector('input[type="email"][name="email"], input[data-sentry-element="AuthInput"][type="email"]', 20000);
      const pwdInput = await waitForSelector('input[type="password"][name="password"], input[data-sentry-element="AuthInput"][type="password"]', 20000);

      // Fill email
      emailInput.focus();
      emailInput.value = EMAIL;
      emailInput.dispatchEvent(new Event('input', { bubbles: true }));
      emailInput.dispatchEvent(new Event('change', { bubbles: true }));
      emailInput.dispatchEvent(new Event('blur', { bubbles: true }));

      // Fill password
      pwdInput.focus();
      pwdInput.value = PASSWORD;
      pwdInput.dispatchEvent(new Event('input', { bubbles: true }));
      pwdInput.dispatchEvent(new Event('change', { bubbles: true }));
      pwdInput.dispatchEvent(new Event('blur', { bubbles: true }));

      // Submit via a visible submit input/button or press Enter
      let submitEl = document.querySelector('input[type="submit"][value*="log in" i], input[type="submit"][value*="sign in" i]');
      if (!submitEl) submitEl = document.querySelector('input[type="submit"]');

      let loginBtn = submitEl;
      if (!loginBtn) {
        loginBtn = Array.from(document.querySelectorAll('button, [role="button"]')).find(function(b) {
          const t = (b.textContent || '').toLowerCase();
          return /log\s*in|sign\s*in|connexion|se\s*connecter/.test(t);
        }) || null;
      }

      // Planifier un rechargement unique 5s après le lancement de l'auto-login (quelque soit la page)
      try {
        sessionStorage.setItem('HIGGSFIELD_RELOAD_DEADLINE_MS', String(Date.now() + 5000));
        // Ancienne méthode (reload sur home) conservée pour compatibilité, mais sera nettoyée par le reload deadline
        sessionStorage.setItem('HIGGSFIELD_RELOAD_NEEDED', '1');
        // Backup: déclencher localement après 5s même en navigation interne SPA
        var alreadyDone = sessionStorage.getItem('HIGGSFIELD_RELOAD_DONE') === '1';
        if (!alreadyDone) {
          setTimeout(function() {
            try {
              if (sessionStorage.getItem('HIGGSFIELD_RELOAD_DONE') === '1') return;
              sessionStorage.setItem('HIGGSFIELD_RELOAD_DONE', '1');
              sessionStorage.removeItem('HIGGSFIELD_RELOAD_DEADLINE_MS');
              sessionStorage.removeItem('HIGGSFIELD_RELOAD_NEEDED');
            } catch (_) {}
            try { location.reload(); } catch (_) {}
          }, 5000);
        }
      } catch (_) {}

      if (loginBtn && isVisible(loginBtn) && !loginBtn.disabled && loginBtn.getAttribute('aria-disabled') !== 'true') {
        try { loginBtn.click(); } catch (_) {}
      } else {
        // Fallback: submit the form or press Enter
        const form = (pwdInput && pwdInput.form) || (emailInput && emailInput.form) || (loginBtn && loginBtn.closest && loginBtn.closest('form')) || null;
        if (form) {
          try { form.requestSubmit ? form.requestSubmit() : form.submit(); } catch (_) {}
        } else {
          const enterEvt = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true };
          pwdInput.dispatchEvent(new KeyboardEvent('keydown', enterEvt));
          pwdInput.dispatchEvent(new KeyboardEvent('keyup', enterEvt));
        }
      }
      // L'overlay sera retiré par le watcher lors de la redirection
    } catch (_) {
      // Silent fail on page mismatch or missing elements
      // En cas d'erreur, laisser l'overlay (cache toujours l'écran)
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run);
  } else {
    run();
  }

  // Handle SPA re-renders
  const observer = new MutationObserver(function() {
    run();
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });
})();


