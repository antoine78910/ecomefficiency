// contentScript.js

// Redirection automatique si sur la page manage-subscription
if (window.location.href.startsWith('https://app.foreplay.co/manage-subscription')) {
    window.location.href = 'https://app.foreplay.co/';
}

(function() {
    'use strict';

    // === Configuration ===

    /**
     * Le label à rechercher dans la table pour identifier la ligne correcte.
     */
    const TARGET_LABEL = 'ElevenLabs'; // Modifiez ce label si nécessaire

    /**
     * URL de la feuille Google Sheets - Format CSV pour récupération directe des données
     */
    const GOOGLE_SHEET_CSV_URL = 'https://docs.google.com/spreadsheets/d/e/2PACX-1vRFtg1rXIe3_TFgDUA6Rj8ARgFBgDPEWfGSH1py5pDzVrlVWXEP9WxwUTjnUJCVCGSd1nRfDWV49Bdm/pub?output=csv';
    
    /**
     * URL de la feuille Google Sheets - Format HTML pour récupération alternative
     */
    const GOOGLE_SHEET_HTML_URL = 'https://docs.google.com/spreadsheets/d/e/2PACX-1vRFtg1rXIe3_TFgDUA6Rj8ARgFBgDPEWfGSH1py5pDzVrlVWXEP9WxwUTjnUJCVCGSd1nRfDWV49Bdm/pubhtml';

       

    // === Fonctions pour la barre de chargement ===

    function showLoadingBar() {
        // Vérifier si la barre de chargement existe déjà
        if (document.getElementById('login-overlay')) {
            return;
        }

        // Créer la superposition
        const overlay = document.createElement('div');
        overlay.id = 'login-overlay';
        Object.assign(overlay.style, {
            position: 'fixed',
            top: '0',
            left: '0',
            width: '100%',
            height: '100%',
            backgroundColor: 'rgba(0, 0, 0, 1)', // Arrière-plan noir
            zIndex: '2147483647', // Z-index très élevé pour être au-dessus de tout
            display: 'flex',
            flexDirection: 'column', // Pour empiler les éléments verticalement
            justifyContent: 'center',
            alignItems: 'center',
            pointerEvents: 'none', // Permettre les interactions à travers sauf pour les éléments enfants
        });

        // Créer le conteneur de la barre de progression
        const progressContainer = document.createElement('div');
        Object.assign(progressContainer.style, {
            width: '80%',
            maxWidth: '600px',
            backgroundColor: '#e5e7eb',
            borderRadius: '10px',
            height: '30px',
            overflow: 'hidden',
            position: 'relative',
            transition: 'opacity 2s ease-in-out', // Pour l'animation de disparition
            pointerEvents: 'auto', // Activer les interactions à l'intérieur du conteneur de progression
        });

        // Créer la barre de progression
        const progressBar = document.createElement('div');
        progressBar.id = 'progress-bar';
        Object.assign(progressBar.style, {
            width: '0%',
            height: '100%',
            backgroundColor: '#3b82f6',
            borderRadius: '10px',
            transition: 'width 1s ease-in-out',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            color: '#fff',
            fontWeight: 'bold',
            fontSize: '16px',
        });

        // Créer l'étiquette de pourcentage
        const percentageLabel = document.createElement('span');
        percentageLabel.id = 'percentage-label';
        percentageLabel.innerText = '0%';

        progressBar.appendChild(percentageLabel);

        // Créer le texte en dessous de la barre de progression
        const textBelow = document.createElement('div');
        textBelow.innerText = 'Ecom Efficiency';
        Object.assign(textBelow.style, {
            marginTop: '20px',
            color: '#fff',
            fontSize: '24px',
            fontWeight: 'bold',
            pointerEvents: 'none',
        });

        // Créer le conteneur de la coche de validation (initialement caché)
        const checkmarkContainer = document.createElement('div');
        checkmarkContainer.id = 'checkmark-container';
        Object.assign(checkmarkContainer.style, {
            display: 'none',
            opacity: '0',
            transition: 'opacity 2s ease-in-out',
            marginTop: '20px',
            pointerEvents: 'none',
        });

        // Créer la coche de validation (SVG)
        const svgNS = "http://www.w3.org/2000/svg";
        const checkmarkSVG = document.createElementNS(svgNS, "svg");
        checkmarkSVG.setAttribute("width", "100");
        checkmarkSVG.setAttribute("height", "100");
        checkmarkSVG.setAttribute("viewBox", "0 0 52 52");

        const circle = document.createElementNS(svgNS, "circle");
        circle.setAttribute("cx", "26");
        circle.setAttribute("cy", "26");
        circle.setAttribute("r", "25");
        circle.setAttribute("fill", "none");
        circle.setAttribute("stroke", "#fff");
        circle.setAttribute("stroke-width", "2");
        checkmarkSVG.appendChild(circle);

        const checkmark = document.createElementNS(svgNS, "path");
        checkmark.setAttribute("fill", "none");
        checkmark.setAttribute("stroke", "#fff");
        checkmark.setAttribute("stroke-width", "5");
        checkmark.setAttribute("d", "M14 27 l7 7 l16 -16");
        checkmark.setAttribute("stroke-linecap", "round");
        checkmark.setAttribute("stroke-linejoin", "round");
        checkmark.style.strokeDasharray = "48";
        checkmark.style.strokeDashoffset = "48";
        checkmark.style.transition = "stroke-dashoffset 2s ease-in-out";
        checkmarkSVG.appendChild(checkmark);

        checkmarkContainer.appendChild(checkmarkSVG);

        // Ajouter les éléments à la superposition
        progressContainer.appendChild(progressBar);
        overlay.appendChild(progressContainer);
        overlay.appendChild(textBelow);
        overlay.appendChild(checkmarkContainer);
        document.body.appendChild(overlay);
    }

    function updateLoadingBar(percent) {
        const progressBar = document.getElementById('progress-bar');
        const percentageLabel = document.getElementById('percentage-label');
        if (progressBar && percentageLabel) {
            progressBar.style.width = percent + '%';

            // Animer l'augmentation du pourcentage
            let currentPercent = parseInt(percentageLabel.innerText.replace('%', '')) || 0;
            const targetPercent = percent;
            const increment = targetPercent > currentPercent ? 1 : -1;

            // Effacer tout intervalle existant pour éviter les chevauchements d'animations
            clearInterval(progressBar.interval);

            progressBar.interval = setInterval(() => {
                currentPercent += increment;
                percentageLabel.innerText = currentPercent + '%';
                if ((increment > 0 && currentPercent >= targetPercent) ||
                    (increment < 0 && currentPercent <= targetPercent)) {
                    clearInterval(progressBar.interval);
                }
            }, 20);
        }
    }

    function startFinalAnimation() {
        const progressBar = document.getElementById('progress-bar');
        const progressContainer = progressBar.parentElement;
        const checkmarkContainer = document.getElementById('checkmark-container');
        const checkmark = checkmarkContainer.querySelector('path');

        if (progressBar && checkmarkContainer && checkmark) {
            // Faire disparaître la barre de progression
            progressContainer.style.opacity = '0';
            progressContainer.style.transition = 'opacity 2s ease-in-out';

            // Après 2 secondes, masquer complètement la barre de progression
            setTimeout(() => {
                progressContainer.style.display = 'none';
            }, 2000);

            // Faire apparaître la coche de validation
            checkmarkContainer.style.display = 'block';
            setTimeout(() => {
                checkmarkContainer.style.opacity = '1';

                // Animer le tracé de la coche
                checkmark.style.strokeDashoffset = '0';
            }, 100); // Légère attente pour démarrer l'animation
        }
    }

    function hideLoadingBar() {
        const overlay = document.getElementById('login-overlay');
        if (overlay) {
            overlay.remove();
        }
    }

    // === Fonctions Utilitaires ===

    /**
     * Simule la saisie dans un champ de saisie avec un délai similaire à celui d'un humain.
     * @param {HTMLElement} field - Le champ de saisie dans lequel taper.
     * @param {string} text - Le texte à taper.
     * @param {Function} callback - La fonction à exécuter après la saisie.
     */
    function typeInFieldWithKeyboard(field, text, callback) {
        console.log(`🎯 Saisie dans champ ${field.type || 'text'}: "${text}"`);
        
        // Effacer le champ d'abord
        field.focus();
        field.value = '';
        
        // Attendre un petit moment pour s'assurer que le focus est bien pris
        setTimeout(() => {
            // Saisir le texte
            field.value = text;
            
            // Déclencher tous les événements nécessaires
            field.dispatchEvent(new Event('focus', { bubbles: true }));
            field.dispatchEvent(new Event('input', { bubbles: true }));
            field.dispatchEvent(new Event('change', { bubbles: true }));
            
            // Pour les champs password, essayer aussi des événements clavier
            if (field.type === 'password') {
                field.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true }));
                field.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));
            }
            
            // Vérifier que la valeur a bien été définie
            if (field.value !== text) {
                console.warn(`⚠️ Valeur incorrecte après saisie. Attendu: "${text}", Obtenu: "${field.value}"`);
                // Tentative de force brute
                field.value = text;
            }
            
            field.dispatchEvent(new Event('blur', { bubbles: true }));
            
            console.log(`✅ Saisie terminée. Valeur finale: "${field.value}"`);
            
            if (callback) {
                setTimeout(callback, 300);
            }
        }, 50);
    }

    /**
     * Fonction pour attendre la présence d'un élément dans le DOM
     * @param {string} selector - Le sélecteur CSS de l'élément à attendre
     * @param {number} timeout - Le délai maximal d'attente en millisecondes
     * @returns {Promise<HTMLElement>} - L'élément trouvé
     */
    function waitForElement(selector, timeout = 10000) {
        return new Promise((resolve, reject) => {
            const element = document.querySelector(selector);
            if (element) {
                return resolve(element);
            }

            const observer = new MutationObserver((mutations, me) => {
                const el = document.querySelector(selector);
                if (el) {
                    resolve(el);
                    me.disconnect();
                }
            });

            observer.observe(document.body, {
                childList: true,
                subtree: true
            });

            setTimeout(() => {
                observer.disconnect();
            }, timeout);
        });
    }

    /**
     * Fonction pour vérifier si un élément contient un texte spécifique
     * @param {HTMLElement} element - L'élément à vérifier
     * @param {string} text - Le texte à rechercher
     * @returns {boolean} - Vrai si le texte est présent, sinon faux
     */
    function elementContainsText(element, text) {
        return element.textContent.trim().includes(text);
    }

    /**
     * Fonction pour attendre la présence d'un élément avec un texte spécifique dans le DOM
     * @param {string} selector - Le sélecteur CSS de l'élément à attendre
     * @param {string} text - Le texte spécifique à rechercher dans l'élément
     * @param {number} timeout - Le délai maximal d'attente en millisecondes
     * @returns {Promise<HTMLElement>} - L'élément trouvé
     */
    function waitForElementWithText(selector, text, timeout = 10000) {
        return new Promise((resolve, reject) => {
            const elements = document.querySelectorAll(selector);
            for (let el of elements) {
                if (elementContainsText(el, text)) {
                    return resolve(el);
                }
            }

            const observer = new MutationObserver((mutations, me) => {
                const elems = document.querySelectorAll(selector);
                for (let el of elems) {
                    if (elementContainsText(el, text)) {
                        resolve(el);
                        me.disconnect();
                        break;
                    }
                }
            });

            observer.observe(document.body, {
                childList: true,
                subtree: true
            });

            setTimeout(() => {
                observer.disconnect();
            }, timeout);
        });
    }

    /**
     * Fonction pour attendre qu'un bouton soit activé (pas désactivé)
     * @param {string} selector - Le sélecteur CSS du bouton à attendre
     * @param {number} timeout - Le délai maximal d'attente en millisecondes
     * @returns {Promise<HTMLElement>} - L'élément trouvé et activé
     */
    function waitForEnabledButton(selector, timeout = 10000) {
        return new Promise((resolve, reject) => {
            const checkButton = () => {
                const button = document.querySelector(selector);
                if (button && !button.disabled) {
                    return resolve(button);
                }
            };

            // Vérifier immédiatement
            checkButton();

            const observer = new MutationObserver((mutations, me) => {
                checkButton();
            });

            observer.observe(document.body, {
                childList: true,
                subtree: true,
                attributes: true,
                attributeFilter: ['disabled']
            });

            setTimeout(() => {
                observer.disconnect();
                reject(new Error(`Timeout: Le bouton (${selector}) n'a pas été activé dans le délai imparti.`));
            }, timeout);
        });
    }

    // === Extraction des Identifiants depuis la Feuille Google Sheets ===

    /**
     * Fonction pour parser les données CSV et extraire les identifiants ElevenLabs
     * @param {string} csvData - Données CSV brutes
     * @returns {Promise<{email: string, password: string}>} Les identifiants récupérés
     */
    async function parseCSVData(csvData) {
        console.log('📊 === PARSING DONNÉES CSV ===');
        
        // Diviser en lignes et afficher un aperçu
        const lines = csvData.split('\n').filter(line => line.trim() !== '');
        console.log(`📈 ${lines.length} lignes trouvées dans le CSV`);
        
        // Afficher les premières lignes pour debugging
        console.log('🔍 Aperçu des premières lignes:');
        for (let i = 0; i < Math.min(lines.length, 10); i++) {
            console.log(`  Ligne ${i + 1}: "${lines[i]}"`);
        }
        
        // MÉTHODE 1: Chercher ligne 8 (index 7) directement - Correspondant à l'ID "0R7"
        console.log('🎯 === MÉTHODE 1: LIGNE 8 DIRECTE ===');
        if (lines.length > 7) {
            const targetLine = lines[7]; // Ligne 8 (index 7)
            console.log(`📍 Ligne 8 brute: "${targetLine}"`);
            
            // Parser la ligne CSV
            const columns = parseCSVLine(targetLine);
            console.log(`📋 ${columns.length} colonnes parsées:`, columns.map((col, idx) => `[${idx}]="${col}"`));
            
            if (columns.length >= 3) {
                const email = columns[1]?.trim() || ''; // 2ème colonne
                const password = columns[2]?.trim() || ''; // 3ème colonne
                
                console.log(`✅ Ligne 8 - Email: "${email}"`);
                console.log(`✅ Ligne 8 - Password: "${password}"`);
                
                if (email && password && email.includes('@')) {
                    console.log('🎯 MÉTHODE 1 RÉUSSIE - Identifiants trouvés ligne 8');
                    return { email, password };
                } else {
                    console.warn('⚠️ Ligne 8 trouvée mais email/password invalides');
                }
            } else {
                console.warn(`⚠️ Ligne 8 trouvée mais seulement ${columns.length} colonnes`);
            }
        } else {
            console.warn(`⚠️ CSV contient seulement ${lines.length} lignes, ligne 8 inexistante`);
        }
        
        // MÉTHODE 2: Chercher "ElevenLabs" dans toutes les lignes
        console.log('🎯 === MÉTHODE 2: RECHERCHE "ELEVENLABS" ===');
        for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            
            if (line.toLowerCase().includes('elevenlabs')) {
                console.log(`✅ "ElevenLabs" trouvé ligne ${i + 1}: "${line}"`);
                
                const columns = parseCSVLine(line);
                console.log(`📋 ${columns.length} colonnes parsées:`, columns.map((col, idx) => `[${idx}]="${col}"`));
                
                if (columns.length >= 3) {
                    const email = columns[1]?.trim() || ''; // 2ème colonne
                    const password = columns[2]?.trim() || ''; // 3ème colonne
                    
                    console.log(`✅ ElevenLabs ligne - Email: "${email}"`);
                    console.log(`✅ ElevenLabs ligne - Password: "${password}"`);
                    
                    if (email && password && email.includes('@')) {
                        console.log('🎯 MÉTHODE 2 RÉUSSIE - Identifiants trouvés par recherche "ElevenLabs"');
                        return { email, password };
                    } else {
                        console.warn('⚠️ Ligne ElevenLabs trouvée mais email/password invalides');
                    }
                } else {
                    console.warn(`⚠️ Ligne ElevenLabs trouvée mais seulement ${columns.length} colonnes`);
                }
            }
        }
        
        console.log('❌ === ÉCHEC DES DEUX MÉTHODES ===');
        console.log('💡 Debug: Voici toutes les lignes pour inspection manuelle:');
        lines.forEach((line, idx) => {
            console.log(`  [${idx + 1}] "${line}"`);
        });
        
        throw new Error('❌ Identifiants ElevenLabs non trouvés dans les données CSV. Vérifiez le contenu ci-dessus.');
    }
    
    /**
     * Fonction pour parser une ligne CSV (gère les guillemets et virgules)
     * @param {string} line - Ligne CSV à parser
     * @returns {Array<string>} - Colonnes extraites
     */
    function parseCSVLine(line) {
        const columns = [];
        let current = '';
        let inQuotes = false;
        
        for (let i = 0; i < line.length; i++) {
            const char = line[i];
            
            if (char === '"') {
                inQuotes = !inQuotes;
            } else if (char === ',' && !inQuotes) {
                columns.push(current);
                current = '';
            } else {
                current += char;
            }
        }
        
        // Ajouter la dernière colonne
        columns.push(current);
        
        // Nettoyer les guillemets
        return columns.map(col => col.replace(/^"(.*)"$/, '$1').trim());
    }

    /**
     * Fonction pour traiter directement les lignes TR sans passer par une table
     * @param {NodeList} rows - Les lignes TR trouvées
     * @returns {Promise<{email: string, password: string}>} Les identifiants récupérés
     */
    async function processRowsDirectly(rows) {
        console.log(`Traitement direct de ${rows.length} lignes`);
        
        // MÉTHODE 1: Chercher par ID spécifique "0R7"
        console.log('🔍 Méthode 1: Recherche par ID "0R7"...');
        for (let i = 0; i < rows.length; i++) {
            const row = rows[i];
            
            // Chercher un TH avec l'ID "0R7"
            const targetHeader = row.querySelector('th[id="0R7"]');
            if (targetHeader) {
                console.log('✅ Ligne avec ID "0R7" trouvée !');
                
                // Récupérer toutes les cellules de cette ligne
                const allCells = row.querySelectorAll('td, th');
                console.log(`Ligne ID "0R7": ${allCells.length} cellules trouvées`);
                
                // Afficher le contenu pour debugging
                let cellContents = [];
                for (let j = 0; j < Math.min(allCells.length, 5); j++) {
                    cellContents.push(`"${allCells[j].textContent.trim().substring(0, 30)}"`);
                }
                console.log(`  Contenu des cellules ID "0R7": [${cellContents.join(', ')}]`);
                
                if (allCells.length >= 3) {
                    // Prendre la 2ème colonne (index 1) pour l'email et 3ème colonne (index 2) pour le password
                    let email = '';
                    let password = '';
                    
                    // Email - 2ème colonne (index 1)
                    const emailCell = allCells[1];
                    const emailInnerDiv = emailCell.querySelector('.softmerge-inner');
                    if (emailInnerDiv) {
                        email = emailInnerDiv.textContent.trim();
                    } else {
                        email = emailCell.textContent.trim();
                    }
                    
                    // Password - 3ème colonne (index 2)
                    const passwordCell = allCells[2];
                    const passwordInnerDiv = passwordCell.querySelector('.softmerge-inner');
                    if (passwordInnerDiv) {
                        password = passwordInnerDiv.textContent.trim();
                    } else {
                        password = passwordCell.textContent.trim();
                    }
                    
                    console.log(`✅ ID "0R7" - Email extrait: "${email}"`);
                    console.log(`✅ ID "0R7" - Password extrait: "${password}"`);
                    
                    if (email && password) {
                        console.log('🎯 Méthode 1 réussie - Identifiants trouvés par ID "0R7"');
                        return { email, password };
                    }
                }
            }
        }
        
        console.log('❌ Méthode 1 échouée - ID "0R7" non trouvé');
        
        // MÉTHODE 2: Chercher "ElevenLabs" dans le contenu des cellules
        console.log('🔍 Méthode 2: Recherche par contenu "ElevenLabs"...');
        for (let i = 0; i < rows.length; i++) {
            const row = rows[i];
            
            // Récupérer toutes les cellules de la ligne
            const allCells = row.querySelectorAll('td, th');
            
            if (allCells.length >= 3) {
                // Parcourir toutes les cellules pour chercher "ElevenLabs"
                for (let cellIndex = 0; cellIndex < allCells.length; cellIndex++) {
                    const cellText = allCells[cellIndex].textContent.trim();
                    
                    if (cellText.toLowerCase().includes('elevenlabs')) {
                        console.log(`✅ "ElevenLabs" trouvé dans ligne ${i}, cellule ${cellIndex}: "${cellText}"`);
                        
                        // Prendre la 2ème et 3ème colonne de cette ligne (index 1 et 2)
                        if (allCells.length >= 3) {
                            let email = '';
                            let password = '';
                            
                            // Email - 2ème colonne (index 1)
                            const emailCell = allCells[1];
                            const emailInnerDiv = emailCell.querySelector('.softmerge-inner');
                            if (emailInnerDiv) {
                                email = emailInnerDiv.textContent.trim();
                            } else {
                                email = emailCell.textContent.trim();
                            }
                            
                            // Password - 3ème colonne (index 2)
                            const passwordCell = allCells[2];
                            const passwordInnerDiv = passwordCell.querySelector('.softmerge-inner');
                            if (passwordInnerDiv) {
                                password = passwordInnerDiv.textContent.trim();
                            } else {
                                password = passwordCell.textContent.trim();
                            }
                            
                            console.log(`✅ ElevenLabs ligne - Email extrait: "${email}"`);
                            console.log(`✅ ElevenLabs ligne - Password extrait: "${password}"`);
                            
                            if (email && password) {
                                console.log('🎯 Méthode 2 réussie - Identifiants trouvés par recherche "ElevenLabs"');
                                return { email, password };
                            } else {
                                console.warn('⚠️ Email ou mot de passe vide dans la ligne ElevenLabs, continuons la recherche...');
                            }
                        }
                    }
                }
            }
        }
        
        console.log('❌ Méthode 2 échouée - "ElevenLabs" non trouvé');
        throw new Error('Identifiants non trouvés avec les méthodes ID "0R7" et recherche "ElevenLabs"');
    }

    /**
     * Fonction pour récupérer les identifiants depuis la feuille Google Sheets
     * @returns {Promise<{email: string, password: string}>} Les identifiants récupérés
     */
    async function fetchCredentialsFromGoogleSheets() {
        // MÉTHODE 1: Récupération CSV (priorité haute)
        console.log('🚀 === RÉCUPÉRATION IDENTIFIANTS GOOGLE SHEETS ===');
        console.log('🔍 Méthode 1: Récupération format CSV...');
        
        try {
            console.log(`📡 Tentative CSV: ${GOOGLE_SHEET_CSV_URL}`);
            const csvResponse = await fetch(GOOGLE_SHEET_CSV_URL);
            
            if (csvResponse.ok) {
                const csvData = await csvResponse.text();
                console.log(`📊 CSV récupéré (${csvData.length} caractères)`);
                console.log('🔍 Début du CSV:', csvData.substring(0, 300));
                
                // Vérifier que c'est bien du CSV et pas une page d'erreur
                if (!csvData.includes('<!DOCTYPE html>') && csvData.includes(',')) {
                    return await parseCSVData(csvData);
                } else {
                    console.warn('⚠️ CSV semble être une page HTML, pas du CSV brut');
                }
            } else {
                console.warn(`❌ CSV échoué: ${csvResponse.status} ${csvResponse.statusText}`);
            }
        } catch (error) {
            console.warn(`❌ Erreur CSV: ${error.message}`);
        }
        
        // MÉTHODE 2: Récupération HTML (fallback)
        console.log('🔍 Méthode 2: Récupération format HTML...');
        
        const htmlUrlsToTry = [
            GOOGLE_SHEET_HTML_URL,
            GOOGLE_SHEET_HTML_URL + '?gid=0',
            GOOGLE_SHEET_HTML_URL.replace('/pubhtml', '/pub?output=html'),
            GOOGLE_SHEET_HTML_URL.replace('/pubhtml', '/pub?gid=0&single=true&output=html')
        ];

        for (let i = 0; i < htmlUrlsToTry.length; i++) {
            const url = htmlUrlsToTry[i];
            try {
                console.log(`📡 Tentative HTML ${i + 1}/${htmlUrlsToTry.length}: ${url}`);
                const response = await fetch(url);
                
                if (!response.ok) {
                    console.warn(`❌ HTML ${i + 1} échoué: ${response.statusText}`);
                    continue;
                }
                
                const htmlData = await response.text();
                console.log(`📄 HTML récupéré (${htmlData.length} caractères)`);
                
                // Vérifier si c'est une page Google Drive au lieu d'une feuille de calcul
                if (htmlData.includes('Google Drive') && htmlData.includes('- Google Drive</title>')) {
                    console.warn(`❌ HTML ${i + 1} retourne Google Drive, pas la feuille`);
                    continue;
                }

                // Parser le HTML
                const parser = new DOMParser();
                const doc = parser.parseFromString(htmlData, 'text/html');
                const allRows = doc.querySelectorAll('tr');
                
                console.log(`📋 HTML ${i + 1} - ${allRows.length} lignes TR trouvées`);
                
                if (allRows.length > 0) {
                    return await processRowsDirectly(allRows);
                }
                
            } catch (error) {
                console.warn(`❌ Erreur HTML ${i + 1}: ${error.message}`);
            }
        }
        
        // Si tout échoue, erreur fatale
        throw new Error('❌ ÉCHEC TOTAL: Impossible de récupérer les identifiants depuis Google Sheets. Vérifiez que la feuille est bien publiée publiquement.');
    }

    // === Fonction Principale d'Auto-Connexion ===

    /**
     * Fonction principale d'auto-login
     */
    async function autoLogin() {
        try {
            console.log("Début de l'auto-login.");
            showLoadingBar();
            updateLoadingBar(10);

            // Récupérer les identifiants depuis Google Sheets (CSV/HTML)
            const credentials = await fetchCredentialsFromGoogleSheets();
            console.log("📊 GOOGLE SHEETS - Identifiants récupérés avec succès :", { 
                email: credentials.email, 
                password: '****' + credentials.password.slice(-2) 
            });

            updateLoadingBar(30);
// Ajout : Si la barre reste bloquée à 30%, on la retire après 5s
setTimeout(() => {
    const progressBar = document.getElementById('progress-bar');
    const percentageLabel = document.getElementById('percentage-label');
    if (progressBar && percentageLabel && percentageLabel.innerText.trim() === '30%') {
        hideLoadingBar();
        console.warn('Loading bar retirée automatiquement après 5s à 30%.');
    }
}, 5000);

            // 1. Attendre le champ d'e-mail
            const emailInput = await waitForElement('input[data-testid="sign-in-email-input"], input[name="email"], input[type="email"]');
            console.log("Champ d'e-mail trouvé.");
            updateLoadingBar(40);

            // 2. Remplir le champ d'e-mail
            console.log(`🔤 Tentative de saisie de l'email : "${credentials.email}"`);
            await new Promise((resolve) => {
                typeInFieldWithKeyboard(emailInput, credentials.email, resolve);
            });
            console.log(`✅ E-mail rempli. Valeur actuelle : "${emailInput.value}"`);
            updateLoadingBar(60);

            // 3. Attendre le champ de mot de passe
            const passwordInput = await waitForElement('input[data-testid="sign-in-password-input"], input[name="password"], input[type="password"]');
            console.log("Champ de mot de passe trouvé.");
            updateLoadingBar(70);

            // 4. Remplir le champ de mot de passe
            console.log(`🔐 Tentative de saisie du password : "${credentials.password}"`);
            await new Promise((resolve) => {
                typeInFieldWithKeyboard(passwordInput, credentials.password, resolve);
            });
            console.log(`✅ Mot de passe rempli. Valeur actuelle : "${passwordInput.value}"`);
            
            // Vérification supplémentaire du mot de passe
            if (!passwordInput.value || passwordInput.value !== credentials.password) {
                console.warn(`⚠️ Problème avec le champ password. Tentative de re-saisie...`);
                passwordInput.focus();
                passwordInput.value = credentials.password;
                passwordInput.dispatchEvent(new Event('input', { bubbles: true }));
                passwordInput.dispatchEvent(new Event('change', { bubbles: true }));
                console.log(`🔄 Re-saisie password. Nouvelle valeur : "${passwordInput.value}"`);
            }
            updateLoadingBar(90);

            // 5. Attendre que le bouton de connexion soit activé et cliquer dessus
            const loginButton = await waitForEnabledButton('button[data-testid="sign-in-submit-button"], button[type="submit"], input[type="submit"]');
            console.log("Bouton de connexion trouvé et activé.");

            // Assurer le focus sur le bouton (optionnel)
            loginButton.focus();

            // Cliquer sur le bouton de connexion
            loginButton.click();
            console.log("Bouton de connexion cliqué.");
            updateLoadingBar(100);

            // Finaliser la barre de chargement
            setTimeout(() => {
                startFinalAnimation();
                setTimeout(() => {
                    hideLoadingBar();
                }, 2500); // Attendre que l'animation de la coche se termine
            }, 1000); // Attendre un court instant après le clic sur le bouton de connexion

        } catch (error) {
            console.error("Auto-connexion échouée:", error.message);
            hideLoadingBar();
        }
    }

    // === Initialisation du Script ===

    /**
     * Initialise le script en affichant la barre de chargement et en démarrant le processus d'auto-connexion.
     */
    async function initialize() {
        // Nouvelle condition : si nous sommes sur la page /fr/login d'ElevenLabs, cliquer sur le lien "Se connecter"
        if (window.location.href.startsWith('https://elevenlabs.io/fr/login')) {
            try {
                const signInLink = await waitForElement('a[href="/app/sign-in"]');
                if (signInLink) {
                    console.log('Lien "Se connecter" trouvé, clic automatique.');
                    signInLink.click();
                    return; // On stoppe l'exécution, le script sera rechargé après la redirection
                }
            } catch (e) {
                console.warn('Lien "Se connecter" introuvable :', e);
            }
        }

        showLoadingBar();
        try {
            await autoLogin();
        } catch (error) {
            console.error("Erreur lors de l'initialisation:", error);
            hideLoadingBar();
        }
    }

    // Exécuter l'initialisation immédiatement
    initialize();

})();