(function() {
    'use strict';

    console.log('[HEYGEN] Loading spinner script started on:', window.location.href);

    // Fonction pour créer l'écran de chargement simple avec spinner
    function showLoadingSpinner() {
        if (document.getElementById('heygen-loading-overlay')) return;

        const overlay = document.createElement('div');
        overlay.id = 'heygen-loading-overlay';
        Object.assign(overlay.style, {
            position: 'fixed',
            top: '0',
            left: '0',
            width: '100vw',
            height: '100vh',
            background: 'linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%)',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center',
            alignItems: 'center',
            zIndex: '2147483647',
            fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
        });

        // Logo/Brand
        const logo = document.createElement('div');
        logo.textContent = 'ECOM EFFICIENCY';
        Object.assign(logo.style, {
            color: '#8b45c4',
            fontSize: '2.5em',
            fontWeight: '900',
            letterSpacing: '3px',
            marginBottom: '40px',
            textShadow: '0 0 20px rgba(139, 69, 196, 0.3)'
        });
        overlay.appendChild(logo);

        // Spinner simple
        const spinner = document.createElement('div');
        Object.assign(spinner.style, {
            width: '50px',
            height: '50px',
            border: '4px solid rgba(139, 69, 196, 0.2)',
            borderTop: '4px solid #8b45c4',
            borderRadius: '50%',
            animation: 'heygen-spin 1s linear infinite'
        });

        // Ajouter le spinner et animer via JS (évite l'inline CSS bloqué par CSP)
        overlay.appendChild(spinner);

        // Animation par rotation via requestAnimationFrame (pas de <style> inline)
        let __heygenSpinnerAngle = 0;
        const __heygenAnimateSpinner = () => {
            __heygenSpinnerAngle = (__heygenSpinnerAngle + 6) % 360;
            spinner.style.transform = `rotate(${__heygenSpinnerAngle}deg)`;
            requestAnimationFrame(__heygenAnimateSpinner);
        };
        requestAnimationFrame(__heygenAnimateSpinner);
        document.body.appendChild(overlay);
        console.log('[HEYGEN] ✅ Loading spinner displayed');
    }

    // Fonction pour terminer l'auto-login (garde juste le spinner)
    function completeAutoLogin() {
        // Juste garder le spinner qui tourne, pas d'action particulière
        console.log('[HEYGEN] ✅ Auto-login completed, keeping spinner visible until page change');
    }

    // Fonction pour surveiller les changements d'URL
    function monitorUrlChange() {
        let currentUrl = window.location.href;
        
        const checkUrl = setInterval(() => {
            if (window.location.href !== currentUrl) {
                console.log('[HEYGEN] URL changed from', currentUrl, 'to', window.location.href);
                
                // Si on quitte la page de login, masquer le spinner
                if (!window.location.href.includes('/login')) {
                    console.log('[HEYGEN] Left login page, hiding spinner');
                    clearInterval(checkUrl);
                    hideLoadingSpinner();
                }
                
                currentUrl = window.location.href;
            }
        }, 500);
        
        return checkUrl;
    }

    // Fonction pour masquer l'écran de chargement
    function hideLoadingSpinner() {
        const overlay = document.getElementById('heygen-loading-overlay');
        if (overlay) {
            overlay.style.opacity = '0';
            overlay.style.transition = 'opacity 0.5s ease';
            setTimeout(() => {
                overlay.remove();
                console.log('[HEYGEN] ✅ Loading spinner hidden');
            }, 500);
        }
    }

    // Fonction utilitaire pour attendre un élément
    function waitForElement(selector, timeout = 10000) {
        return new Promise((resolve, reject) => {
            const element = document.querySelector(selector);
            if (element) return resolve(element);

            const observer = new MutationObserver(() => {
                const found = document.querySelector(selector);
                if (found) {
                    observer.disconnect();
                    resolve(found);
                }
            });

            observer.observe(document.body, {
                childList: true,
                subtree: true
            });

            setTimeout(() => {
                observer.disconnect();
                reject(new Error(`Element "${selector}" not found after ${timeout}ms`));
            }, timeout);
        });
    }

    // Fonction pour saisie rapide (copier-coller)
    function fastFillField(field, text) {
        field.focus();
        field.value = text;
        
        // Déclencher les événements nécessaires
        field.dispatchEvent(new Event('input', { bubbles: true }));
        field.dispatchEvent(new Event('change', { bubbles: true }));
        field.dispatchEvent(new Event('blur', { bubbles: true }));
        
        return Promise.resolve();
    }

    // Fonction principale d'auto-login
    async function performAutoLogin() {
        try {
            console.log('[HEYGEN] Starting auto-login process...');

            // 1) Étape Email -> bouton Continue
            console.log('[HEYGEN] Waiting for email field...');
            const emailInput = await waitForElement('input[type="email"], #email', 15000);
            console.log('[HEYGEN] ✅ Email field found');

            console.log('[HEYGEN] Filling email field...');
            await fastFillField(emailInput, 'ecom.efficiency1@gmail.com');
            console.log('[HEYGEN] ✅ Email filled:', emailInput.value);

            // Petite pause pour laisser la validation s'appliquer
            await new Promise(resolve => setTimeout(resolve, 200));

            // Trouver et cliquer sur le bouton "Continue" / "Continuar"
            const getElementLabel = (el) => {
                if (!el) return '';
                if (el.tagName === 'INPUT') return (el.value || '').trim();
                const aria = el.getAttribute('aria-label') || '';
                const title = el.getAttribute('title') || '';
                const txt = (el.textContent || '').trim();
                return (aria || title || txt);
            };

            const tryEnterOn = async (el) => {
                try {
                    el.focus();
                    const enterEventInit = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true };
                    el.dispatchEvent(new KeyboardEvent('keydown', enterEventInit));
                    el.dispatchEvent(new KeyboardEvent('keyup', enterEventInit));
                    await new Promise(r => setTimeout(r, 400));
                } catch {}
            };

            let continueButton = Array.from(document.querySelectorAll('button, [role="button"]')).find((el) => {
                const label = getElementLabel(el).toLowerCase();
                return label.includes('continue') || label.includes('continuar');
            }) || null;

            if (continueButton) {
                if (continueButton.disabled) {
                    console.log('[HEYGEN] Continue button disabled, waiting to enable...');
                    let attempts = 0;
                    while (continueButton.disabled && attempts < 25) {
                        await new Promise(resolve => setTimeout(resolve, 200));
                        attempts++;
                    }
                }
                if (!continueButton.disabled) {
                    console.log('[HEYGEN] Clicking Continue button...');
                    continueButton.click();
                } else {
                    console.log('[HEYGEN] Continue still disabled, trying Enter on email');
                    await tryEnterOn(emailInput);
                }
            } else {
                console.log('[HEYGEN] Continue button not found, trying Enter on email');
                await tryEnterOn(emailInput);
            }

            // 2) Étape Mot de passe -> bouton Log in
            console.log('[HEYGEN] Waiting for password field...');
            const passwordInput = await waitForElement('input[type="password"], #password', 15000);
            console.log('[HEYGEN] ✅ Password field found');

            console.log('[HEYGEN] Filling password field...');
            await fastFillField(passwordInput, 'C+N8(%5+3ScL.6S');
            console.log('[HEYGEN] ✅ Password filled (length:', passwordInput.value.length, ')');

            await new Promise(resolve => setTimeout(resolve, 300));

            // Trouver et cliquer sur le bouton "Log in"
            const targetForm = (passwordInput && passwordInput.closest('form')) || (emailInput && emailInput.closest('form')) || null;
            let loginButton = null;

            if (targetForm) {
                loginButton = targetForm.querySelector('button[type="submit"], input[type="submit"]');
            }
            if (!loginButton) {
                const candidates = Array.from(document.querySelectorAll('button, input[type="submit"], [role="button"]'));
                const keywords = ['log in', 'login', 'sign in', 'signin', 'se connecter', 'connexion', 'iniciar sesión', 'iniciar'];
                loginButton = candidates.find((el) => {
                    const label = getElementLabel(el).toLowerCase();
                    const isInSameForm = targetForm && el.closest('form') === targetForm;
                    return (isInSameForm && keywords.some(k => label.includes(k))) || keywords.some(k => label.includes(k));
                }) || null;
            }

            const tryFormSubmitFallback = async () => {
                if (!targetForm) return false;
                try {
                    if (typeof targetForm.requestSubmit === 'function') {
                        targetForm.requestSubmit();
                    } else {
                        const proceed = targetForm.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
                        if (proceed !== false) {
                            targetForm.submit();
                        }
                    }
                    console.log('[HEYGEN] ✅ Form submitted via fallback');
                    return true;
                } catch (e) {
                    console.warn('[HEYGEN] Form submit fallback failed:', e);
                    return false;
                }
            };

            let clicked = false;
            if (loginButton) {
                if (loginButton.disabled) {
                    console.log('[HEYGEN] Login button disabled, waiting to enable...');
                    let attempts = 0;
                    while (loginButton.disabled && attempts < 25) {
                        await new Promise(resolve => setTimeout(resolve, 200));
                        attempts++;
                    }
                }
                if (!loginButton.disabled) {
                    console.log('[HEYGEN] Clicking Login button...');
                    loginButton.click();
                    clicked = true;
                }
            }

            if (!clicked) {
                await tryEnterOn(passwordInput);
                const submitted = await tryFormSubmitFallback();
                if (!submitted && !clicked) {
                    throw new Error('Login control not found');
                }
            }

            // Auto-login terminé, garder juste le spinner
            completeAutoLogin();

            console.log('[HEYGEN] ✅ Auto-login process completed');

        } catch (error) {
            console.error('[HEYGEN] Auto-login failed:', error);
            
            // En cas d'erreur, garder juste le spinner qui tourne
            console.log('[HEYGEN] ❌ Auto-login failed, but keeping spinner visible until page change');
        }
    }

    // Fonction principale
    function initialize() {
        console.log('[HEYGEN] Initializing loading spinner and auto-login...');
        
        // Afficher le spinner immédiatement
        showLoadingSpinner();
        
        // Démarrer la surveillance des changements d'URL
        monitorUrlChange();
        
        // Démarrer l'auto-login après un court délai
        setTimeout(performAutoLogin, 1000);
    }

    // Démarrer dès que possible
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initialize);
    } else {
        // Si le DOM est déjà chargé
        initialize();
    }

})();