# 🚀 Quick Start Guide - 2FA Setup

## What Was Changed

### 1. ✅ Gemini Auto-Login (`auto_login_gemini_google.js`)
- ✅ Password field is now **grayed out** and **read-only** after filling
- ✅ Password visibility toggle button is **disabled**
- ✅ Added **2FA/TOTP support** - automatically handles Google 2-step verification
- ✅ Opens 2fa.live, generates code, and submits it automatically

### 2. ✅ New 2FA Server (`2fa_server.js`)
- ✅ Standalone TOTP code generator
- ✅ Can be deployed on any server (VPS, Heroku, Railway, etc.)
- ✅ REST API with GET and POST endpoints
- ✅ Web interface for testing

### 3. ✅ Helper Script (`2fa_live_helper.js`)
- ✅ Injected into 2fa.live pages
- ✅ Helps automate code extraction
- ✅ Better reliability for popup interactions

### 4. ✅ Configuration Files
- ✅ Updated `manifest.json` with 2fa.live permissions
- ✅ Updated `package.json` with speakeasy dependency
- ✅ Added script: `npm run 2fa-server`

## Installation Steps

### Step 1: Install Dependencies

```bash
npm install
```

This will install the new `speakeasy` package needed for TOTP generation.

### Step 2: Configure Your TOTP Secret

The TOTP secret is currently hardcoded in `auto_login_gemini_google.js`:

```javascript
const TOTP_SECRET = 't2v4 3lj5 ysb2 kh2y vidm gip2 4nty 3mu4';
```

**To change it:**
1. Open `auto_login_gemini_google.js`
2. Find line 7
3. Replace with your actual TOTP secret

### Step 3: Load Extension in Chrome

1. Open Chrome and go to `chrome://extensions/`
2. Enable "Developer mode" (top right)
3. Click "Load unpacked"
4. Select this project folder
5. The extension should now be loaded

### Step 4: (Optional) Run Standalone 2FA Server

If you want to use the standalone server for testing or other purposes:

```bash
npm run 2fa-server
```

Then open: `http://localhost:3000`

## How It Works

### Automatic Flow

1. **Visit Gemini**: Go to `https://gemini.google.com`
2. **Auto Sign-In**: Extension clicks "Sign in" button
3. **Select Account**: Extension selects your Google account
4. **Fill Password**: Extension types password character by character (1 second delay)
5. **Password Protected**: Password field becomes grayed out and read-only
6. **2FA Challenge**: When Google asks for 2-step verification:
   - Extension opens 2fa.live in new window
   - Fills in your TOTP secret
   - Waits for code generation
   - Extracts the 6-digit code
   - Enters it in Google's TOTP field
   - Submits and closes 2fa.live window
7. **Login Complete**: You're now logged in!

### Manual Testing

You can manually test the 2FA server:

**Web Interface:**
```
http://localhost:3000
```

**API Call:**
```bash
curl -X POST http://localhost:3000/generate \
  -H "Content-Type: application/json" \
  -d '{"secret":"t2v4 3lj5 ysb2 kh2y vidm gip2 4nty 3mu4"}'
```

## Troubleshooting

### Problem: Popup is blocked

**Solution:**
1. Go to Chrome Settings > Privacy and Security > Site Settings > Pop-ups and redirects
2. Add `https://accounts.google.com` to allowed sites

### Problem: Password is visible

**Solution:**
- The password field is styled after typing completes
- Wait for the "Password typing complete" log message
- The field should turn gray with a "not-allowed" cursor

### Problem: 2FA code not working

**Check:**
1. Your TOTP secret is correct
2. Your computer's time is synchronized (very important for TOTP!)
3. The code hasn't expired (they change every 30 seconds)

**To sync time on Windows:**
```powershell
w32tm /resync
```

### Problem: Extension not loading

**Check:**
1. All files are in the correct directory
2. `manifest.json` is valid (no syntax errors)
3. Try reloading the extension in `chrome://extensions/`

## Console Logs

The extension logs everything to the browser console. To see logs:

1. Press `F12` to open Developer Tools
2. Go to "Console" tab
3. Look for messages starting with:
   - `[GEMINI-GOOGLE-AUTOLOGIN]`
   - `[2FA-LIVE-HELPER]`

## Security Reminders

⚠️ **Important:**

1. Your TOTP secret is stored in plain text in the extension code
2. Anyone with access to your browser can see it
3. Never share your TOTP secret with anyone
4. Consider using browser profiles if multiple people use your computer
5. Keep your Chrome extension directory secure

## Testing Checklist

Before using in production, test:

- [ ] Extension loads without errors
- [ ] Sign-in button is clicked automatically
- [ ] Account is selected correctly
- [ ] Email is typed correctly
- [ ] Password is typed correctly
- [ ] Password field becomes grayed out
- [ ] 2FA page is detected
- [ ] 2fa.live window opens
- [ ] TOTP code is generated
- [ ] Code is entered correctly
- [ ] Login succeeds

## Files Modified/Created

| File | Status | Description |
|------|--------|-------------|
| `auto_login_gemini_google.js` | ✏️ Modified | Added 2FA support, password protection |
| `manifest.json` | ✏️ Modified | Added 2fa.live permissions |
| `package.json` | ✏️ Modified | Added speakeasy dependency |
| `2fa_server.js` | ✨ New | Standalone 2FA server |
| `2fa_live_helper.js` | ✨ New | Helper script for 2fa.live |
| `README-2FA.md` | ✨ New | Full documentation |
| `QUICK-START-2FA.md` | ✨ New | This file |

## Next Steps

1. **Test Locally**: Load the extension and test the login flow
2. **Verify 2FA**: Make sure the 2FA code generation works
3. **Deploy Server** (Optional): If needed, deploy `2fa_server.js` to a remote server
4. **Secure Secrets**: Consider using environment variables for production

## Support

If something doesn't work:

1. Check the console logs (F12)
2. Verify your TOTP secret is correct
3. Ensure time synchronization
4. Check for popup blockers
5. Review the troubleshooting section above

## What's Next?

You can now:
- ✅ Use the extension for automatic Gemini login with 2FA
- ✅ Deploy the 2FA server independently if needed
- ✅ Integrate the 2FA API into other projects
- ✅ Test the web interface at `http://localhost:3000`

---

**Version**: 1.0.0  
**Last Updated**: October 23, 2025  
**Status**: ✅ Ready for testing

