// auto_login_dropship.js
(function() {
  // Exécute uniquement sur la page de login dropship.io
  if (!window.location.href.startsWith('https://app.dropship.io/login')) return;

  const EMAIL = 'efficiencyecom@gmail.com';
  const PASSWORD = 'C.YBnm*C%t2as6_';

  function fillAndSubmitDropship() {
    const emailInput = document.querySelector('input[type="email"][name="email"], input#email');
    if (emailInput) {
      emailInput.value = EMAIL;
      emailInput.dispatchEvent(new Event('input', { bubbles: true }));
    }
    const passwordInput = document.querySelector('input[name="password"], input#password');
    if (passwordInput) {
      passwordInput.value = PASSWORD;
      passwordInput.dispatchEvent(new Event('input', { bubbles: true }));
    }
    const loginBtn = document.querySelector('button[type="submit"].login-form-submit, button[type="submit"].ant-btn-primary');
    if (loginBtn) {
      setTimeout(() => loginBtn.click(), 300);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', fillAndSubmitDropship);
  } else {
    fillAndSubmitDropship();
  }
})();
