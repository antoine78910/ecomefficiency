(function() {
  'use strict';

  function onTarget() {
    try {
      return location.hostname.endsWith('higgsfield.ai');
    } catch (_) {
      return false;
    }
  }

  function ensureOverlay() {
    if (!onTarget()) return;
    if (document.getElementById('ecom-purple-rect')) return;

    const rect = document.createElement('div');
    rect.id = 'ecom-purple-rect';
    Object.assign(rect.style, {
      position: 'fixed',
      top: '2px',
      right: '10px',
      width: '320px',
      height: '60px',
      backgroundColor: 'transparent',
      opacity: '0',
      borderRadius: '12px',
      zIndex: '2147483647',
      pointerEvents: 'auto',
      cursor: 'not-allowed',
      boxShadow: 'none'
    });

    // Swallow pointer events so nothing underneath is clickable
    const swallow = function(e) {
      try { e.preventDefault(); } catch (_) {}
      try { e.stopPropagation(); } catch (_) {}
      return false;
    };
    ['click','mousedown','mouseup','pointerdown','pointerup','touchstart','touchend','contextmenu'].forEach(function(evt){
      rect.addEventListener(evt, swallow, true);
    });

    document.documentElement.appendChild(rect);
  }

  function run() {
    ensureOverlay();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run);
  } else {
    run();
  }

  // Keep it present if the app re-renders
  const mo = new MutationObserver(function() { ensureOverlay(); });
  mo.observe(document.documentElement, { childList: true, subtree: true });
})();


