(function() {
  'use strict';

  const EMAIL = 'noactou2bot2l@outlook.com';
  const PASSWORD = 'Baka@619';

  function onTargetPage() {
    try {
      return location.hostname.endsWith('higgsfield.ai') && location.pathname.startsWith('/auth/login');
    } catch (_) {
      return false;
    }
  }

  function isVisible(el) {
    if (!el) return false;
    const cs = getComputedStyle(el);
    if (cs.visibility === 'hidden' || cs.display === 'none' || Number(cs.opacity) === 0) return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }

  function waitForSelector(selector, timeoutMs = 15000) {
    return new Promise(function(resolve, reject) {
      const start = Date.now();
      const check = function() {
        const el = document.querySelector(selector);
        if (el && isVisible(el)) return resolve(el);
        if (Date.now() - start >= timeoutMs) return reject(new Error('Timeout waiting for ' + selector));
        setTimeout(check, 100);
      };
      check();
    });
  }

  async function run() {
    if (!onTargetPage()) return;
    try {
      // Force remove any leftover overlay nodes from other scripts
      var overlay = document.getElementById('auto-login-overlay');
      if (overlay) overlay.remove();
      var styleEl = document.getElementById('auto-login-style');
      if (styleEl) styleEl.remove();
    } catch (_) {}
    try {
      const emailInput = await waitForSelector('input[type="email"][name="email"], input[data-sentry-element="AuthInput"][type="email"]', 20000);
      const pwdInput = await waitForSelector('input[type="password"][name="password"], input[data-sentry-element="AuthInput"][type="password"]', 20000);

      // Fill email
      emailInput.focus();
      emailInput.value = EMAIL;
      emailInput.dispatchEvent(new Event('input', { bubbles: true }));
      emailInput.dispatchEvent(new Event('change', { bubbles: true }));
      emailInput.dispatchEvent(new Event('blur', { bubbles: true }));

      // Fill password
      pwdInput.focus();
      pwdInput.value = PASSWORD;
      pwdInput.dispatchEvent(new Event('input', { bubbles: true }));
      pwdInput.dispatchEvent(new Event('change', { bubbles: true }));
      pwdInput.dispatchEvent(new Event('blur', { bubbles: true }));

      // Submit via a visible submit input/button or press Enter
      let submitEl = document.querySelector('input[type="submit"][value*="log in" i], input[type="submit"][value*="sign in" i]');
      if (!submitEl) submitEl = document.querySelector('input[type="submit"]');

      let loginBtn = submitEl;
      if (!loginBtn) {
        loginBtn = Array.from(document.querySelectorAll('button, [role="button"]')).find(function(b) {
          const t = (b.textContent || '').toLowerCase();
          return /log\s*in|sign\s*in|connexion|se\s*connecter/.test(t);
        }) || null;
      }

      if (loginBtn && isVisible(loginBtn) && !loginBtn.disabled && loginBtn.getAttribute('aria-disabled') !== 'true') {
        try { loginBtn.click(); } catch (_) {}
      } else {
        // Fallback: submit the form or press Enter
        const form = (pwdInput && pwdInput.form) || (emailInput && emailInput.form) || (loginBtn && loginBtn.closest && loginBtn.closest('form')) || null;
        if (form) {
          try { form.requestSubmit ? form.requestSubmit() : form.submit(); } catch (_) {}
        } else {
          const enterEvt = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true };
          pwdInput.dispatchEvent(new KeyboardEvent('keydown', enterEvt));
          pwdInput.dispatchEvent(new KeyboardEvent('keyup', enterEvt));
        }
      }
    } catch (_) {
      // Silent fail on page mismatch or missing elements
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run);
  } else {
    run();
  }

  // Handle SPA re-renders
  const observer = new MutationObserver(function() {
    run();
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });
})();


