(function() {
  'use strict';

  const EMAIL = 'noactou2bot2l@outlook.com';

  function onTarget() {
    try {
      return location.hostname.endsWith('microsoftonline.com') && /\/oauth2\//.test(location.pathname);
    } catch (_) {
      return false;
    }
  }

  function isVisible(el) {
    if (!el) return false;
    const cs = getComputedStyle(el);
    if (cs.visibility === 'hidden' || cs.display === 'none' || Number(cs.opacity) === 0) return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }

  function fillEmailAndNext() {
    if (!onTarget()) return false;
    const emailInput = document.querySelector('input#i0116[name="loginfmt"][type="email"]');
    if (!emailInput || !isVisible(emailInput)) return false;

    try {
      emailInput.focus();
      emailInput.value = EMAIL;
      emailInput.dispatchEvent(new Event('input', { bubbles: true }));
      emailInput.dispatchEvent(new Event('change', { bubbles: true }));
      emailInput.dispatchEvent(new Event('blur', { bubbles: true }));
    } catch (_) {}

    // Click Next
    let nextBtn = document.querySelector('input#idSIButton9[type="submit"], input[type="submit"][value="Next"]');
    if (!nextBtn) {
      // Sometimes button is rendered differently; try role or data attributes
      const candidates = Array.from(document.querySelectorAll('input[type="submit"], button'));
      nextBtn = candidates.find(function(b) {
        const t = (b.value || b.textContent || '').trim().toLowerCase();
        return t === 'next' || t.includes('next');
      }) || null;
    }

    if (nextBtn && isVisible(nextBtn) && !nextBtn.disabled) {
      try { nextBtn.focus(); } catch(_) {}
      try { nextBtn.click(); } catch(_) {}
      try { nextBtn.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true })); } catch(_) {}
      return true;
    }
    return false;
  }

  function run() {
    if (!onTarget()) return;
    if (fillEmailAndNext()) return;
    let tries = 0;
    const max = 100; // 10s
    const iv = setInterval(function() {
      tries++;
      if (fillEmailAndNext() || tries >= max) clearInterval(iv);
    }, 100);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run);
  } else {
    run();
  }
})();


