# 🔐 2FA TOTP Server & Gemini Auto-Login

This project includes a standalone 2FA/TOTP code generator server and enhanced Gemini auto-login with 2FA support.

## Features

- ✅ Standalone 2FA TOTP server
- ✅ REST API for generating TOTP codes
- ✅ Web interface for testing
- ✅ Gemini/Google auto-login with 2FA support
- ✅ Password field protection (grayed out, read-only)
- ✅ Automatic 2FA code generation and submission

## Installation

### 1. Install Dependencies

```bash
npm install
```

This will install:
- `express` - Web server framework
- `speakeasy` - TOTP code generation
- `cors` - Cross-origin resource sharing

### 2. Configure Environment

Copy `.env.example` to `.env` and update with your values:

```bash
cp .env.example .env
```

Edit `.env` file:
```env
TOTP_SECRET="t2v4 3lj5 ysb2 kh2y vidm gip2 4nty 3mu4"
PORT=3000
GOOGLE_EMAIL="your-email@gmail.com"
GOOGLE_PASSWORD="your-password"
```

## Usage

### Running the 2FA Server

**Option 1: Using npm script**
```bash
npm run 2fa-server
```

**Option 2: Direct node command**
```bash
node 2fa_server.js
```

The server will start on `http://localhost:3000` (or the port specified in `.env`)

### Using the Web Interface

1. Open your browser and go to `http://localhost:3000`
2. Enter your TOTP secret (e.g., `t2v4 3lj5 ysb2 kh2y vidm gip2 4nty 3mu4`)
3. Click "Generate Code"
4. The 6-digit code will be displayed along with time remaining

### Using the API

**POST Request:**
```bash
curl -X POST http://localhost:3000/generate \
  -H "Content-Type: application/json" \
  -d '{"secret":"t2v4 3lj5 ysb2 kh2y vidm gip2 4nty 3mu4"}'
```

**GET Request:**
```bash
curl "http://localhost:3000/generate?secret=t2v4%203lj5%20ysb2%20kh2y%20vidm%20gip2%204nty%203mu4"
```

**Response:**
```json
{
  "success": true,
  "code": "123456",
  "timeRemaining": 25,
  "timestamp": "2025-10-23T12:34:56.789Z"
}
```

## Chrome Extension - Gemini Auto-Login with 2FA

### How It Works

1. **Password Protection**: The password field is automatically grayed out and made read-only after filling to prevent viewing or copying
2. **2FA Detection**: When reaching the TOTP challenge page (`/challenge/totp`), the script automatically:
   - Opens `https://2fa.live/` in a new window
   - Fills in the TOTP secret
   - Waits for code generation
   - Extracts the code (after the `|` character)
   - Submits it to Google
   - Closes the 2fa.live window

### Configuration

The TOTP secret is configured in `auto_login_gemini_google.js`:

```javascript
const TOTP_SECRET = 't2v4 3lj5 ysb2 kh2y vidm gip2 4nty 3mu4';
```

You can also load it from environment variables if needed.

### Extension Permissions

The extension has been granted permissions for:
- `https://gemini.google.com/*`
- `https://accounts.google.com/*`
- `https://2fa.live/*`

## Deployment

### Deploy 2FA Server to Production

**Using Node.js on a VPS:**

1. Upload `2fa_server.js` to your server
2. Install dependencies: `npm install express speakeasy cors`
3. Set environment variables:
   ```bash
   export PORT=3000
   ```
4. Run the server:
   ```bash
   node 2fa_server.js
   ```

**Using PM2 (Process Manager):**

```bash
npm install -g pm2
pm2 start 2fa_server.js --name "2fa-server"
pm2 save
pm2 startup
```

**Using Docker:**

```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY 2fa_server.js package.json ./
RUN npm install --production
EXPOSE 3000
CMD ["node", "2fa_server.js"]
```

Build and run:
```bash
docker build -t 2fa-server .
docker run -d -p 3000:3000 --name 2fa-server 2fa-server
```

**Using Heroku:**

```bash
heroku create your-2fa-app
git push heroku main
```

**Using Railway/Render/Fly.io:**

Simply connect your repository and deploy. The server will automatically detect the `PORT` environment variable.

### Securing Your Server

1. **Add Authentication**: Modify the API endpoints to require an API key
2. **Use HTTPS**: Deploy behind a reverse proxy (nginx) with SSL
3. **Rate Limiting**: Add rate limiting to prevent abuse
4. **Environment Variables**: Store secrets in environment variables, not in code
5. **Firewall**: Restrict access to specific IP addresses if possible

Example with API key authentication:

```javascript
const API_KEY = process.env.API_KEY || 'your-secret-api-key';

app.use('/generate', (req, res, next) => {
  const apiKey = req.headers['x-api-key'] || req.query.apiKey;
  if (apiKey !== API_KEY) {
    return res.status(401).json({ success: false, message: 'Unauthorized' });
  }
  next();
});
```

## Troubleshooting

### Issue: "Failed to open 2fa.live window (popup blocker?)"
**Solution**: Allow popups for the Google Accounts domain in your browser settings.

### Issue: "Could not find secret input on 2fa.live"
**Solution**: Check if 2fa.live is accessible and the page structure hasn't changed.

### Issue: "Invalid TOTP code"
**Solution**: 
- Verify your TOTP secret is correct
- Ensure your system time is synchronized (TOTP is time-based)
- Check if the code format matches (6 digits)

### Issue: Password field not grayed out
**Solution**: The styling is applied after password typing completes. If you see the password, it might be a timing issue.

## Security Notes

⚠️ **Important Security Considerations:**

1. **Never commit `.env` file**: Your secrets should never be in version control
2. **Protect your TOTP secret**: Anyone with your TOTP secret can generate codes for your account
3. **Use secure connections**: Always use HTTPS in production
4. **Rotate secrets regularly**: Change your passwords and 2FA secrets periodically
5. **Monitor access**: Keep logs of 2FA code generations
6. **Limited exposure**: Only expose the 2FA server to trusted networks if possible

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | Web interface for testing |
| `/generate` | POST | Generate TOTP code (JSON body) |
| `/generate` | GET | Generate TOTP code (query param) |
| `/health` | GET | Health check endpoint |

## Dependencies

- **express**: ^4.21.2 - Web framework
- **speakeasy**: ^2.0.0 - TOTP/HOTP library
- **cors**: ^2.8.5 - CORS middleware

## License

This is a private tool for personal use. Use at your own risk.

## Support

If you encounter any issues or have questions, please check the troubleshooting section above or review the console logs in your browser's developer tools.

## Changelog

### Version 1.0.0 (October 2025)
- ✅ Initial release
- ✅ Standalone 2FA server
- ✅ Gemini auto-login with 2FA support
- ✅ Password field protection
- ✅ Web interface for testing
- ✅ REST API endpoints

