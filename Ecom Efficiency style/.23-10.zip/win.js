// win.js
(function() {
    /**
     * Affiche un overlay plein écran avec une barre de progression animée
     * afin de masquer les champs de connexion pendant l’auto-login.
     */
    function showLoadingOverlay() {
        if (document.getElementById('auto-login-overlay')) return; // déjà présent
        const overlay = document.createElement('div');
        overlay.id = 'auto-login-overlay';
        overlay.style.cssText = `position:fixed;inset:0;display:flex;align-items:center;justify-content:center;background:#000;z-index:9999;`;

        const barContainer = document.createElement('div');
        barContainer.style.cssText = `width:70%;max-width:300px;height:8px;background:#e0e0e0;border-radius:4px;overflow:hidden;`;

        const bar = document.createElement('div');
        bar.style.cssText = `width:0%;height:100%;background:#9c27b0;animation:loading-bar 1.5s infinite;`;
        barContainer.appendChild(bar);
        overlay.appendChild(barContainer);
        document.body.appendChild(overlay);

        // Définition des keyframes pour l'animation si pas déjà injectées
        if (!document.getElementById('auto-login-style')) {
          const styleElem = document.createElement('style');
          styleElem.id = 'auto-login-style';
          styleElem.textContent = `@keyframes loading-bar{0%{width:0%}50%{width:80%}100%{width:0%}}`;
          document.head.appendChild(styleElem);
        }
    }
    // Attendre que le DOM soit prêt
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', init);
    } else {
      init();

    // Afficher une barre de chargement pour masquer les identifiants
    function showLoadingOverlay() {
        const overlay = document.createElement('div');
        overlay.id = 'auto-login-overlay';
        overlay.style.cssText = `position:fixed;inset:0;display:flex;align-items:center;justify-content:center;background:#000;z-index:9999;`;

        const barContainer = document.createElement('div');
        barContainer.style.cssText = `width:70%;max-width:300px;height:8px;background:#e0e0e0;border-radius:4px;overflow:hidden;`;
        const bar = document.createElement('div');
        bar.style.cssText = `width:0%;height:100%;background:#9c27b0;animation:loading-bar 1.5s infinite;`;
        barContainer.appendChild(bar);
        overlay.appendChild(barContainer);
        document.body.appendChild(overlay);

        // Définition des keyframes pour l'animation
        const styleElem = document.createElement('style');
        styleElem.textContent = `@keyframes loading-bar{0%{width:0%}50%{width:80%}100%{width:0%}}`;
        document.head.appendChild(styleElem);
    }
    }
  
    function init() {
      // Affiche la barre de chargement
      showLoadingOverlay();

      // 1) Sélectionner l’input email
      const emailInput = document.querySelector('input#Email-2[name="Email"]');
      // 2) Sélectionner l’input password
      //    Si ton input password porte un autre id ou name, ajuste-le ici
      const passwordInput = document.querySelector('input[type="password"], input#Password-2[name="Password"]');
      // 3) Sélectionner le bouton de submit
      const loginBtn = document.querySelector('button.button.login.w-button');
  
      if (!emailInput || !passwordInput || !loginBtn) {
        console.warn('[auto-login] Un ou plusieurs éléments introuvables.');
        return;
      }
  
      // Remplir les champs
      emailInput.value = 'biwowev428@protonza.com';
      passwordInput.value = '!bcE9HL4p!QkF@D';
  
      // Optionnel : simuler un event “input” pour certains frameworks React/Vue/Angular
      emailInput.dispatchEvent(new Event('input', { bubbles: true }));
      passwordInput.dispatchEvent(new Event('input', { bubbles: true }));
  
      // Cliquer sur le bouton
      loginBtn.click();
    }
  })();
  