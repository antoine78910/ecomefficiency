// =======================
// ElevenLabs Credits Notification
// =======================
// Détecte "Low credits" et affiche le temps restant avant le prochain refill
// Refill tous les 3 jours à partir du 19 octobre 2025 5h AM UTC+2

(function() {
    'use strict';

    console.log('[ElevenLabs Credits] Script started');

    // Configuration du refill
    const REFILL_START_DATE = new Date('2025-10-19T05:00:00+02:00'); // 19 octobre 2025 5h AM UTC+2
    const REFILL_INTERVAL_HOURS = 3 * 24; // 3 jours = 72 heures

    // Fonction pour calculer le temps restant avant le prochain refill
    function getNextRefillTime() {
        const now = new Date();
        const timeSinceStart = now - REFILL_START_DATE;
        
        if (timeSinceStart < 0) {
            // Si on est avant la date de début, retourner la date de début
            const timeUntilStart = Math.abs(timeSinceStart);
            const days = Math.floor(timeUntilStart / (1000 * 60 * 60 * 24));
            const hours = Math.floor((timeUntilStart % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((timeUntilStart % (1000 * 60 * 60)) / (1000 * 60));
            return { days, hours, minutes };
        }

        // Calculer combien de cycles de 3 jours se sont écoulés
        const millisInInterval = REFILL_INTERVAL_HOURS * 60 * 60 * 1000;
        const cyclesPassed = Math.floor(timeSinceStart / millisInInterval);
        
        // Calculer la date du prochain refill
        const nextRefillDate = new Date(REFILL_START_DATE.getTime() + (cyclesPassed + 1) * millisInInterval);
        
        // Calculer le temps restant en jours, heures et minutes
        const timeUntilRefill = nextRefillDate - now;
        const days = Math.floor(timeUntilRefill / (1000 * 60 * 60 * 24));
        const hours = Math.floor((timeUntilRefill % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((timeUntilRefill % (1000 * 60 * 60)) / (1000 * 60));
        
        return { days, hours, minutes };
    }

    // Fonction pour créer la notification personnalisée
    function createCustomNotification() {
        // Vérifier si la notification existe déjà
        if (document.getElementById('elevenlabs-custom-credits-notif')) {
            console.log('[ElevenLabs Credits] Custom notification already exists');
            return;
        }

        // Vérifier si l'utilisateur a déjà fermé la notification pour cette session
        const dismissedForSession = sessionStorage.getItem('elevenlabs_credits_notif_dismissed');
        if (dismissedForSession === '1') {
            console.log('[ElevenLabs Credits] Notification already dismissed for this session');
            return;
        }

        const timeUntilRefill = getNextRefillTime();
        console.log('[ElevenLabs Credits] Time until next refill:', timeUntilRefill);
        
        // Formater le timer
        let timerText = '';
        if (timeUntilRefill.days > 0) {
            timerText = `${timeUntilRefill.days}d ${timeUntilRefill.hours}h ${timeUntilRefill.minutes}m`;
        } else {
            timerText = `${timeUntilRefill.hours}h ${timeUntilRefill.minutes}m`;
        }

        // Créer la notification
        const notifDiv = document.createElement('div');
        notifDiv.id = 'elevenlabs-custom-credits-notif';
        notifDiv.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            width: 360px;
            background: #1a1a2e;
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(138, 43, 226, 0.4);
            z-index: 999999;
            color: white;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            animation: slideIn 0.3s ease-out;
        `;

        notifDiv.innerHTML = `
            <style>
                @keyframes slideIn {
                    from {
                        transform: translateX(100px);
                        opacity: 0;
                    }
                    to {
                        transform: translateX(0);
                        opacity: 1;
                    }
                }
                
                #elevenlabs-custom-credits-notif .close-btn {
                    position: absolute;
                    top: 12px;
                    right: 12px;
                    background: transparent;
                    border: 1px solid rgba(138, 43, 226, 0.3);
                    color: rgba(138, 43, 226, 0.8);
                    width: 28px;
                    height: 28px;
                    border-radius: 6px;
                    cursor: pointer;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    transition: all 0.2s ease;
                    font-size: 18px;
                    font-weight: 600;
                }
                
                #elevenlabs-custom-credits-notif .close-btn:hover {
                    background: rgba(138, 43, 226, 0.15);
                    border-color: rgba(138, 43, 226, 0.6);
                    color: rgba(138, 43, 226, 1);
                }
                
                #elevenlabs-custom-credits-notif .timer {
                    font-size: 42px;
                    font-weight: 700;
                    margin: 15px 0;
                    color: #a78bfa;
                }
                
                #elevenlabs-custom-credits-notif .label {
                    font-size: 13px;
                    opacity: 0.7;
                    margin-bottom: 8px;
                    letter-spacing: 0.3px;
                    text-transform: uppercase;
                    font-size: 11px;
                }
                
                #elevenlabs-custom-credits-notif .section {
                    background: rgba(138, 43, 226, 0.08);
                    border: 1px solid rgba(138, 43, 226, 0.2);
                    border-radius: 8px;
                    padding: 14px;
                    margin-top: 18px;
                }
                
                #elevenlabs-custom-credits-notif .section-title {
                    font-size: 14px;
                    font-weight: 600;
                    margin-bottom: 10px;
                    opacity: 0.9;
                }
                
                #elevenlabs-custom-credits-notif .upgrade-btn {
                    background: #8b5cf6;
                    color: white;
                    border: none;
                    padding: 10px 20px;
                    border-radius: 6px;
                    font-weight: 600;
                    cursor: pointer;
                    width: 100%;
                    margin-top: 8px;
                    transition: background 0.2s ease;
                    font-size: 13px;
                }
                
                #elevenlabs-custom-credits-notif .upgrade-btn:hover {
                    background: #7c3aed;
                }
                
                #elevenlabs-custom-credits-notif .warning {
                    background: rgba(138, 43, 226, 0.05);
                    border: 1px solid rgba(138, 43, 226, 0.15);
                    border-radius: 6px;
                    padding: 10px;
                    font-size: 11px;
                    margin-top: 12px;
                    display: flex;
                    align-items: center;
                    gap: 8px;
                    line-height: 1.4;
                    opacity: 0.85;
                }
                
                #elevenlabs-custom-credits-notif .warning-icon {
                    font-size: 14px;
                    flex-shrink: 0;
                }
            </style>
            
            <button class="close-btn" id="close-credits-notif" title="Close">×</button>
            
            <div style="font-size: 24px; font-weight: 700; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; justify-content: center;">
                <span style="font-size: 28px;">⚠️</span>
                <span>No More Credits</span>
            </div>
            
            <div class="label">Next refill in</div>
            <div class="timer">${timerText}</div>
            
            <div class="section">
                <div class="section-title">💎 Want more credits?</div>
                <button class="upgrade-btn" id="upgrade-pro-btn">Upgrade to Pro</button>
            </div>
            
            <div class="warning">
                <span class="warning-icon">⚠️</span>
                <span><strong>Important:</strong> Connect and open the link in your own browser</span>
            </div>
        `;

        document.body.appendChild(notifDiv);
        console.log('[ElevenLabs Credits] Custom notification created');

        // Ajouter les event listeners
        const closeBtn = document.getElementById('close-credits-notif');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                // Marquer comme dismissed pour cette session uniquement
                sessionStorage.setItem('elevenlabs_credits_notif_dismissed', '1');
                console.log('[ElevenLabs Credits] Notification dismissed for this session');
                
                notifDiv.style.animation = 'slideInRight 0.3s ease-in reverse';
                setTimeout(() => {
                    notifDiv.remove();
                    console.log('[ElevenLabs Credits] Notification closed');
                }, 300);
            });
        }

        const upgradeBtn = document.getElementById('upgrade-pro-btn');
        if (upgradeBtn) {
            upgradeBtn.addEventListener('click', () => {
                window.open('https://ecomefficiency.com', '_blank');
                console.log('[ElevenLabs Credits] Upgrade button clicked - Opening ecomefficiency.com');
            });
        }

        // Ne plus auto-fermer - l'utilisateur doit cliquer sur la croix
        // setTimeout(() => {
        //     if (document.getElementById('elevenlabs-custom-credits-notif')) {
        //         notifDiv.style.animation = 'slideInRight 0.3s ease-in reverse';
        //         setTimeout(() => {
        //             notifDiv.remove();
        //             console.log('[ElevenLabs Credits] Notification auto-closed after 30s (will show again on next page load)');
        //         }, 300);
        //     }
        // }, 30000);
    }

    // Fonction pour détecter la notification "Low credits" ou afficher automatiquement
    function detectLowCreditsNotification() {
        // Afficher le popup sur toutes les pages d'ElevenLabs
        console.log('[ElevenLabs Credits] Showing notification on', location.pathname);
        createCustomNotification();
        return true;

        // Code de détection "Low credits" conservé au cas où (mais désactivé)
        /*
        const allElements = document.querySelectorAll('*');
        
        for (const el of allElements) {
            const text = el.textContent || '';
            
            // Chercher "Low credits" dans le texte
            if (text.includes('Low credits') && text.includes('Upgrade')) {
                console.log('[ElevenLabs Credits] "Low credits" notification detected!');
                
                // Vérifier si c'est bien l'élément parent avec la structure attendue
                const html = el.outerHTML || '';
                if (html.includes('bg-gray-alpha-50') || html.includes('Low credits')) {
                    createCustomNotification();
                    return true;
                }
            }
        }
        
        return false;
        */
    }

    // Observer les changements du DOM pour détecter l'apparition de la notification
    const observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
            if (mutation.addedNodes.length > 0) {
                // Attendre un peu que le DOM soit stable
                setTimeout(() => {
                    detectLowCreditsNotification();
                }, 100);
                break;
            }
        }
    });

    // Démarrer l'observation
    function startObserving() {
        if (document.body) {
            observer.observe(document.body, {
                childList: true,
                subtree: true
            });
            console.log('[ElevenLabs Credits] Observer started');
            
            // Faire une première vérification
            setTimeout(() => {
                detectLowCreditsNotification();
            }, 1000);
        } else {
            setTimeout(startObserving, 100);
        }
    }

    // Attendre que le DOM soit prêt
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', startObserving);
    } else {
        startObserving();
    }

    console.log('[ElevenLabs Credits] Initialization complete');

})();

